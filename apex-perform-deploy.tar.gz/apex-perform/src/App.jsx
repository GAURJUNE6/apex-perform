import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants & Data ───
const BRAND = {
  bg: "#060610",
  surface: "#0C0C1A",
  card: "rgba(18,18,32,0.65)",
  cardSolid: "#121220",
  border: "rgba(255,255,255,0.06)",
  borderHover: "rgba(233,69,96,0.4)",
  primary: "#E94560",
  primaryGlow: "rgba(233,69,96,0.35)",
  accent: "#00D4AA",
  accentGlow: "rgba(0,212,170,0.25)",
  gold: "#FFD700",
  purple: "#8B5CF6",
  blue: "#3B82F6",
  text: "#F2F2FA",
  textMuted: "#9494B0",
  textDim: "#50506A",
  gradient: "linear-gradient(135deg, #E94560 0%, #FF6B8A 50%, #E94560 100%)",
  accentGradient: "linear-gradient(135deg, #00D4AA 0%, #00F5C8 100%)",
  meshGradient: "radial-gradient(ellipse at 20% 50%, rgba(233,69,96,0.15) 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, rgba(0,212,170,0.1) 0%, transparent 50%), radial-gradient(ellipse at 50% 80%, rgba(139,92,246,0.08) 0%, transparent 50%)",
};

const PAGES = { LANDING: "landing", DASHBOARD: "dashboard", AI_LAB: "ailab", COACH: "coach", RESUME: "resume", PROFILE: "profile", SETTINGS: "settings", DOJO: "dojo", ANALYTICS: "analytics", INSIGHTS: "insights", HEADSHOTS: "headshots", HALL_OF_FAME: "halloffame", FOUNDER: "founder" };

const SAMPLE_SCORES = [
  { date: "Feb 1", eye: 72, pacing: 65, expression: 78, overall: 72 },
  { date: "Feb 8", eye: 75, pacing: 70, expression: 80, overall: 75 },
  { date: "Feb 15", eye: 80, pacing: 74, expression: 82, overall: 79 },
  { date: "Feb 22", eye: 83, pacing: 78, expression: 85, overall: 82 },
  { date: "Mar 1", eye: 87, pacing: 82, expression: 88, overall: 86 },
];

const TIPS = [
  { icon: "👁️", title: "Eye Contact at 0:42", text: "Your gaze drifts down-left for 1.3s during the emotional beat. Try anchoring to a fixed point just above the lens." },
  { icon: "🎭", title: "Micro-Expression Gap", text: "Between 1:15–1:22, your face goes neutral during dialogue. Layer in subtle tension through your jaw and brow." },
  { icon: "⏱️", title: "Pacing Rush at 0:58", text: "You accelerated to 185 WPM during the confrontation line. Slow to 140 WPM and let the silence carry weight." },
];

const DAILY_CHALLENGES = [
  { title: "The Dramatic Pause", desc: "Deliver a 15-second monologue with one powerful dramatic pause of at least 3 seconds.", xp: 50, focus: "Pacing" },
  { title: "Eye Lock Challenge", desc: "Perform a 30-second emotional speech maintaining 100% eye contact with the camera.", xp: 60, focus: "Eye Contact" },
  { title: "The Cold Read", desc: "Read these 3 lines for the first time on camera — no rehearsal, pure instinct.", xp: 75, focus: "Instinct" },
  { title: "Emotion Switch", desc: "Transition from joy to grief in a single take. Make the switch feel natural, not forced.", xp: 80, focus: "Expression" },
  { title: "Whisper Power", desc: "Deliver an intense monologue entirely in a whisper. Let the quiet carry the emotion.", xp: 55, focus: "Vocal Control" },
  { title: "The One-Take Wonder", desc: "Perform a 60-second scene in one unbroken take with zero restarts.", xp: 100, focus: "Composure" },
  { title: "Mirror Work", desc: "Record yourself reacting silently to an imaginary scene partner for 20 seconds.", xp: 45, focus: "Micro-Expressions" },
];

// Leaderboard will be populated with real users only

// ─── AI UTILITY FUNCTIONS ───
const callClaudeAPI = async (systemPrompt, userContent) => {
  try {
    const messages = [{ role: "user", content: typeof userContent === "string" ? userContent : userContent }];
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages,
      }),
    });
    const data = await response.json();
    const text = data.content?.map(b => b.type === "text" ? b.text : "").join("") || "";
    return text;
  } catch (err) {
    console.error("Claude API error:", err);
    return null;
  }
};

const parseJSON = (text) => {
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch { return null; }
};

// ─── Utility Components ───
const GlowButton = ({ children, onClick, variant = "primary", size = "md", style = {}, disabled = false }) => {
  const [hover, setHover] = useState(false);
  const isPrimary = variant === "primary";
  const isLg = size === "lg";
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: isPrimary
          ? (hover ? "linear-gradient(135deg, #FF6B8A 0%, #E94560 50%, #FF6B8A 100%)" : BRAND.gradient)
          : "transparent",
        backgroundSize: isPrimary && hover ? "200% 100%" : "100% 100%",
        animation: isPrimary && hover ? "shimmer 2s linear infinite" : "none",
        border: isPrimary ? "none" : `1px solid ${hover ? BRAND.borderHover : BRAND.border}`,
        color: BRAND.text,
        padding: isLg ? "20px 52px" : size === "sm" ? "10px 20px" : "14px 32px",
        borderRadius: isLg ? 16 : 12,
        fontSize: isLg ? "18px" : size === "sm" ? "13px" : "15px",
        fontWeight: 700,
        fontFamily: "'Outfit', sans-serif",
        cursor: disabled ? "not-allowed" : "pointer",
        transition: "all 0.35s cubic-bezier(0.4, 0, 0.2, 1)",
        transform: hover && !disabled ? "translateY(-3px) scale(1.02)" : "none",
        boxShadow: hover && isPrimary && !disabled
          ? `0 12px 40px ${BRAND.primaryGlow}, 0 0 0 1px rgba(233,69,96,0.2)`
          : hover && !isPrimary ? `0 6px 24px rgba(0,0,0,0.4)` : "none",
        opacity: disabled ? 0.4 : 1,
        letterSpacing: "0.5px",
        position: "relative",
        overflow: "hidden",
        ...style,
      }}
    >
      {children}
    </button>
  );
};

const ScoreGauge = ({ score, size = 140, label }) => {
  const [animScore, setAnimScore] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = () => {
      start += 2;
      if (start >= score) { setAnimScore(score); return; }
      setAnimScore(start);
      requestAnimationFrame(step);
    };
    const t = setTimeout(step, 300);
    return () => clearTimeout(t);
  }, [score]);
  const r = (size - 16) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (animScore / 100) * circ;
  const color = animScore >= 70 ? BRAND.accent : animScore >= 40 ? BRAND.gold : BRAND.primary;
  return (
    <div style={{ textAlign: "center", position: "relative" }}>
      <div style={{
        position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
        width: size * 0.7, height: size * 0.7, borderRadius: "50%",
        background: `radial-gradient(circle, ${color}15 0%, transparent 70%)`,
        filter: "blur(20px)", animation: "glow-pulse 3s ease-in-out infinite",
      }} />
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)", position: "relative" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="8" />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.5s ease-out", filter: `drop-shadow(0 0 12px ${color})` }} />
      </svg>
      <div style={{ marginTop: -size/2 - 20, position: "relative", height: size/2 + 20 }}>
        <div style={{ fontSize: size * 0.3, fontWeight: 800, color, fontFamily: "'Space Mono', monospace", letterSpacing: "-2px" }}>{animScore}</div>
        {label && <div style={{ fontSize: 12, color: BRAND.textMuted, marginTop: 2 }}>{label}</div>}
      </div>
    </div>
  );
};

const BarScore = ({ label, score, delay = 0 }) => {
  const [w, setW] = useState(0);
  useEffect(() => { const t = setTimeout(() => setW(score), 200 + delay); return () => clearTimeout(t); }, [score, delay]);
  const color = score >= 70 ? BRAND.accent : score >= 40 ? BRAND.gold : BRAND.primary;
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{ fontSize: 13, color: BRAND.textMuted, fontFamily: "'Outfit', sans-serif" }}>{label}</span>
        <span style={{ fontSize: 13, fontWeight: 700, color, fontFamily: "'Space Mono', monospace" }}>{score}/100</span>
      </div>
      <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.04)", overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${w}%`, borderRadius: 3, background: `linear-gradient(90deg, ${color}CC, ${color})`, transition: "width 1s cubic-bezier(0.4, 0, 0.2, 1)", boxShadow: `0 0 16px ${color}40` }} />
      </div>
    </div>
  );
};

const Card = ({ children, style = {}, glow = false, onClick }) => {
  const [hover, setHover] = useState(false);
  return (
    <div onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: BRAND.card,
        backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)",
        borderRadius: 20,
        border: `1px solid ${hover && (glow || onClick) ? BRAND.borderHover : BRAND.border}`,
        padding: 28, transition: "all 0.4s cubic-bezier(0.4, 0, 0.2, 1)",
        boxShadow: hover && glow
          ? `0 12px 48px ${BRAND.primaryGlow}, inset 0 1px 0 rgba(255,255,255,0.05)`
          : "inset 0 1px 0 rgba(255,255,255,0.03)",
        cursor: onClick ? "pointer" : "default",
        transform: hover && onClick ? "translateY(-6px) scale(1.01)" : "none",
        ...style,
      }}
    >
      {children}
    </div>
  );
};

const StatCard = ({ icon, value, label }) => (
  <Card style={{ textAlign: "center", flex: 1, minWidth: 140, position: "relative", overflow: "hidden", padding: "32px 20px" }}>
    <div style={{ position: "absolute", top: 0, left: "20%", right: "20%", height: 2, background: BRAND.gradient, borderRadius: "0 0 2px 2px" }} />
    <div style={{ fontSize: 28, marginBottom: 10, filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.3))" }}>{icon}</div>
    <div style={{ fontSize: 30, fontWeight: 800, color: BRAND.text, fontFamily: "'Space Mono', monospace", letterSpacing: "-1px" }}>{value}</div>
    <div style={{ fontSize: 12, color: BRAND.textMuted, marginTop: 6, fontWeight: 500, letterSpacing: "0.5px" }}>{label}</div>
  </Card>
);

const NavBar = ({ page, setPage, isLoggedIn, openSignup, openLogin, onLogout, username, role }) => {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const el = document.getElementById("main-scroll");
    if (!el) return;
    const h = () => setScrolled(el.scrollTop > 20);
    el.addEventListener("scroll", h);
    return () => el.removeEventListener("scroll", h);
  }, []);
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 100,
      background: scrolled ? "rgba(6,6,16,0.85)" : "rgba(6,6,16,0.4)",
      backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)",
      borderBottom: `1px solid ${scrolled ? BRAND.border : "transparent"}`,
      padding: "14px 32px", display: "flex", alignItems: "center", justifyContent: "space-between",
      transition: "all 0.4s ease",
    }}>
      <div onClick={() => setPage(isLoggedIn ? PAGES.DASHBOARD : PAGES.LANDING)}
        style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          width: 38, height: 38, borderRadius: 12, background: BRAND.gradient, display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 900, fontSize: 18, color: "#fff", fontFamily: "'Outfit', sans-serif",
          boxShadow: `0 4px 16px ${BRAND.primaryGlow}`,
        }}>A</div>
        <span style={{ fontWeight: 800, fontSize: 18, color: BRAND.text, fontFamily: "'Outfit', sans-serif", letterSpacing: "2px" }}>APEX</span>
        <span style={{ fontWeight: 400, fontSize: 18, color: BRAND.textMuted, fontFamily: "'Outfit', sans-serif", letterSpacing: "2px" }}>CASTING</span>
      </div>
      {isLoggedIn ? (
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          {(role === "director" ? [
            { p: PAGES.DASHBOARD, label: "Dashboard", icon: "◻" },
            { p: PAGES.SETTINGS, label: "Settings", icon: "⚙" },
          ] : [
            { p: PAGES.DASHBOARD, label: "Dashboard", icon: "◻" },
            { p: PAGES.HALL_OF_FAME, label: "Hall of Fame", icon: "🏆" },
            { p: PAGES.DOJO, label: "Dojo", icon: "🥋" },
            { p: PAGES.AI_LAB, label: "AI Lab", icon: "⚡" },
            { p: PAGES.PROFILE, label: "Profile", icon: "◉" },
            { p: PAGES.SETTINGS, label: "Settings", icon: "⚙" },
          ]).map(({ p, label, icon }) => (
            <button key={p} onClick={() => setPage(p)} style={{
              background: page === p ? "rgba(233,69,96,0.12)" : "transparent",
              border: "none",
              borderBottom: page === p ? `2px solid ${BRAND.primary}` : "2px solid transparent",
              color: page === p ? BRAND.text : BRAND.textDim,
              padding: "10px 16px", borderRadius: "8px 8px 0 0", fontSize: 13, fontWeight: page === p ? 700 : 500,
              cursor: "pointer", fontFamily: "'Outfit', sans-serif", transition: "all 0.25s ease",
            }}>
              {icon} {label}
            </button>
          ))}
          <div style={{ width: 1, height: 20, background: BRAND.border, margin: "0 8px" }} />
          <GlowButton size="sm" variant="ghost" onClick={onLogout}>Log Out{username ? ` (@${username})` : ""}</GlowButton>
        </div>
      ) : (
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <GlowButton size="sm" variant="ghost" onClick={openLogin}>Log In</GlowButton>
          <GlowButton size="sm" onClick={openSignup}>Start Free Trial</GlowButton>
        </div>
      )}
    </nav>
  );
};

// ─── LANDING PAGE ───
const LandingPage = ({ setPage, openSignup, founderSlotsLeft, isFounderPricing, currentPrice, performerOfTheWeek }) => {
  const [visible, setVisible] = useState(false);
  const [waitlistEmail, setWaitlistEmail] = useState("");
  const [waitlistStatus, setWaitlistStatus] = useState(""); // "", "error", "success"
  useEffect(() => { setTimeout(() => setVisible(true), 100); }, []);

  const Feature = ({ icon, title, desc, delay }) => (
    <Card glow style={{
      flex: 1, minWidth: 260, opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(40px)",
      transition: `all 0.7s cubic-bezier(0.4,0,0.2,1) ${delay}ms`,
    }}>
      <div style={{ fontSize: 40, marginBottom: 16 }}>{icon}</div>
      <h3 style={{ margin: "0 0 10px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{title}</h3>
      <p style={{ margin: 0, fontSize: 14, lineHeight: 1.7, color: BRAND.textMuted }}>{desc}</p>
    </Card>
  );

  const PriceRow = ({ platform, price, ai, highlighted }) => (
    <div style={{
      display: "flex", alignItems: "center", padding: "16px 20px", borderRadius: 12,
      background: highlighted ? BRAND.primary + "15" : "transparent",
      border: highlighted ? `1px solid ${BRAND.primary}40` : `1px solid ${BRAND.border}`,
      marginBottom: 8,
    }}>
      <div style={{ flex: 2, fontWeight: highlighted ? 800 : 500, color: highlighted ? BRAND.primary : BRAND.text, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>{platform}</div>
      <div style={{ flex: 1, textAlign: "center", fontWeight: 700, fontSize: 15, color: highlighted ? BRAND.accent : BRAND.textMuted, fontFamily: "'Outfit', sans-serif" }}>{price}</div>
      <div style={{ flex: 1, textAlign: "center", fontSize: 14, color: highlighted ? BRAND.accent : BRAND.textMuted }}>{ai}</div>
    </div>
  );

  return (
    <div>
      {/* Hero */}
      <section style={{
        minHeight: "92vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        textAlign: "center", padding: "80px 24px", position: "relative", overflow: "hidden",
      }}>
        {/* Animated gradient orbs */}
        <div style={{
          position: "absolute", top: "-20%", left: "40%", transform: "translateX(-50%)",
          width: 900, height: 900, borderRadius: "50%",
          background: `radial-gradient(circle, rgba(233,69,96,0.2) 0%, transparent 60%)`,
          filter: "blur(100px)", pointerEvents: "none", animation: "glow-pulse 6s ease-in-out infinite",
        }} />
        <div style={{
          position: "absolute", bottom: "-15%", right: "-5%",
          width: 600, height: 600, borderRadius: "50%",
          background: `radial-gradient(circle, rgba(0,212,170,0.15) 0%, transparent 60%)`,
          filter: "blur(80px)", pointerEvents: "none", animation: "glow-pulse 8s ease-in-out infinite 2s",
        }} />
        <div style={{
          position: "absolute", top: "20%", left: "5%",
          width: 400, height: 400, borderRadius: "50%",
          background: `radial-gradient(circle, rgba(139,92,246,0.1) 0%, transparent 60%)`,
          filter: "blur(60px)", pointerEvents: "none", animation: "glow-pulse 7s ease-in-out infinite 4s",
        }} />
        {/* Grid lines decoration */}
        <div style={{
          position: "absolute", inset: 0, pointerEvents: "none", opacity: 0.03,
          backgroundImage: "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }} />

        <div style={{ position: "relative", zIndex: 1, maxWidth: 860 }}>
          <div style={{
            display: "inline-block", padding: "8px 24px", borderRadius: 40,
            background: "rgba(233,69,96,0.08)", border: `1px solid rgba(233,69,96,0.2)`,
            marginBottom: 36, opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.6s ease 0.1s", backdropFilter: "blur(10px)",
          }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: BRAND.primary, fontFamily: "'Outfit', sans-serif", letterSpacing: 1.5 }}>
              AI-POWERED ACTING TOOLS &bull; {isFounderPricing ? "FOUNDER'S PRICE: $1.99/MO" : "$4.99/MO"}
            </span>
          </div>

          <h1 style={{
            fontSize: "clamp(44px, 7vw, 80px)", fontWeight: 900, lineHeight: 1.0,
            margin: "0 0 28px", fontFamily: "'Outfit', sans-serif", color: BRAND.text,
            opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.7s ease 0.2s", letterSpacing: "-2px",
          }}>
            Your AI Acting Coach<br />
            <span style={{
              background: "linear-gradient(135deg, #E94560, #FF6B8A, #E94560)",
              backgroundSize: "200% 100%",
              animation: "gradient-shift 4s ease infinite",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              for {currentPrice}/month
            </span>
          </h1>

          <p style={{
            fontSize: 21, color: BRAND.textMuted, lineHeight: 1.7, margin: "0 0 44px", maxWidth: 600, marginLeft: "auto", marginRight: "auto",
            opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.7s ease 0.35s", fontWeight: 300,
          }}>
            AI-powered audition coaching, a Hollywood-grade digital resume, headshot analysis, and career analytics — for less than a coffee.
          </p>

          <div style={{
            display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap",
            opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.7s ease 0.5s",
          }}>
            <GlowButton size="lg" onClick={openSignup}>Start 3-Day Free Trial →</GlowButton>
            <GlowButton size="lg" variant="ghost" onClick={() => {}}>Watch Demo</GlowButton>
          </div>

          {/* Founder Counter */}
          {isFounderPricing && (
            <div style={{
              maxWidth: 480, margin: "56px auto 0",
              opacity: visible ? 1 : 0, transition: "all 0.7s ease 0.7s",
            }}>
              <div style={{
                padding: "20px 28px", borderRadius: 16,
                background: "rgba(233,69,96,0.06)", border: `1px solid rgba(233,69,96,0.2)`,
                backdropFilter: "blur(10px)",
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: BRAND.primary, fontFamily: "'Outfit', sans-serif", letterSpacing: 1 }}>🔥 FOUNDER'S PRICING</span>
                  <span style={{ fontSize: 15, fontWeight: 800, color: BRAND.text, fontFamily: "'Space Mono', monospace" }}>{founderSlotsLeft} of 1,000 left</span>
                </div>
                <div style={{ height: 8, borderRadius: 4, background: BRAND.border, overflow: "hidden", marginBottom: 10 }}>
                  <div style={{
                    height: "100%", borderRadius: 4,
                    width: `${((1000 - founderSlotsLeft) / 1000) * 100}%`,
                    background: founderSlotsLeft < 100 ? BRAND.primary : BRAND.accent,
                    transition: "width 1s ease",
                    boxShadow: `0 0 12px ${founderSlotsLeft < 100 ? BRAND.primaryGlow : BRAND.accentGlow}`,
                  }} />
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 12, color: BRAND.textDim }}>Lock in <strong style={{ color: BRAND.accent }}>$1.99/mo forever</strong> — price goes to $4.99 after 1,000</span>
                </div>
              </div>
            </div>
          )}

          {!isFounderPricing && (
            <div style={{
              maxWidth: 480, margin: "56px auto 0",
              opacity: visible ? 1 : 0, transition: "all 0.7s ease 0.7s",
            }}>
              <div style={{
                padding: "16px 24px", borderRadius: 12,
                background: BRAND.gold + "10", border: `1px solid ${BRAND.gold}30`,
              }}>
                <span style={{ fontSize: 13, color: BRAND.gold, fontWeight: 600 }}>
                  ⚡ Founder slots are full! Standard pricing: $4.99/month
                </span>
              </div>
            </div>
          )}

          <div style={{
            display: "flex", gap: 48, justifyContent: "center", marginTop: 32,
            opacity: visible ? 1 : 0, transition: "all 0.7s ease 0.8s",
          }}>
            {[
              { n: "3-Day", l: "Free Trial" },
              { n: currentPrice, l: isFounderPricing ? "Founder Price" : "Per Month" },
              { n: "6+", l: "AI Tools" },
            ].map(({ n, l }) => (
              <div key={l} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Space Mono', monospace" }}>{n}</div>
                <div style={{ fontSize: 12, color: BRAND.textDim, marginTop: 4, letterSpacing: "1px", textTransform: "uppercase" }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: "100px 32px", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.primary, letterSpacing: 3, marginBottom: 16, fontFamily: "'Space Mono', monospace" }}>WHAT'S INCLUDED</div>
          <h2 style={{ fontSize: 40, fontWeight: 800, margin: "0 0 12px", color: BRAND.text, fontFamily: "'Outfit', sans-serif", letterSpacing: "-1px" }}>
            Elite Tools. <span style={{ color: BRAND.primary }}>Micro Price.</span>
          </h2>
          <p style={{ color: BRAND.textMuted, margin: 0, fontSize: 17, fontWeight: 300 }}>
            Everything you need to level up your acting career — powered by AI.
          </p>
        </div>
        <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
          <Feature icon="🎬" title="AI Audition Coach" desc="Upload self-tapes and get scored on eye contact, pacing, and facial expression. Receive a Pro Score and 3 actionable coaching tips — like having a personal coach on demand." delay={0} />
          <Feature icon="📝" title="AI Resume Architect" desc="Transform raw skills into professional casting language. Upload proof of your certifications and awards to earn a Verified by APEX badge that makes your profile stand out." delay={150} />
          <Feature icon="📸" title="AI Headshot Ranker" desc="Upload multiple headshots. AI tags them with casting archetypes — Commercial, Theatrical, Villain, Hero — and ranks their effectiveness by industry lighting and framing standards." delay={300} />
          <Feature icon="📊" title="Audition Analytics" desc="Track your audition-to-booking ratio. AI finds correlations between your performance scores and successful bookings to optimize your career strategy." delay={450} />
          <Feature icon="👁️" title="Talent Insights" desc="See which casting directors viewed your profile, how long they watched your reel, and what sections they engaged with. Know when industry pros are interested." delay={600} />
          <Feature icon="🥋" title="Daily Dojo" desc="New acting challenge every day. Record your take, get an AI score, earn XP, and climb the global leaderboard against other actors." delay={750} />
        </div>
      </section>

      {/* Performer of the Week */}
      {performerOfTheWeek && (
        <section style={{ padding: "80px 32px", maxWidth: 700, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.gold, letterSpacing: 3, marginBottom: 12, fontFamily: "'Space Mono', monospace" }}>🏆 HALL OF FAME</div>
            <h2 style={{ fontSize: 36, fontWeight: 800, margin: "0 0 8px", color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
              Performer of the Week
            </h2>
            <p style={{ color: BRAND.textMuted, margin: 0, fontSize: 15 }}>Highest average AI Pro Score with 3+ auditions this week.</p>
          </div>
          <div style={{
            padding: "40px 36px", borderRadius: 24, textAlign: "center",
            background: `linear-gradient(180deg, ${BRAND.gold}08 0%, ${BRAND.card} 60%)`,
            border: `1px solid ${BRAND.gold}30`,
            boxShadow: `0 16px 64px ${BRAND.gold}10`,
          }}>
            <div style={{ position: "relative", display: "inline-block", marginBottom: 20 }}>
              <div style={{
                width: 120, height: 150, borderRadius: 16, overflow: "hidden",
                background: performerOfTheWeek.form?.headshot ? "none" : BRAND.gradient,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 48, fontWeight: 800, color: "#fff", fontFamily: "'Outfit', sans-serif",
                border: `3px solid ${BRAND.gold}`,
                boxShadow: `0 0 40px ${BRAND.gold}30`,
              }}>
                {performerOfTheWeek.form?.headshot ? (
                  <img src={performerOfTheWeek.form.headshot.dataUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                ) : (performerOfTheWeek.form?.name?.charAt(0) || performerOfTheWeek.username?.charAt(0) || "?")}
              </div>
              <div style={{
                position: "absolute", top: -8, right: -8, width: 36, height: 36, borderRadius: "50%",
                background: BRAND.gold, display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 18, boxShadow: `0 4px 16px ${BRAND.gold}50`,
              }}>🏆</div>
            </div>
            <h3 style={{ margin: "0 0 4px", fontSize: 26, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
              {performerOfTheWeek.form?.name || `@${performerOfTheWeek.username}`}
            </h3>
            <div style={{ fontSize: 14, color: BRAND.textMuted, marginBottom: 16 }}>
              {[performerOfTheWeek.form?.ageRange, performerOfTheWeek.form?.ethnicity, performerOfTheWeek.form?.location].filter(Boolean).join(" · ")}
            </div>
            <div style={{ display: "flex", gap: 24, justifyContent: "center", marginBottom: 16 }}>
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 36, fontWeight: 800, color: BRAND.gold, fontFamily: "'Space Mono', monospace" }}>{performerOfTheWeek.avg}</div>
                <div style={{ fontSize: 11, color: BRAND.textDim, letterSpacing: 1 }}>AVG SCORE</div>
              </div>
              <div style={{ width: 1, background: BRAND.border }} />
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 36, fontWeight: 800, color: BRAND.accent, fontFamily: "'Space Mono', monospace" }}>{performerOfTheWeek.best}</div>
                <div style={{ fontSize: 11, color: BRAND.textDim, letterSpacing: 1 }}>BEST SCORE</div>
              </div>
              <div style={{ width: 1, background: BRAND.border }} />
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 36, fontWeight: 800, color: BRAND.text, fontFamily: "'Space Mono', monospace" }}>{performerOfTheWeek.count}</div>
                <div style={{ fontSize: 11, color: BRAND.textDim, letterSpacing: 1 }}>AUDITIONS</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 6, justifyContent: "center", flexWrap: "wrap" }}>
              {[performerOfTheWeek.form?.skill1, performerOfTheWeek.form?.skill2, performerOfTheWeek.form?.skill3].filter(Boolean).map(s => (
                <span key={s} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 6, background: BRAND.surface, border: `1px solid ${BRAND.border}`, color: BRAND.textMuted }}>{s}</span>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Pricing Comparison */}
      <section style={{ padding: "80px 32px", maxWidth: 700, margin: "0 auto" }}>
        <h2 style={{ fontSize: 32, fontWeight: 800, textAlign: "center", margin: "0 0 40px", color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
          What You'd Pay <span style={{ color: BRAND.primary }}>Elsewhere</span>
        </h2>
        <div style={{ display: "flex", padding: "12px 20px", marginBottom: 12 }}>
          <div style={{ flex: 2, fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, fontFamily: "'Outfit', sans-serif" }}>OPTION</div>
          <div style={{ flex: 1, textAlign: "center", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, fontFamily: "'Outfit', sans-serif" }}>COST</div>
          <div style={{ flex: 1, textAlign: "center", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, fontFamily: "'Outfit', sans-serif" }}>AI TOOLS</div>
        </div>
        <PriceRow platform="Private Acting Coach" price="$75–200/hr" ai="None" />
        <PriceRow platform="Online Audition Course" price="$50–300" ai="None" />
        <PriceRow platform="Resume Copywriter" price="$100+ one-time" ai="Manual" />
        <PriceRow platform="⚡ APEX PERFORM" price={isFounderPricing ? "$1.99/mo" : "$4.99/mo"} ai="6 AI Tools" highlighted />
      </section>

      {/* Phase 2: APEX Market Waitlist */}
      <section style={{
        padding: "80px 32px", maxWidth: 900, margin: "0 auto",
      }}>
        <div style={{
          borderRadius: 24, overflow: "hidden",
          background: `linear-gradient(135deg, ${BRAND.card} 0%, ${BRAND.surface} 100%)`,
          border: `1px solid ${BRAND.accent}25`, position: "relative",
        }}>
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: BRAND.accentGradient }} />
          <div style={{ padding: "48px 40px" }}>
            <div style={{ display: "inline-block", padding: "4px 14px", borderRadius: 8, background: BRAND.accent + "15", border: `1px solid ${BRAND.accent}40`, marginBottom: 20 }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: BRAND.accent, letterSpacing: 1, fontFamily: "'Outfit', sans-serif" }}>COMING SOON — PHASE 2</span>
            </div>
            <h2 style={{ fontSize: 32, fontWeight: 900, margin: "0 0 12px", color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
              The APEX Market
            </h2>
            <p style={{ fontSize: 16, color: BRAND.textMuted, lineHeight: 1.7, margin: "0 0 32px", maxWidth: 600 }}>
              A high-end marketplace where vetted production houses, casting directors, and agents post roles directly to APEX-verified talent. No open cattle calls. No unqualified submissions.
            </p>

            <div style={{ display: "flex", gap: 20, flexWrap: "wrap", marginBottom: 32 }}>
              {[
                { icon: "📋", title: "The Job Board", desc: "Vetted casting directors from major studios post roles exclusively to APEX talent." },
                { icon: "🛡️", title: "Apex-Verified Filter", desc: "Directors set minimum Pro Scores and require verified skills — only qualified actors appear." },
                { icon: "🤖", title: "Matchmaker AI", desc: "Upload a script. AI scans character breakdowns and notifies the Top 5% of matching actors." },
              ].map(item => (
                <div key={item.title} style={{ flex: 1, minWidth: 200 }}>
                  <div style={{ fontSize: 28, marginBottom: 8 }}>{item.icon}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: BRAND.text, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>{item.title}</div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted, lineHeight: 1.6 }}>{item.desc}</div>
                </div>
              ))}
            </div>

            <div style={{
              padding: 24, borderRadius: 16, background: BRAND.surface, border: `1px solid ${BRAND.border}`,
            }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: BRAND.text, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>
                🎬 Are you a Casting Director, Agent, or Production House?
              </div>
              <div style={{ fontSize: 13, color: BRAND.textMuted, marginBottom: 16, lineHeight: 1.6 }}>
                Join the early access list for the APEX Market. Get first access to post roles, use Matchmaker AI, and browse the industry's first AI-verified talent pool.
              </div>
              {waitlistStatus === "success" ? (
                <div style={{ padding: "20px 0", textAlign: "center" }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>✅</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: BRAND.accent, fontFamily: "'Outfit', sans-serif", marginBottom: 4 }}>You're on the list!</div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted }}>We'll notify you at <strong style={{ color: BRAND.text }}>{waitlistEmail}</strong> when the APEX Market launches.</div>
                </div>
              ) : (
                <>
                  <div style={{ display: "flex", gap: 8 }}>
                    <input value={waitlistEmail} onChange={e => { setWaitlistEmail(e.target.value); setWaitlistStatus(""); }} placeholder="your@studio.com" style={{
                      flex: 1, background: BRAND.bg, border: `1px solid ${waitlistStatus === "error" ? BRAND.primary : BRAND.border}`, borderRadius: 10,
                      padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif", outline: "none",
                    }} />
                    <GlowButton onClick={() => {
                      if (!waitlistEmail || !waitlistEmail.includes("@") || !waitlistEmail.includes(".")) { setWaitlistStatus("error"); return; }
                      setWaitlistStatus("success");
                    }}>Join Waitlist →</GlowButton>
                  </div>
                  {waitlistStatus === "error" && <div style={{ marginTop: 6, fontSize: 12, color: BRAND.primary }}>Please enter a valid email address.</div>}
                  <div style={{ marginTop: 10, fontSize: 11, color: BRAND.textDim }}>We'll email you when the APEX Market launches. No spam.</div>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{
        padding: "100px 32px", textAlign: "center", position: "relative", overflow: "hidden",
      }}>
        <div style={{
          position: "absolute", inset: 0, background: BRAND.meshGradient, pointerEvents: "none",
        }} />
        <div style={{ position: "relative", zIndex: 1 }}>
          <h2 style={{ fontSize: 44, fontWeight: 900, margin: "0 0 16px", color: BRAND.text, fontFamily: "'Outfit', sans-serif", letterSpacing: "-1px" }}>
            Ready to Level Up?
          </h2>
          <p style={{ color: BRAND.textMuted, fontSize: 18, margin: "0 0 36px", fontWeight: 300 }}>
            Try it free for 3 days — no credit card required.
          </p>
          <GlowButton size="lg" onClick={openSignup}>Start 3-Day Free Trial →</GlowButton>
          <div style={{ marginTop: 20, fontSize: 13, color: BRAND.textDim, letterSpacing: "0.5px" }}>
            No contracts · Cancel anytime · {isFounderPricing ? "$1.99/mo Founder's Price" : "$4.99/mo"} after trial
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: "48px 32px", borderTop: `1px solid ${BRAND.border}`, textAlign: "center" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 12 }}>
          <div style={{ width: 24, height: 24, borderRadius: 7, background: BRAND.gradient, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 12, color: "#fff", fontFamily: "'Outfit', sans-serif" }}>A</div>
          <span style={{ fontWeight: 700, fontSize: 14, color: BRAND.textDim, fontFamily: "'Outfit', sans-serif", letterSpacing: "2px" }}>APEX PERFORM</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, flexWrap: "wrap" }}>
          <span style={{ fontSize: 12, color: BRAND.textDim }}>© 2026 APEX PERFORM Inc.</span>
          <span style={{ fontSize: 12, color: BRAND.border }}>·</span>
          <button onClick={() => setPage(PAGES.FOUNDER)} style={{ background: "none", border: "none", fontSize: 12, color: BRAND.primary, cursor: "pointer", fontWeight: 600, fontFamily: "'Outfit', sans-serif" }}>Created by Armaan Juneja, age 11 🚀</button>
          <span style={{ fontSize: 12, color: BRAND.border }}>·</span>
          <span style={{ fontSize: 12, color: BRAND.textDim }}>Built by actors, for actors.</span>
        </div>
      </footer>
    </div>
  );
};

// ─── DASHBOARD ───
const DashboardPage = ({ setPage, stats, username }) => (
  <div style={{ padding: "32px", maxWidth: 1100, margin: "0 auto" }}>
    <div style={{ marginBottom: 32 }}>
      <h1 style={{ margin: "0 0 8px", fontSize: 32, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
        Welcome back{username ? `, @${username}` : ""} 👋
      </h1>
      <p style={{ margin: 0, color: BRAND.textMuted, fontSize: 15 }}>Here's your performance overview.</p>
    </div>

    <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 32 }}>
      <StatCard icon="🎬" value={String(stats.auditions)} label="Auditions Scored" />
      <StatCard icon="📈" value={stats.lastScore ? String(stats.lastScore) : "—"} label="Pro Score" />
      <StatCard icon="🔥" value={String(stats.dojoStreak)} label="Dojo Streak" />
      <StatCard icon="⭐" value={stats.dojoXp > 0 ? String(stats.dojoXp) : "0"} label="Dojo XP" />
    </div>

    <div style={{ display: "flex", gap: 24, flexWrap: "wrap", marginBottom: 32 }}>
      <Card glow onClick={() => setPage(PAGES.COACH)} style={{ flex: 1, minWidth: 250, cursor: "pointer" }}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>🎬</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>AI Audition Coach</h3>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>Upload a self-tape and get instant AI feedback on eye contact, pacing, and expression.</p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 14, fontFamily: "'Outfit', sans-serif" }}>Start Analysis →</span>
      </Card>
      <Card glow onClick={() => setPage(PAGES.RESUME)} style={{ flex: 1, minWidth: 250, cursor: "pointer" }}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>📝</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>AI Resume Architect</h3>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>Transform your skills into professional casting language and generate your digital portfolio.</p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 14, fontFamily: "'Outfit', sans-serif" }}>Build Resume →</span>
      </Card>
      <Card glow onClick={() => setPage(PAGES.DOJO)} style={{ flex: 1, minWidth: 250, cursor: "pointer" }}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>🥋</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Daily Dojo</h3>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>New acting challenge every day. Score high to earn XP and climb the global leaderboard.</p>
        <span style={{ color: BRAND.gold, fontWeight: 700, fontSize: 14, fontFamily: "'Outfit', sans-serif" }}>🔥 Today's Challenge →</span>
      </Card>
    </div>

    <div style={{ display: "flex", gap: 20, flexWrap: "wrap", marginBottom: 32 }}>
      <Card glow onClick={() => setPage(PAGES.ANALYTICS)} style={{ flex: 1, minWidth: 200, cursor: "pointer" }}>
        <div style={{ fontSize: 28, marginBottom: 8 }}>📊</div>
        <h3 style={{ margin: "0 0 6px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Audition Analytics</h3>
        <p style={{ margin: 0, fontSize: 13, color: BRAND.textMuted, lineHeight: 1.5 }}>Track your booking rate and find career patterns.</p>
      </Card>
      <Card glow onClick={() => setPage(PAGES.INSIGHTS)} style={{ flex: 1, minWidth: 200, cursor: "pointer" }}>
        <div style={{ fontSize: 28, marginBottom: 8 }}>👁️</div>
        <h3 style={{ margin: "0 0 6px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Talent Insights</h3>
        <p style={{ margin: 0, fontSize: 13, color: BRAND.textMuted, lineHeight: 1.5 }}>See who's viewing your profile and reels.</p>
      </Card>
      <Card glow onClick={() => setPage(PAGES.HEADSHOTS)} style={{ flex: 1, minWidth: 200, cursor: "pointer" }}>
        <div style={{ fontSize: 28, marginBottom: 8 }}>📸</div>
        <h3 style={{ margin: "0 0 6px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Headshot Ranker</h3>
        <p style={{ margin: 0, fontSize: 13, color: BRAND.textMuted, lineHeight: 1.5 }}>AI ranks and tags your headshots by archetype.</p>
      </Card>
      <Card glow onClick={() => setPage(PAGES.HALL_OF_FAME)} style={{ flex: 1, minWidth: 200, cursor: "pointer" }}>
        <div style={{ fontSize: 28, marginBottom: 8 }}>🏆</div>
        <h3 style={{ margin: "0 0 6px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Hall of Fame</h3>
        <p style={{ margin: 0, fontSize: 13, color: BRAND.textMuted, lineHeight: 1.5 }}>Weekly leaderboard — top avg Pro Score wins.</p>
      </Card>
    </div>

    {/* Empty State or Recent Score */}
    {stats.auditions === 0 ? (
      <Card style={{ marginBottom: 32, textAlign: "center", padding: "48px 32px" }}>
        <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.7 }}>🎬</div>
        <h3 style={{ margin: "0 0 10px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>No auditions scored yet</h3>
        <p style={{ margin: "0 0 24px", color: BRAND.textMuted, fontSize: 14, maxWidth: 400, marginLeft: "auto", marginRight: "auto", lineHeight: 1.7 }}>
          Upload your first self-tape to the AI Audition Coach and your Pro Score will appear here.
        </p>
        <GlowButton onClick={() => setPage(PAGES.COACH)}>Score My First Audition →</GlowButton>
      </Card>
    ) : (
      <Card style={{ marginBottom: 32, padding: "32px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 20 }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 2, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>LATEST PRO SCORE</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <span style={{ fontSize: 48, fontWeight: 800, color: stats.lastScore >= 80 ? BRAND.accent : stats.lastScore >= 60 ? BRAND.gold : BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>{stats.lastScore}</span>
            <span style={{ fontSize: 14, color: BRAND.textMuted }}>/ 100</span>
          </div>
          <div style={{ fontSize: 13, color: BRAND.textMuted, marginTop: 4 }}>{stats.auditions} audition{stats.auditions !== 1 ? "s" : ""} scored total</div>
        </div>
        <GlowButton onClick={() => setPage(PAGES.COACH)}>Score Another →</GlowButton>
      </Card>
    )}
  </div>
);

// ─── AI AUDITION COACH ───
const CoachPage = ({ setPage, onAuditionScored }) => {
  const [stage, setStage] = useState("upload"); // upload, describe, analyzing, results, error
  const [fileName, setFileName] = useState("");
  const [sceneDesc, setSceneDesc] = useState("");
  const [results, setResults] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef(null);

  const handleFile = (file) => {
    if (file) { setFileName(file.name); setStage("describe"); }
  };

  const handleFileSelect = (e) => { const f = e.target.files?.[0]; if (f) handleFile(f); };
  const handleDrop = (e) => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files?.[0]; if (f) handleFile(f); };

  const analyzePerformance = async () => {
    if (!sceneDesc.trim()) return;
    setStage("analyzing");

    const prompt = `You are an elite acting coach analyzing a self-tape audition.

FILE: ${fileName}
ACTOR'S SCENE DESCRIPTION: ${sceneDesc}

Based on the actor's description of their performance, give a thorough, realistic coaching analysis. Be specific and actionable. Vary your scores — don't just give everything 80s. Be honest: if the description suggests struggle, score lower. If it sounds strong, score higher.

Respond ONLY with a JSON object (no markdown, no backticks):
{
  "overallScore": <number 40-98, be realistic and varied>,
  "eyeContact": <number 40-98>,
  "pacing": <number 40-98>,
  "expression": <number 40-98>,
  "label": "<one of: Exceptional Performance, Excellent Performance, Strong Performance, Good Performance, Developing, Needs Work>",
  "tips": [
    { "icon": "👁️", "title": "<specific eye contact coaching point>", "text": "<detailed actionable tip based on what they described>" },
    { "icon": "🎭", "title": "<specific expression/emotion coaching point>", "text": "<detailed actionable tip>" },
    { "icon": "⏱️", "title": "<specific pacing/delivery coaching point>", "text": "<detailed actionable tip>" }
  ],
  "stats": {
    "emotionsDetected": <number 1-8 based on scene complexity>,
    "keyMoments": <number 2-10>
  }
}`;

    const raw = await callClaudeAPI(
      "You are an expert acting coach for APEX PERFORM. Give honest, specific, actionable coaching. Always respond with valid JSON only. No markdown.",
      prompt
    );

    if (raw) {
      const parsed = parseJSON(raw);
      if (parsed && parsed.overallScore) {
        setResults(parsed);
        onAuditionScored(parsed.overallScore);
        setStage("results");
        return;
      }
    }
    setErrorMsg("AI analysis failed. Please try again.");
    setStage("error");
  };

  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <button onClick={() => setPage(PAGES.DASHBOARD)} style={{
        background: "transparent", border: "none", color: BRAND.textMuted, cursor: "pointer",
        fontSize: 14, fontFamily: "'Outfit', sans-serif", marginBottom: 24, padding: 0,
      }}>← Back to Dashboard</button>

      <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
        🎬 AI Audition Coach
      </h1>
      <p style={{ margin: "0 0 32px", color: BRAND.textMuted, fontSize: 15 }}>Upload your self-tape and get real AI-powered coaching feedback.</p>

      <input ref={fileRef} type="file" accept="video/*,.mp4,.mov,.webm,.avi,.mkv" onChange={handleFileSelect} style={{ display: "none" }} />

      {stage === "upload" && (
        <Card style={{
          border: `2px dashed ${dragOver ? BRAND.primary : BRAND.border}`,
          background: dragOver ? BRAND.primary + "08" : BRAND.card,
          textAlign: "center", padding: "60px 32px", transition: "all 0.3s",
        }}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
        >
          <div style={{ fontSize: 56, marginBottom: 20 }}>🎥</div>
          <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
            Drop your self-tape here
          </h3>
          <p style={{ margin: "0 0 24px", color: BRAND.textMuted, fontSize: 14 }}>
            MP4, MOV, or WebM · Max 5 minutes
          </p>
          <GlowButton onClick={() => fileRef.current?.click()}>Choose File</GlowButton>
        </Card>
      )}

      {stage === "describe" && (
        <Card style={{ padding: "36px 32px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
            <span style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>📎 {fileName}</span>
          </div>
          <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
            Tell the AI about your scene
          </h3>
          <p style={{ margin: "0 0 20px", color: BRAND.textMuted, fontSize: 14, lineHeight: 1.6 }}>
            Describe what you performed so our AI coach can give you specific, personalized feedback. The more detail you give, the better the coaching.
          </p>
          <textarea
            value={sceneDesc}
            onChange={(e) => setSceneDesc(e.target.value)}
            placeholder={"Example: I performed a dramatic monologue from a crime drama. I played a detective confronting a suspect. I tried to build tension with pauses but I think I rushed the emotional climax. I maintained eye contact with the camera most of the time but looked away during the harder lines. About 2 minutes long."}
            rows={5}
            style={{
              width: "100%", boxSizing: "border-box", background: BRAND.surface, border: `1px solid ${BRAND.border}`,
              borderRadius: 12, padding: "14px 16px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif",
              resize: "vertical", outline: "none", lineHeight: 1.7,
            }}
          />
          <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
            <GlowButton onClick={analyzePerformance} disabled={!sceneDesc.trim()}>Analyze My Performance →</GlowButton>
            <GlowButton variant="ghost" onClick={() => { setStage("upload"); setFileName(""); setSceneDesc(""); if(fileRef.current) fileRef.current.value=""; }}>← Change File</GlowButton>
          </div>
        </Card>
      )}

      {stage === "analyzing" && (
        <Card style={{ textAlign: "center", padding: "60px 32px" }}>
          <div style={{ fontSize: 48, marginBottom: 20, animation: "pulse 1.5s ease-in-out infinite" }}>🧠</div>
          <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
            AI Coach is analyzing your performance...
          </h3>
          <p style={{ margin: "0 0 8px", color: BRAND.textMuted, fontSize: 14 }}>
            Generating personalized coaching based on your scene.
          </p>
          <p style={{ margin: "0 0 24px", color: BRAND.textDim, fontSize: 12 }}>📎 {fileName}</p>
          <div style={{ maxWidth: 300, margin: "0 auto", height: 6, borderRadius: 3, background: BRAND.border, overflow: "hidden" }}>
            <div style={{ height: "100%", borderRadius: 3, background: BRAND.gradient, width: "60%", animation: "pulse 1.5s ease-in-out infinite" }} />
          </div>
          <style>{`@keyframes pulse { 0%, 100% { transform: scale(1); opacity: 0.8; } 50% { transform: scale(1.05); opacity: 1; } }`}</style>
        </Card>
      )}

      {stage === "error" && (
        <Card style={{ textAlign: "center", padding: "48px 32px" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
          <h3 style={{ margin: "0 0 12px", fontSize: 20, fontWeight: 700, color: BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>{errorMsg}</h3>
          <GlowButton onClick={() => { setStage("describe"); setErrorMsg(""); }}>Try Again</GlowButton>
        </Card>
      )}

      {stage === "results" && results && (
        <>
          <Card style={{ textAlign: "center", padding: "40px 32px", marginBottom: 24 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 2, marginBottom: 16, fontFamily: "'Outfit', sans-serif" }}>YOUR PRO SCORE</div>
            <ScoreGauge score={results.overallScore} size={180} />
            <div style={{ marginTop: 8, fontSize: 14, color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>{results.label}</div>
          </Card>

          <div style={{ display: "flex", gap: 24, flexWrap: "wrap", marginBottom: 24 }}>
            <Card style={{ flex: 1, minWidth: 250 }}>
              <h3 style={{ margin: "0 0 20px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Dimension Breakdown</h3>
              <BarScore label="👁️ Eye Contact" score={results.eyeContact} delay={0} />
              <BarScore label="⏱️ Pacing" score={results.pacing} delay={150} />
              <BarScore label="🎭 Facial Expression" score={results.expression} delay={300} />
            </Card>
            <Card style={{ flex: 1, minWidth: 250 }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Session Stats</h3>
              <div style={{ display: "grid", gap: 12 }}>
                {[
                  ["File", fileName],
                  ["Eye Contact", `${results.eyeContact}%`],
                  ["Emotions Detected", String(results.stats?.emotionsDetected || "—")],
                  ["Key Moments", String(results.stats?.keyMoments || "—")],
                ].map(([l, v]) => (
                  <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${BRAND.border}` }}>
                    <span style={{ fontSize: 13, color: BRAND.textMuted }}>{l}</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{v}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <Card style={{ marginBottom: 24 }}>
            <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>🎯 AI Coaching Tips</h3>
            {(results.tips || []).map((tip, i) => (
              <div key={i} style={{
                padding: "16px", borderRadius: 12, background: BRAND.surface,
                border: `1px solid ${BRAND.border}`, marginBottom: i < (results.tips?.length || 0) - 1 ? 12 : 0,
                display: "flex", gap: 14, alignItems: "flex-start",
              }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: BRAND.primary + "15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>{tip.icon}</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: BRAND.text, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>{tip.title}</div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted, lineHeight: 1.7 }}>{tip.text}</div>
                </div>
              </div>
            ))}
          </Card>

          <div style={{ display: "flex", gap: 12 }}>
            <GlowButton onClick={() => { setStage("upload"); setFileName(""); setSceneDesc(""); setResults(null); if(fileRef.current) fileRef.current.value=""; }}>Analyze Another →</GlowButton>
          </div>
        </>
      )}
    </div>
  );
};

// ─── AI RESUME ARCHITECT ───
const FormField = ({ label, field, multiline, form, setForm, placeholder }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 6, fontFamily: "'Outfit', sans-serif" }}>{label}</label>
    {multiline ? (
      <textarea value={form[field]} onChange={e => setForm(prev => ({ ...prev, [field]: e.target.value }))}
        placeholder={placeholder || ""}
        rows={3} style={{
          width: "100%", boxSizing: "border-box", background: BRAND.surface, border: `1px solid ${BRAND.border}`,
          borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif",
          resize: "vertical", outline: "none",
        }} />
    ) : (
      <input value={form[field]} onChange={e => setForm(prev => ({ ...prev, [field]: e.target.value }))}
        placeholder={placeholder || ""}
        style={{
          width: "100%", boxSizing: "border-box", background: BRAND.surface, border: `1px solid ${BRAND.border}`,
          borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif",
          outline: "none",
        }} />
    )}
  </div>
);

const SkillField = ({ num, form, setForm, handleProofUpload }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 6, fontFamily: "'Outfit', sans-serif" }}>SKILL {num}</label>
    <div style={{ display: "flex", gap: 8 }}>
      <input value={form[`skill${num}`]} onChange={e => setForm(prev => ({ ...prev, [`skill${num}`]: e.target.value }))}
        placeholder="e.g. Taekwondo Black Belt"
        style={{
          flex: 1, boxSizing: "border-box", background: BRAND.surface, border: `1px solid ${BRAND.border}`,
          borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif",
          outline: "none",
        }} />
      <button onClick={() => handleProofUpload(num)} style={{
        background: form[`skill${num}Proof`] ? BRAND.accent + "20" : BRAND.surface,
        border: `1px solid ${form[`skill${num}Proof`] ? BRAND.accent + "60" : BRAND.border}`,
        borderRadius: 10, padding: "8px 14px", color: form[`skill${num}Proof`] ? BRAND.accent : BRAND.textDim,
        fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "'Outfit', sans-serif",
        whiteSpace: "nowrap", transition: "all 0.2s",
      }}>
        {form[`skill${num}Proof`] ? "✓ Verified" : "📎 Upload Proof"}
      </button>
    </div>
    {form[`skill${num}Proof`] && (
      <div style={{ marginTop: 6, fontSize: 11, color: BRAND.accent, display: "flex", alignItems: "center", gap: 4 }}>
        <span>📄 {form[`skill${num}Proof`]}</span>
        <button onClick={() => setForm(prev => ({ ...prev, [`skill${num}Proof`]: null }))} style={{
          background: "none", border: "none", color: BRAND.textDim, cursor: "pointer", fontSize: 11, padding: "0 4px",
        }}>✕</button>
      </div>
    )}
  </div>
);

const ResumePage = ({ setPage, onProfileBuilt, profileData }) => {
  const [step, setStep] = useState(profileData ? 2 : 0); // 0=form, 1=generating, 2=preview
  const [form, setForm] = useState(profileData?.form || {
    name: "",
    ageRange: "",
    ethnicity: "",
    location: "",
    headshot: null,      // { dataUrl, fileName }
    skill1: "",
    skill2: "",
    skill3: "",
    skill1Proof: null,
    skill2Proof: null,
    skill3Proof: null,
    training: "",
    experience: "",
    tiktok: "",
    youtube: "",
    instagram: "",
  });

  const [aiSkills, setAiSkills] = useState(profileData?.aiSkills || []);
  const [aiError, setAiError] = useState("");

  const generate = async () => {
    setStep(1);
    setAiError("");

    const skills = [form.skill1, form.skill2, form.skill3].filter(Boolean);
    if (skills.length === 0) {
      setAiSkills([]);
      setStep(2);
      return;
    }

    const prompt = `You are a professional casting director and talent resume writer for APEX PERFORM. Transform these raw actor skills into professional casting-industry language.

Actor Info:
- Name: ${form.name || "Unknown"}
- Age Range: ${form.ageRange || "Not specified"}
- Ethnicity: ${form.ethnicity || "Not specified"}
- Location: ${form.location || "Not specified"}
- Training: ${form.training || "None listed"}
- Experience: ${form.experience || "None listed"}

Raw Skills to Transform:
${skills.map((s, i) => `${i + 1}. ${s}`).join("\n")}

Respond ONLY with a JSON array (no markdown, no backticks). Each element should be:
{ "raw": "<original skill>", "pro": "<2-3 sentence professional casting language transformation. Be specific about how this skill applies to acting, stunts, commercial work, or on-camera performance. Make it sound impressive but truthful.>" }`;

    const raw = await callClaudeAPI(
      "You are an expert talent resume writer. Always respond with valid JSON only. No markdown. No backticks. Transform actor skills into professional casting-industry language.",
      prompt
    );

    if (raw) {
      const parsed = parseJSON(raw);
      if (Array.isArray(parsed)) {
        setAiSkills(parsed);
        onProfileBuilt(form, parsed);
        setStep(2);
        return;
      }
    }

    // Fallback if AI fails
    setAiError("AI transformation is temporarily unavailable. Showing your skills as entered.");
    const fallback = skills.map(s => ({ raw: s, pro: s }));
    setAiSkills(fallback);
    onProfileBuilt(form, fallback);
    setStep(2);
  };

  const handleProofUpload = (skillNum) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*,.pdf";
    input.onchange = (e) => {
      const file = e.target.files?.[0];
      if (file) setForm(prev => ({ ...prev, [`skill${skillNum}Proof`]: file.name }));
    };
    input.click();
  };

  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <button onClick={() => setPage(PAGES.DASHBOARD)} style={{
        background: "transparent", border: "none", color: BRAND.textMuted, cursor: "pointer",
        fontSize: 14, fontFamily: "'Outfit', sans-serif", marginBottom: 24, padding: 0,
      }}>← Back to Dashboard</button>

      <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
        📝 AI Resume Architect
      </h1>
      <p style={{ margin: "0 0 32px", color: BRAND.textMuted, fontSize: 15 }}>Transform your skills into Hollywood-grade professional language.</p>

      {step === 0 && (
        <Card>
          <h3 style={{ margin: "0 0 20px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Tell us about yourself</h3>

          {/* Headshot Upload */}
          <div style={{ display: "flex", gap: 24, marginBottom: 24, alignItems: "flex-start" }}>
            <div style={{ flexShrink: 0 }}>
              <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>HEADSHOT</label>
              <div onClick={() => {
                const inp = document.createElement("input");
                inp.type = "file"; inp.accept = "image/*";
                inp.onchange = (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = (ev) => setForm(prev => ({ ...prev, headshot: { dataUrl: ev.target.result, fileName: file.name } }));
                  reader.readAsDataURL(file);
                };
                inp.click();
              }} style={{
                width: 120, height: 150, borderRadius: 14, cursor: "pointer", overflow: "hidden",
                background: form.headshot ? "none" : BRAND.surface, border: `2px dashed ${form.headshot ? BRAND.accent : BRAND.border}`,
                display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 6, transition: "all 0.2s",
              }}>
                {form.headshot ? (
                  <img src={form.headshot.dataUrl} alt="Headshot" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                ) : (
                  <>
                    <span style={{ fontSize: 28, opacity: 0.5 }}>📸</span>
                    <span style={{ fontSize: 11, color: BRAND.textDim, textAlign: "center", padding: "0 8px" }}>Click to upload</span>
                  </>
                )}
              </div>
              {form.headshot && (
                <button onClick={() => setForm(prev => ({ ...prev, headshot: null }))} style={{
                  display: "block", margin: "6px auto 0", background: "none", border: "none", color: BRAND.textDim, fontSize: 11, cursor: "pointer", fontFamily: "'Outfit', sans-serif",
                }}>✕ Remove</button>
              )}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 20px" }}>
                <FormField label="FULL NAME" field="name" form={form} setForm={setForm} placeholder="Your full name" />
                <FormField label="AGE RANGE" field="ageRange" form={form} setForm={setForm} placeholder="e.g. 25-30" />
                <FormField label="ETHNICITY" field="ethnicity" form={form} setForm={setForm} placeholder="e.g. African American, Caucasian, Latino, Asian, Mixed" />
                <FormField label="LOCATION" field="location" form={form} setForm={setForm} placeholder="e.g. Los Angeles, CA" />
              </div>
            </div>
          </div>
          <h4 style={{ margin: "12px 0 6px", fontSize: 14, fontWeight: 700, color: BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>✦ Special Skills (the AI magic happens here)</h4>
          <p style={{ margin: "0 0 16px", fontSize: 12, color: BRAND.textDim }}>Upload proof (certificate, screenshot, award) to earn a <span style={{ color: BRAND.accent, fontWeight: 700 }}>Verified by APEX ✓</span> badge on your profile.</p>
          <SkillField num={1} form={form} setForm={setForm} handleProofUpload={handleProofUpload} />
          <SkillField num={2} form={form} setForm={setForm} handleProofUpload={handleProofUpload} />
          <SkillField num={3} form={form} setForm={setForm} handleProofUpload={handleProofUpload} />
          <FormField label="TRAINING & EDUCATION" field="training" form={form} setForm={setForm} multiline placeholder="e.g. UCLA School of Theater, Meisner Technique Intensive" />
          <FormField label="ACTING EXPERIENCE" field="experience" form={form} setForm={setForm} multiline placeholder="e.g. Lead in 'The Glass Menagerie' — Community Playhouse 2024" />
          <h4 style={{ margin: "12px 0 16px", fontSize: 14, fontWeight: 700, color: BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>🔗 Social Media (optional)</h4>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0 20px" }}>
            <FormField label="TIKTOK" field="tiktok" form={form} setForm={setForm} placeholder="@username" />
            <FormField label="YOUTUBE" field="youtube" form={form} setForm={setForm} placeholder="Channel name or URL" />
            <FormField label="INSTAGRAM" field="instagram" form={form} setForm={setForm} placeholder="@username" />
          </div>
          <div style={{ marginTop: 8 }}>
            <GlowButton onClick={generate}>Generate My Portfolio →</GlowButton>
          </div>
        </Card>
      )}

      {step === 1 && (
        <Card style={{ textAlign: "center", padding: "60px 32px" }}>
          <div style={{ fontSize: 48, marginBottom: 20, animation: "pulse 1.5s ease-in-out infinite" }}>✨</div>
          <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
            Building Your Professional Portfolio...
          </h3>
          <p style={{ color: BRAND.textMuted, fontSize: 14, margin: "0 0 8px" }}>
            AI is transforming your skills into Hollywood-grade language.
          </p>
          <style>{`@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }`}</style>
        </Card>
      )}

      {step === 2 && (
        <>
          <Card style={{ marginBottom: 20, padding: "12px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", background: BRAND.accent + "10", border: `1px solid ${BRAND.accent}30` }}>
            <span style={{ fontSize: 14, color: BRAND.accent, fontWeight: 600, fontFamily: "'Outfit', sans-serif" }}>✓ Portfolio generated! Share your link: apexperform.com/{form.name.toLowerCase()}</span>
            <GlowButton size="sm" onClick={() => setPage(PAGES.PROFILE)}>View Profile →</GlowButton>
          </Card>

          <Card style={{ marginBottom: 24 }}>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{
                width: 100, height: 120, borderRadius: 14, margin: "0 auto 16px", overflow: "hidden",
                background: form.headshot ? "none" : BRAND.gradient,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 44, fontWeight: 800, color: "#fff", fontFamily: "'Outfit', sans-serif",
                boxShadow: `0 8px 32px ${BRAND.primaryGlow}`,
              }}>
                {form.headshot ? (
                  <img src={form.headshot.dataUrl} alt="Headshot" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                ) : form.name.charAt(0)}
              </div>
              <h2 style={{ margin: "0 0 4px", fontSize: 24, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{form.name}</h2>
              <div style={{ fontSize: 14, color: BRAND.textMuted }}>{[form.ageRange, form.ethnicity, form.location].filter(Boolean).join(" · ")}</div>
            </div>

            <div style={{ marginBottom: 24 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                <h4 style={{ fontSize: 12, fontWeight: 700, letterSpacing: 2, color: BRAND.primary, margin: 0, fontFamily: "'Outfit', sans-serif" }}>SPECIAL SKILLS — AI ENHANCED</h4>
                {(form.skill1Proof || form.skill2Proof || form.skill3Proof) && (
                  <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 6, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif", border: `1px solid ${BRAND.accent}40` }}>✓ Verified by APEX</span>
                )}
              </div>
              {aiError && <div style={{ padding: 12, borderRadius: 8, background: BRAND.gold + "10", border: `1px solid ${BRAND.gold}30`, marginBottom: 12, fontSize: 12, color: BRAND.gold }}>{aiError}</div>}
              {aiSkills.map((s, i) => {
                const proofKey = `skill${i + 1}Proof`;
                const hasProof = form[proofKey];
                return (
                  <div key={i} style={{ padding: 16, borderRadius: 12, background: BRAND.surface, border: `1px solid ${hasProof ? BRAND.accent + "40" : BRAND.border}`, marginBottom: 10 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                      <span style={{ fontSize: 11, padding: "3px 8px", borderRadius: 6, background: BRAND.primary + "20", color: BRAND.primary, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>RAW</span>
                      <span style={{ fontSize: 13, color: BRAND.textMuted }}>{s.raw}</span>
                      {hasProof && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, marginLeft: "auto" }}>✓ VERIFIED</span>}
                    </div>
                    <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
                      <span style={{ fontSize: 11, padding: "3px 8px", borderRadius: 6, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif", flexShrink: 0, marginTop: 2 }}>PRO</span>
                      <span style={{ fontSize: 13, color: BRAND.text, lineHeight: 1.7 }}>{s.pro}</span>
                    </div>
                  </div>
                );
              })}
              {aiSkills.length === 0 && !aiError && (
                <div style={{ padding: 16, borderRadius: 12, background: BRAND.surface, border: `1px dashed ${BRAND.border}`, textAlign: "center" }}>
                  <span style={{ fontSize: 13, color: BRAND.textDim }}>No skills entered. Go back to add your skills.</span>
                </div>
              )}
            </div>

            {form.training && <div style={{ marginBottom: 24 }}>
              <h4 style={{ fontSize: 12, fontWeight: 700, letterSpacing: 2, color: BRAND.primary, margin: "0 0 12px", fontFamily: "'Outfit', sans-serif" }}>TRAINING</h4>
              <div style={{ fontSize: 14, color: BRAND.textMuted, lineHeight: 1.8 }}>{form.training}</div>
            </div>}

            {(form.tiktok || form.youtube || form.instagram) && <div style={{ marginBottom: 24 }}>
              <h4 style={{ fontSize: 12, fontWeight: 700, letterSpacing: 2, color: BRAND.primary, margin: "0 0 12px", fontFamily: "'Outfit', sans-serif" }}>SOCIAL MEDIA</h4>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                {form.tiktok && <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}`, fontSize: 13, color: BRAND.text }}>🎵 TikTok: {form.tiktok}</div>}
                {form.youtube && <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}`, fontSize: 13, color: BRAND.text }}>▶️ YouTube: {form.youtube}</div>}
                {form.instagram && <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}`, fontSize: 13, color: BRAND.text }}>📸 Instagram: {form.instagram}</div>}
              </div>
            </div>}
          </Card>

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <GlowButton onClick={() => setStep(0)}>Edit Information</GlowButton>
            <GlowButton variant="ghost" onClick={() => setPage(PAGES.PROFILE)}>View Public Profile</GlowButton>
            <GlowButton variant="ghost" onClick={() => {}}>Download PDF</GlowButton>
          </div>
        </>
      )}
    </div>
  );
};

// ─── DAILY DOJO ───
const DojoPage = ({ setPage, onDojoCompleted, stats }) => {
  const [dojoState, setDojoState] = useState("challenge"); // challenge, describe, scoring, result, error
  const [dojoScore, setDojoScore] = useState(null);
  const [xpEarned, setXpEarned] = useState(0);
  const [dojoFeedback, setDojoFeedback] = useState("");
  const [dojoDesc, setDojoDesc] = useState("");
  const [dojoFileName, setDojoFileName] = useState("");
  const [tab, setTab] = useState("challenge"); // challenge, leaderboard
  const fileRef = useRef(null);

  const todayIndex = new Date().getDay() % DAILY_CHALLENGES.length;
  const challenge = DAILY_CHALLENGES[todayIndex];

  const handleFileSelect = (e) => {
    const file = e?.target?.files?.[0];
    if (file) { setDojoFileName(file.name); setDojoState("describe"); }
  };

  const submitChallenge = async () => {
    if (!dojoDesc.trim()) return;
    setDojoState("scoring");

    const prompt = `You are scoring a Daily Dojo acting challenge submission for APEX PERFORM.

CHALLENGE: "${challenge.title}"
CHALLENGE DESCRIPTION: "${challenge.desc}"
FOCUS AREA: ${challenge.focus}
MAX XP: ${challenge.xp}

ACTOR'S DESCRIPTION OF THEIR TAKE: ${dojoDesc}

Score this honestly based on how well they addressed the specific challenge. Respond ONLY with JSON (no markdown):
{
  "score": <number 30-98, be honest and varied based on their description>,
  "feedback": "<2-3 sentences of specific, encouraging coaching feedback about how they performed THIS challenge. Reference the challenge focus area.>"
}`;

    const raw = await callClaudeAPI(
      "You are a tough but encouraging acting coach for the APEX PERFORM Daily Dojo. Score honestly. Always respond with valid JSON only.",
      prompt
    );

    if (raw) {
      const parsed = parseJSON(raw);
      if (parsed && parsed.score) {
        const score = Math.min(100, Math.max(0, parsed.score));
        const xp = score >= 85 ? challenge.xp : Math.floor(challenge.xp * 0.6);
        setDojoScore(score);
        setXpEarned(xp);
        setDojoFeedback(parsed.feedback || "");
        onDojoCompleted(xp);
        setDojoState("result");
        return;
      }
    }

    setDojoFeedback("AI scoring failed. Please try again.");
    setDojoState("error");
  };

  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
        <div>
          <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
            🥋 Daily Dojo
          </h1>
          <p style={{ margin: 0, color: BRAND.textMuted, fontSize: 15 }}>Complete daily challenges. Earn XP. Climb the leaderboard.</p>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 28, fontWeight: 800, color: BRAND.gold, fontFamily: "'Outfit', sans-serif" }}>{stats.dojoXp} XP</div>
          <div style={{ fontSize: 12, color: BRAND.textDim }}>Your Total</div>
        </div>
      </div>

      {/* Tab Switcher */}
      <div style={{ display: "flex", gap: 4, marginBottom: 24, background: BRAND.surface, borderRadius: 12, padding: 4, border: `1px solid ${BRAND.border}` }}>
        {[{ id: "challenge", label: "Today's Challenge" }, { id: "leaderboard", label: "Global Leaderboard" }].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, padding: "10px 16px", borderRadius: 10, border: "none", cursor: "pointer",
            background: tab === t.id ? BRAND.gradient : "transparent",
            color: tab === t.id ? "#fff" : BRAND.textMuted,
            fontSize: 14, fontWeight: 700, fontFamily: "'Outfit', sans-serif", transition: "all 0.2s",
          }}>{t.label}</button>
        ))}
      </div>

      <input ref={fileRef} type="file" accept="video/*,.mp4,.mov,.webm,.avi,.mkv" onChange={handleFileSelect} style={{ display: "none" }} />

      {tab === "challenge" && (
        <>
          {dojoState === "challenge" && (
            <Card style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ padding: "32px 32px 20px", background: `linear-gradient(135deg, ${BRAND.primary}15 0%, ${BRAND.card} 100%)` }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                  <span style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, background: BRAND.gold + "20", color: BRAND.gold, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>TODAY'S CHALLENGE</span>
                  <span style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>+{challenge.xp} XP</span>
                  <span style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, background: BRAND.primary + "20", color: BRAND.primary, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>Focus: {challenge.focus}</span>
                </div>
                <h2 style={{ margin: "0 0 12px", fontSize: 26, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{challenge.title}</h2>
                <p style={{ margin: 0, fontSize: 16, color: BRAND.textMuted, lineHeight: 1.7 }}>{challenge.desc}</p>
              </div>
              <div style={{ padding: "24px 32px", borderTop: `1px solid ${BRAND.border}`, display: "flex", gap: 12, alignItems: "center" }}>
                <GlowButton onClick={() => fileRef.current?.click()}>🎥 Upload Your Take</GlowButton>
                <span style={{ fontSize: 13, color: BRAND.textDim }}>Record your challenge, then upload to earn XP</span>
              </div>
            </Card>
          )}

          {dojoState === "describe" && (
            <Card style={{ padding: "36px 32px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, background: BRAND.gold + "20", color: BRAND.gold, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>{challenge.title}</span>
                <span style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>📎 {dojoFileName}</span>
              </div>
              <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>How did your take go?</h3>
              <p style={{ margin: "0 0 16px", color: BRAND.textMuted, fontSize: 14, lineHeight: 1.6 }}>
                Briefly describe your performance so the AI coach can score your challenge.
              </p>
              <textarea
                value={dojoDesc}
                onChange={(e) => setDojoDesc(e.target.value)}
                placeholder={`Example: I held a 4-second pause after the line and maintained eye contact the whole time. I think my facial expression could have been more intense during the pause.`}
                rows={4}
                style={{
                  width: "100%", boxSizing: "border-box", background: BRAND.surface, border: `1px solid ${BRAND.border}`,
                  borderRadius: 12, padding: "14px 16px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif",
                  resize: "vertical", outline: "none", lineHeight: 1.7,
                }}
              />
              <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
                <GlowButton onClick={submitChallenge} disabled={!dojoDesc.trim()}>Submit for Scoring →</GlowButton>
                <GlowButton variant="ghost" onClick={() => { setDojoState("challenge"); setDojoFileName(""); setDojoDesc(""); if(fileRef.current) fileRef.current.value=""; }}>← Back</GlowButton>
              </div>
            </Card>
          )}

          {dojoState === "scoring" && (
            <Card style={{ textAlign: "center", padding: "60px 32px" }}>
              <div style={{ fontSize: 48, marginBottom: 20, animation: "pulse 1.5s ease-in-out infinite" }}>🥋</div>
              <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
                Scoring Your Challenge...
              </h3>
              <p style={{ color: BRAND.textMuted, fontSize: 14, margin: "0 0 24px" }}>
                AI is evaluating your {challenge.focus.toLowerCase()} performance.
              </p>
              <div style={{ maxWidth: 300, margin: "0 auto", height: 6, borderRadius: 3, background: BRAND.border, overflow: "hidden" }}>
                <div style={{ height: "100%", borderRadius: 3, background: BRAND.gradient, width: "70%", animation: "pulse 1s ease-in-out infinite" }} />
              </div>
              <style>{`@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }`}</style>
            </Card>
          )}

          {dojoState === "error" && (
            <Card style={{ textAlign: "center", padding: "48px 32px" }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
              <h3 style={{ margin: "0 0 12px", fontSize: 20, fontWeight: 700, color: BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>{dojoFeedback}</h3>
              <GlowButton onClick={() => { setDojoState("challenge"); if(fileRef.current) fileRef.current.value=""; }}>Try Again</GlowButton>
            </Card>
          )}

          {dojoState === "result" && (
            <Card style={{ textAlign: "center", padding: "48px 32px" }}>
              <div style={{ fontSize: 56, marginBottom: 16 }}>{dojoScore >= 85 ? "🔥" : "💪"}</div>
              <h2 style={{ margin: "0 0 8px", fontSize: 32, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
                Challenge Score: <span style={{ color: dojoScore >= 85 ? BRAND.accent : BRAND.gold }}>{dojoScore}</span>
              </h2>
              <p style={{ margin: "0 0 16px", fontSize: 16, color: BRAND.textMuted }}>
                {dojoScore >= 85 ? "Amazing! Full XP earned." : "Good effort! Keep practicing for full XP."}
              </p>
              {dojoFeedback && (
                <div style={{ maxWidth: 500, margin: "0 auto 24px", padding: "16px 20px", borderRadius: 12, background: BRAND.surface, border: `1px solid ${BRAND.border}`, textAlign: "left" }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.primary, marginBottom: 6, fontFamily: "'Outfit', sans-serif" }}>🎯 AI COACH FEEDBACK</div>
                  <div style={{ fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>{dojoFeedback}</div>
                </div>
              )}
              <div style={{
                display: "inline-flex", alignItems: "center", gap: 8, padding: "12px 24px", borderRadius: 12,
                background: BRAND.gold + "15", border: `1px solid ${BRAND.gold}30`, marginBottom: 24,
              }}>
                <span style={{ fontSize: 24 }}>⭐</span>
                <span style={{ fontSize: 22, fontWeight: 800, color: BRAND.gold, fontFamily: "'Outfit', sans-serif" }}>+{xpEarned} XP</span>
              </div>
              <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
                <GlowButton onClick={() => { setDojoState("challenge"); setDojoScore(null); setDojoFeedback(""); if(fileRef.current) fileRef.current.value=""; }}>Back to Challenge</GlowButton>
                <GlowButton variant="ghost" onClick={() => setTab("leaderboard")}>View Leaderboard →</GlowButton>
              </div>
            </Card>
          )}

          {/* Upcoming Challenges Preview */}
          {dojoState === "challenge" && (
            <div style={{ marginTop: 24 }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.textDim, fontFamily: "'Outfit', sans-serif" }}>UPCOMING CHALLENGES</h3>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                {DAILY_CHALLENGES.filter((_, i) => i !== todayIndex).slice(0, 3).map((c, i) => (
                  <Card key={i} style={{ flex: 1, minWidth: 200, padding: 20, opacity: 0.6 }}>
                    <div style={{ fontSize: 11, color: BRAND.textDim, fontWeight: 700, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>+{c.xp} XP · {c.focus}</div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: BRAND.text, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>{c.title}</div>
                    <div style={{ fontSize: 12, color: BRAND.textDim }}>{c.desc.substring(0, 60)}...</div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {tab === "leaderboard" && (
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "24px 28px 16px", borderBottom: `1px solid ${BRAND.border}` }}>
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>🏆 Leaderboard</h3>
          </div>

          {stats.dojoXp > 0 ? (
            <>
              <div style={{
                display: "flex", alignItems: "center", gap: 16, padding: "20px 28px",
                background: BRAND.gold + "08", borderBottom: `1px solid ${BRAND.border}`,
              }}>
                <span style={{ fontSize: 24 }}>🥇</span>
                <div style={{
                  width: 44, height: 44, borderRadius: "50%", background: BRAND.gradient,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 18, fontWeight: 700, color: "#fff", fontFamily: "'Outfit', sans-serif",
                }}>Y</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>You</div>
                  <div style={{ fontSize: 12, color: BRAND.textDim }}>🔥 {stats.dojoStreak} day streak</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 20, fontWeight: 800, color: BRAND.gold, fontFamily: "'Outfit', sans-serif" }}>{stats.dojoXp.toLocaleString()}</div>
                  <div style={{ fontSize: 11, color: BRAND.textDim }}>XP</div>
                </div>
              </div>
              <div style={{ padding: "24px 28px", textAlign: "center" }}>
                <p style={{ margin: "0 0 8px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>
                  You're the first on the board! As more actors join APEX PERFORM and complete challenges, the leaderboard will fill up with real users.
                </p>
                <p style={{ margin: 0, fontSize: 12, color: BRAND.textDim }}>Keep completing daily challenges to hold your spot at the top.</p>
              </div>
            </>
          ) : (
            <div style={{ padding: "60px 32px", textAlign: "center" }}>
              <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.5 }}>🏆</div>
              <h3 style={{ margin: "0 0 10px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>No one on the board yet</h3>
              <p style={{ margin: "0 0 20px", color: BRAND.textMuted, fontSize: 14, lineHeight: 1.6, maxWidth: 400, marginLeft: "auto", marginRight: "auto" }}>
                Complete your first Daily Dojo challenge to be the first name on the leaderboard. Real users only — no fake accounts.
              </p>
              <GlowButton onClick={() => setTab("challenge")}>Take Today's Challenge →</GlowButton>
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

// ─── AI LAB ───
const AILabPage = ({ setPage }) => (
  <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
    <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
      ⚡ AI Lab
    </h1>
    <p style={{ margin: "0 0 32px", color: BRAND.textMuted, fontSize: 15 }}>Your elite AI tools — all in one place.</p>

    <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
      <Card glow onClick={() => setPage(PAGES.COACH)} style={{ flex: 1, minWidth: 260, cursor: "pointer", padding: 36 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🎬</div>
        <h2 style={{ margin: "0 0 10px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>AI Audition Coach</h2>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>
          Upload your self-tape and receive an instant Pro Score with personalized coaching tips.
        </p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>Launch Coach →</span>
      </Card>

      <Card glow onClick={() => setPage(PAGES.RESUME)} style={{ flex: 1, minWidth: 260, cursor: "pointer", padding: 36 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>📝</div>
        <h2 style={{ margin: "0 0 10px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>AI Resume Architect</h2>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>
          Transform raw skills into professional casting language with verified badges.
        </p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>Build Resume →</span>
      </Card>

      <Card glow onClick={() => setPage(PAGES.DOJO)} style={{ flex: 1, minWidth: 260, cursor: "pointer", padding: 36 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🥋</div>
        <h2 style={{ margin: "0 0 10px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Daily Dojo</h2>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>
          Daily acting challenges with AI scoring. Earn XP and build your streak.
        </p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>Enter Dojo →</span>
      </Card>
    </div>

    <div style={{ margin: "12px 0 8px" }}>
      <h2 style={{ fontSize: 20, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Business Intelligence</h2>
      <p style={{ margin: "4px 0 20px", color: BRAND.textDim, fontSize: 14 }}>Pro-level analytics and career tools for serious actors.</p>
    </div>

    <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
      <Card glow onClick={() => setPage(PAGES.ANALYTICS)} style={{ flex: 1, minWidth: 260, cursor: "pointer", padding: 36 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>📊</div>
        <h2 style={{ margin: "0 0 10px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Audition Analytics</h2>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>
          Track your audition-to-booking ratio. AI finds correlations between Pro Scores and successful bookings.
        </p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>View Analytics →</span>
      </Card>

      <Card glow onClick={() => setPage(PAGES.INSIGHTS)} style={{ flex: 1, minWidth: 260, cursor: "pointer", padding: 36 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>👁️</div>
        <h2 style={{ margin: "0 0 10px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Talent Insights</h2>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>
          See which casting directors viewed your profile, how long they watched your reel, and which sections they engaged with.
        </p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>View Insights →</span>
      </Card>

      <Card glow onClick={() => setPage(PAGES.HEADSHOTS)} style={{ flex: 1, minWidth: 260, cursor: "pointer", padding: 36 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>📸</div>
        <h2 style={{ margin: "0 0 10px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>AI Headshot Ranker</h2>
        <p style={{ margin: "0 0 16px", fontSize: 14, color: BRAND.textMuted, lineHeight: 1.7 }}>
          Upload multiple headshots. AI tags them with casting archetypes and ranks effectiveness by industry lighting and framing standards.
        </p>
        <span style={{ color: BRAND.primary, fontWeight: 700, fontSize: 15, fontFamily: "'Outfit', sans-serif" }}>Rank Headshots →</span>
      </Card>
    </div>
  </div>
);

// ─── AUDITION ANALYTICS DASHBOARD ───
const AnalyticsPage = ({ setPage, stats }) => {
  const [bookings, setBookings] = useState([]);
  const [bookingInput, setBookingInput] = useState({ role: "", project: "", date: "", scored: false, proScore: "" });
  const [aiInsight, setAiInsight] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const addBooking = () => {
    if (!bookingInput.role || !bookingInput.project) return;
    setBookings(prev => [...prev, { ...bookingInput, id: Date.now() }]);
    setBookingInput({ role: "", project: "", date: "", scored: false, proScore: "" });
  };

  const removeBooking = (id) => setBookings(prev => prev.filter(b => b.id !== id));

  const totalAuditions = stats.auditions + bookings.filter(b => !b.scored).length;
  const bookedCount = bookings.length;
  const ratio = totalAuditions > 0 ? ((bookedCount / totalAuditions) * 100).toFixed(1) : "0.0";

  const runAIAnalysis = async () => {
    if (bookings.length === 0) return;
    setAnalyzing(true);
    const prompt = `You are a talent analytics AI for APEX PERFORM. Analyze this actor's audition-to-booking data and find actionable patterns.

STATS:
- Total auditions scored by AI: ${stats.auditions}
- Latest AI Pro Score: ${stats.lastScore || "N/A"}
- Total bookings logged: ${bookings.length}
- Booking ratio: ${ratio}%

BOOKINGS:
${bookings.map((b, i) => `${i + 1}. Role: "${b.role}" — Project: "${b.project}" — Date: ${b.date || "N/A"} — Had AI coaching before: ${b.scored ? `Yes (score: ${b.proScore})` : "No"}`).join("\n")}

Respond ONLY with JSON (no markdown):
{
  "summary": "<2-3 sentence overall analysis of their career trajectory>",
  "bookingPattern": "<specific pattern you notice — which types of roles they book, timing, etc.>",
  "aiCorrelation": "<analysis of whether AI-coached auditions led to more bookings>",
  "recommendation": "<one specific, actionable recommendation to increase their booking rate>",
  "projectedRatio": "<what their ratio could be if they follow your advice, e.g. '15-20%'>"
}`;
    const raw = await callClaudeAPI("You are an expert talent analytics advisor. Be specific and data-driven. Always respond with valid JSON only.", prompt);
    if (raw) { const parsed = parseJSON(raw); if (parsed) setAiInsight(parsed); }
    setAnalyzing(false);
  };

  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <button onClick={() => setPage(PAGES.DASHBOARD)} style={{ background: "transparent", border: "none", color: BRAND.textMuted, cursor: "pointer", fontSize: 14, fontFamily: "'Outfit', sans-serif", marginBottom: 24, padding: 0 }}>← Back to Dashboard</button>
      <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>📊 Audition Analytics</h1>
      <p style={{ margin: "0 0 32px", color: BRAND.textMuted, fontSize: 15 }}>Track your audition-to-booking ratio and find AI-powered career patterns.</p>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 32 }}>
        <StatCard icon="🎬" value={String(stats.auditions)} label="AI-Scored Auditions" />
        <StatCard icon="✅" value={String(bookedCount)} label="Bookings Logged" />
        <StatCard icon="📈" value={`${ratio}%`} label="Booking Rate" />
        <StatCard icon="🎯" value={stats.lastScore ? String(stats.lastScore) : "—"} label="Latest Pro Score" />
      </div>

      <Card style={{ marginBottom: 24 }}>
        <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Log a Booking</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px 16px", marginBottom: 16 }}>
          <input value={bookingInput.role} onChange={e => setBookingInput(p => ({ ...p, role: e.target.value }))} placeholder="Role name (e.g. Detective #2)" style={{ background: BRAND.surface, border: `1px solid ${BRAND.border}`, borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif", outline: "none" }} />
          <input value={bookingInput.project} onChange={e => setBookingInput(p => ({ ...p, project: e.target.value }))} placeholder="Project (e.g. NBC Pilot)" style={{ background: BRAND.surface, border: `1px solid ${BRAND.border}`, borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif", outline: "none" }} />
          <input type="date" value={bookingInput.date} onChange={e => setBookingInput(p => ({ ...p, date: e.target.value }))} style={{ background: BRAND.surface, border: `1px solid ${BRAND.border}`, borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif", outline: "none", colorScheme: "dark" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <label style={{ fontSize: 13, color: BRAND.textMuted, display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
              <input type="checkbox" checked={bookingInput.scored} onChange={e => setBookingInput(p => ({ ...p, scored: e.target.checked }))} /> Used AI Coach
            </label>
            {bookingInput.scored && <input value={bookingInput.proScore} onChange={e => setBookingInput(p => ({ ...p, proScore: e.target.value }))} placeholder="Score" style={{ width: 70, background: BRAND.surface, border: `1px solid ${BRAND.border}`, borderRadius: 8, padding: "8px 10px", color: BRAND.text, fontSize: 13, fontFamily: "'Outfit', sans-serif", outline: "none" }} />}
          </div>
        </div>
        <GlowButton onClick={addBooking} disabled={!bookingInput.role || !bookingInput.project}>+ Log Booking</GlowButton>
      </Card>

      {bookings.length > 0 && (
        <Card style={{ marginBottom: 24 }}>
          <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Your Bookings ({bookings.length})</h3>
          {bookings.map((b, i) => (
            <div key={b.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: i < bookings.length - 1 ? `1px solid ${BRAND.border}` : "none" }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: BRAND.accent + "15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>✅</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{b.role}</div>
                <div style={{ fontSize: 12, color: BRAND.textDim }}>{b.project}{b.date ? ` · ${b.date}` : ""}{b.scored ? ` · AI Score: ${b.proScore}` : ""}</div>
              </div>
              <button onClick={() => removeBooking(b.id)} style={{ background: "none", border: "none", color: BRAND.textDim, cursor: "pointer", fontSize: 14 }}>✕</button>
            </div>
          ))}
          <div style={{ marginTop: 16 }}>
            <GlowButton onClick={runAIAnalysis} disabled={analyzing}>{analyzing ? "Analyzing..." : "🧠 Run AI Career Analysis"}</GlowButton>
          </div>
        </Card>
      )}

      {aiInsight && (
        <Card style={{ marginBottom: 24, border: `1px solid ${BRAND.accent}30` }}>
          <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.accent, fontFamily: "'Outfit', sans-serif" }}>🧠 AI Career Analysis</h3>
          {[
            ["Summary", aiInsight.summary],
            ["Booking Pattern", aiInsight.bookingPattern],
            ["AI Coaching Correlation", aiInsight.aiCorrelation],
            ["Recommendation", aiInsight.recommendation],
            ["Projected Booking Rate", aiInsight.projectedRatio],
          ].map(([label, val]) => val ? (
            <div key={label} style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>{label.toUpperCase()}</div>
              <div style={{ fontSize: 14, color: BRAND.text, lineHeight: 1.7 }}>{val}</div>
            </div>
          ) : null)}
        </Card>
      )}
    </div>
  );
};

// ─── TALENT INSIGHTS (VIEW TRACKER) ───
const MOCK_CD_VIEWS = [
  { name: "Sarah Chen", company: "Chen Casting LA", time: "2h ago", duration: 47, viewed: ["Profile", "Reel"], photo: "S" },
  { name: "Marcus Rivera", company: "Rivera Talent NYC", time: "5h ago", duration: 23, viewed: ["Profile"], photo: "M" },
  { name: "Jennifer Walsh", company: "Walsh & Partners", time: "1d ago", duration: 68, viewed: ["Profile", "Reel", "Resume"], photo: "J" },
  { name: "David Kim", company: "NBC Casting Dept", time: "2d ago", duration: 34, viewed: ["Profile", "Reel"], photo: "D" },
  { name: "Amanda Torres", company: "Indie Film Collective", time: "3d ago", duration: 12, viewed: ["Profile"], photo: "A" },
];

const InsightsPage = ({ setPage, stats }) => {
  const hasViews = stats.profileBuilt;
  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <button onClick={() => setPage(PAGES.DASHBOARD)} style={{ background: "transparent", border: "none", color: BRAND.textMuted, cursor: "pointer", fontSize: 14, fontFamily: "'Outfit', sans-serif", marginBottom: 24, padding: 0 }}>← Back to Dashboard</button>
      <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>👁️ Talent Insights</h1>
      <p style={{ margin: "0 0 32px", color: BRAND.textMuted, fontSize: 15 }}>See who's viewing your profile and how they engage with your content.</p>

      {!hasViews ? (
        <Card style={{ textAlign: "center", padding: "60px 32px" }}>
          <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.5 }}>👁️</div>
          <h3 style={{ margin: "0 0 10px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>No views yet</h3>
          <p style={{ margin: "0 0 24px", color: BRAND.textMuted, fontSize: 14, maxWidth: 400, marginLeft: "auto", marginRight: "auto", lineHeight: 1.7 }}>
            Build your profile with the AI Resume Architect first. Once your profile is live, casting directors will start finding you — and you'll see their activity here.
          </p>
          <GlowButton onClick={() => setPage(PAGES.RESUME)}>Build My Profile →</GlowButton>
        </Card>
      ) : (
        <>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 32 }}>
            <StatCard icon="👁️" value={String(MOCK_CD_VIEWS.length)} label="Profile Views (7d)" />
            <StatCard icon="⏱️" value={`${Math.round(MOCK_CD_VIEWS.reduce((a, v) => a + v.duration, 0) / MOCK_CD_VIEWS.length)}s`} label="Avg. View Duration" />
            <StatCard icon="🎬" value={String(MOCK_CD_VIEWS.filter(v => v.viewed.includes("Reel")).length)} label="Reel Watches" />
            <StatCard icon="📄" value={String(MOCK_CD_VIEWS.filter(v => v.viewed.includes("Resume")).length)} label="Resume Downloads" />
          </div>

          <Card style={{ marginBottom: 24 }}>
            <h3 style={{ margin: "0 0 20px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Recent Profile Views</h3>
            {MOCK_CD_VIEWS.map((v, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 0", borderBottom: i < MOCK_CD_VIEWS.length - 1 ? `1px solid ${BRAND.border}` : "none" }}>
                <div style={{
                  width: 44, height: 44, borderRadius: "50%", background: BRAND.gradient,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 18, fontWeight: 700, color: "#fff", fontFamily: "'Outfit', sans-serif",
                }}>{v.photo}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{v.name}</div>
                  <div style={{ fontSize: 12, color: BRAND.textDim }}>{v.company}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: v.duration >= 30 ? BRAND.accent : BRAND.textMuted, fontFamily: "'Outfit', sans-serif" }}>{v.duration}s</div>
                  <div style={{ fontSize: 11, color: BRAND.textDim }}>{v.time}</div>
                </div>
                <div style={{ display: "flex", gap: 4, flexWrap: "wrap", maxWidth: 140 }}>
                  {v.viewed.map(item => (
                    <span key={item} style={{ fontSize: 10, padding: "2px 8px", borderRadius: 6, background: item === "Reel" ? BRAND.primary + "20" : item === "Resume" ? BRAND.accent + "20" : BRAND.surface, color: item === "Reel" ? BRAND.primary : item === "Resume" ? BRAND.accent : BRAND.textMuted, fontWeight: 700 }}>{item}</span>
                  ))}
                </div>
              </div>
            ))}
          </Card>

          <Card style={{ padding: "16px 20px", background: BRAND.gold + "08", border: `1px solid ${BRAND.gold}30` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 20 }}>💡</span>
              <span style={{ fontSize: 13, color: BRAND.gold, lineHeight: 1.6 }}>
                <strong>Pro tip:</strong> {MOCK_CD_VIEWS[2].name} from {MOCK_CD_VIEWS[2].company} spent {MOCK_CD_VIEWS[2].duration}s on your profile and viewed your reel + resume. This is a strong signal of interest — consider reaching out.
              </span>
            </div>
          </Card>
        </>
      )}
    </div>
  );
};

// ─── AI HEADSHOT RANKER ───
const HeadshotRankerPage = ({ setPage }) => {
  const [headshots, setHeadshots] = useState([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState(null);
  const fileRef = useRef(null);

  const handleFiles = (e) => {
    const files = Array.from(e.target.files || []).slice(0, 6);
    const newHeadshots = [];
    let loaded = 0;
    files.forEach((file, idx) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        newHeadshots.push({ id: Date.now() + idx, name: file.name, dataUrl: ev.target.result, base64: ev.target.result.split(",")[1] });
        loaded++;
        if (loaded === files.length) setHeadshots(prev => [...prev, ...newHeadshots].slice(0, 6));
      };
      reader.readAsDataURL(file);
    });
  };

  const removeHeadshot = (id) => { setHeadshots(prev => prev.filter(h => h.id !== id)); setResults(null); };

  const analyzeHeadshots = async () => {
    if (headshots.length === 0) return;
    setAnalyzing(true);
    const userContent = [
      ...headshots.map((h, i) => ({
        type: "image",
        source: { type: "base64", media_type: h.dataUrl.startsWith("data:image/png") ? "image/png" : "image/jpeg", data: h.base64 },
      })),
      {
        type: "text",
        text: `You are an expert casting director and headshot consultant analyzing ${headshots.length} actor headshot(s). For EACH headshot (in order), analyze:

1. Casting Archetypes it fits (Commercial, Theatrical, Villain, Hero, Love Interest, Authority Figure, Quirky/Character, Corporate, Edgy/Alternative)
2. Technical quality (lighting, framing, focus, background)
3. Overall effectiveness ranking vs the others

Respond ONLY with JSON (no markdown):
{
  "headshots": [
    {
      "index": 1,
      "rank": <number 1 = best>,
      "archetypes": ["<archetype1>", "<archetype2>"],
      "primaryArchetype": "<single best archetype>",
      "lighting": <score 1-10>,
      "framing": <score 1-10>,
      "expression": <score 1-10>,
      "overall": <score 1-100>,
      "strengths": "<what works well>",
      "improvement": "<one specific actionable tip>"
    }
  ],
  "recommendation": "<which headshot to use for what purpose — be specific about commercial vs theatrical submissions>"
}`
      }
    ];
    const raw = await callClaudeAPI("You are an expert casting director specializing in actor headshot evaluation. Be honest, specific, and industry-savvy. Always respond with valid JSON only.", userContent);
    if (raw) { const parsed = parseJSON(raw); if (parsed) setResults(parsed); }
    setAnalyzing(false);
  };

  const archetypeColors = { Commercial: BRAND.accent, Theatrical: BRAND.primary, Villain: "#8B5CF6", Hero: BRAND.gold, "Love Interest": "#EC4899", "Authority Figure": "#3B82F6", "Quirky/Character": "#F97316", Corporate: "#6B7280", "Edgy/Alternative": "#EF4444" };

  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <button onClick={() => setPage(PAGES.DASHBOARD)} style={{ background: "transparent", border: "none", color: BRAND.textMuted, cursor: "pointer", fontSize: 14, fontFamily: "'Outfit', sans-serif", marginBottom: 24, padding: 0 }}>← Back to Dashboard</button>
      <h1 style={{ margin: "0 0 8px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>📸 AI Headshot Ranker</h1>
      <p style={{ margin: "0 0 32px", color: BRAND.textMuted, fontSize: 15 }}>Upload your headshots. AI tags casting archetypes and ranks them by industry standards.</p>

      <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleFiles} style={{ display: "none" }} />

      <Card style={{ marginBottom: 24 }}>
        {headshots.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 20px" }}>
            <div style={{ fontSize: 56, marginBottom: 16 }}>📸</div>
            <h3 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Upload Your Headshots</h3>
            <p style={{ margin: "0 0 24px", color: BRAND.textMuted, fontSize: 14 }}>Up to 6 photos. JPG or PNG. The AI will rank and tag each one.</p>
            <GlowButton onClick={() => fileRef.current?.click()}>Choose Photos</GlowButton>
          </div>
        ) : (
          <>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Your Headshots ({headshots.length}/6)</h3>
              {headshots.length < 6 && <GlowButton size="sm" variant="ghost" onClick={() => fileRef.current?.click()}>+ Add More</GlowButton>}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(120, 1fr))", gap: 12, marginBottom: 20 }}>
              {headshots.map((h, i) => (
                <div key={h.id} style={{ position: "relative", borderRadius: 12, overflow: "hidden", border: `2px solid ${results?.headshots?.[i]?.rank === 1 ? BRAND.gold : BRAND.border}`, aspectRatio: "3/4" }}>
                  <img src={h.dataUrl} alt={h.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  {results?.headshots?.[i] && (
                    <div style={{ position: "absolute", top: 6, left: 6, padding: "2px 8px", borderRadius: 6, background: results.headshots[i].rank === 1 ? BRAND.gold : BRAND.surface, color: results.headshots[i].rank === 1 ? "#000" : BRAND.text, fontSize: 11, fontWeight: 800 }}>#{results.headshots[i].rank}</div>
                  )}
                  <button onClick={() => removeHeadshot(h.id)} style={{ position: "absolute", top: 6, right: 6, width: 24, height: 24, borderRadius: "50%", background: "rgba(0,0,0,0.7)", border: "none", color: "#fff", fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
                </div>
              ))}
            </div>
            <GlowButton onClick={analyzeHeadshots} disabled={analyzing}>{analyzing ? "🧠 AI Analyzing..." : "🧠 Rank & Tag Headshots"}</GlowButton>
          </>
        )}
      </Card>

      {results?.headshots && (
        <>
          {results.headshots.sort((a, b) => a.rank - b.rank).map((h, i) => (
            <Card key={i} style={{ marginBottom: 16, border: h.rank === 1 ? `1px solid ${BRAND.gold}40` : `1px solid ${BRAND.border}` }}>
              <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
                <div style={{ width: 100, height: 133, borderRadius: 10, overflow: "hidden", flexShrink: 0, border: `2px solid ${h.rank === 1 ? BRAND.gold : BRAND.border}` }}>
                  {headshots[h.index - 1] && <img src={headshots[h.index - 1].dataUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
                </div>
                <div style={{ flex: 1, minWidth: 200 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                    <span style={{ fontSize: 18, fontWeight: 800, color: h.rank === 1 ? BRAND.gold : BRAND.text, fontFamily: "'Outfit', sans-serif" }}>#{h.rank}</span>
                    <span style={{ fontSize: 28, fontWeight: 800, color: h.overall >= 80 ? BRAND.accent : h.overall >= 60 ? BRAND.gold : BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>{h.overall}</span>
                    <span style={{ fontSize: 13, color: BRAND.textDim }}>/100</span>
                  </div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
                    {(h.archetypes || []).map(a => (
                      <span key={a} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 6, background: (archetypeColors[a] || BRAND.textDim) + "20", color: archetypeColors[a] || BRAND.textMuted, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>{a}</span>
                    ))}
                  </div>
                  <div style={{ display: "flex", gap: 16, marginBottom: 10 }}>
                    {[["💡", "Lighting", h.lighting], ["📐", "Framing", h.framing], ["🎭", "Expression", h.expression]].map(([icon, label, score]) => (
                      <div key={label} style={{ textAlign: "center" }}>
                        <div style={{ fontSize: 11, color: BRAND.textDim, marginBottom: 2 }}>{icon} {label}</div>
                        <div style={{ fontSize: 16, fontWeight: 800, color: score >= 8 ? BRAND.accent : score >= 6 ? BRAND.gold : BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>{score}/10</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ fontSize: 13, color: BRAND.accent, marginBottom: 4 }}>✓ {h.strengths}</div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted }}>→ {h.improvement}</div>
                </div>
              </div>
            </Card>
          ))}
          {results.recommendation && (
            <Card style={{ padding: "20px 24px", background: BRAND.accent + "08", border: `1px solid ${BRAND.accent}30`, marginBottom: 24 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.accent, letterSpacing: 1, marginBottom: 6, fontFamily: "'Outfit', sans-serif" }}>AI RECOMMENDATION</div>
              <div style={{ fontSize: 14, color: BRAND.text, lineHeight: 1.7 }}>{results.recommendation}</div>
            </Card>
          )}
        </>
      )}
    </div>
  );
};

// ─── HALL OF FAME ───
const HallOfFamePage = ({ setPage, hallOfFame, performerOfTheWeek, daysUntilReset, currentWeekScores, currentUser }) => {
  const myScores = currentWeekScores.filter(s => s.username === currentUser?.username);
  const myAvg = myScores.length >= 3 ? Math.round(myScores.reduce((a, s) => a + s.score, 0) / myScores.length) : null;

  return (
    <div style={{ padding: "32px", maxWidth: 900, margin: "0 auto" }}>
      <button onClick={() => setPage(PAGES.DASHBOARD)} style={{ background: "transparent", border: "none", color: BRAND.textMuted, cursor: "pointer", fontSize: 14, fontFamily: "'Outfit', sans-serif", marginBottom: 24, padding: 0 }}>← Back to Dashboard</button>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 32 }}>
        <div>
          <h1 style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>🏆 Weekly Hall of Fame</h1>
          <p style={{ margin: 0, color: BRAND.textMuted, fontSize: 14 }}>Top performers ranked by average AI Pro Score. Min 3 auditions to qualify.</p>
        </div>
        <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}` }}>
          <span style={{ fontSize: 13, color: BRAND.textDim }}>Resets in </span>
          <span style={{ fontSize: 15, fontWeight: 800, color: BRAND.primary, fontFamily: "'Space Mono', monospace" }}>{daysUntilReset}d</span>
        </div>
      </div>

      {/* Your progress */}
      <Card style={{ marginBottom: 24, background: BRAND.surface, border: `1px solid ${BRAND.accent}25` }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.accent, letterSpacing: 1, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>YOUR WEEKLY PROGRESS</div>
            <div style={{ fontSize: 14, color: BRAND.textMuted }}>
              {myScores.length === 0 ? "No auditions scored this week yet." :
               myScores.length < 3 ? `${myScores.length}/3 auditions — score ${3 - myScores.length} more to qualify!` :
               `Qualified! ${myScores.length} auditions this week.`}
            </div>
          </div>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: BRAND.text, fontFamily: "'Space Mono', monospace" }}>{myScores.length}</div>
              <div style={{ fontSize: 10, color: BRAND.textDim }}>AUDITIONS</div>
            </div>
            {myAvg && (
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 24, fontWeight: 800, color: myAvg >= 80 ? BRAND.accent : BRAND.gold, fontFamily: "'Space Mono', monospace" }}>{myAvg}</div>
                <div style={{ fontSize: 10, color: BRAND.textDim }}>AVG SCORE</div>
              </div>
            )}
            {myScores.length < 3 && <GlowButton size="sm" onClick={() => setPage(PAGES.COACH)}>Score Audition →</GlowButton>}
          </div>
        </div>
      </Card>

      {/* Winner spotlight */}
      {performerOfTheWeek && (
        <Card style={{ marginBottom: 24, padding: "32px", textAlign: "center", background: `linear-gradient(180deg, ${BRAND.gold}06 0%, ${BRAND.card} 80%)`, border: `1px solid ${BRAND.gold}30` }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.gold, letterSpacing: 2, marginBottom: 16, fontFamily: "'Space Mono', monospace" }}>👑 CURRENT #1 — PERFORMER OF THE WEEK</div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 20, flexWrap: "wrap" }}>
            <div style={{
              width: 80, height: 100, borderRadius: 12, overflow: "hidden", flexShrink: 0,
              background: performerOfTheWeek.form?.headshot ? "none" : BRAND.gradient,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 32, fontWeight: 800, color: "#fff", border: `2px solid ${BRAND.gold}`,
            }}>
              {performerOfTheWeek.form?.headshot ? <img src={performerOfTheWeek.form.headshot.dataUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : (performerOfTheWeek.form?.name?.charAt(0) || "?")}
            </div>
            <div style={{ textAlign: "left" }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{performerOfTheWeek.form?.name || `@${performerOfTheWeek.username}`}</div>
              <div style={{ fontSize: 13, color: BRAND.textMuted }}>{performerOfTheWeek.count} auditions · Avg: {performerOfTheWeek.avg} · Best: {performerOfTheWeek.best}</div>
            </div>
          </div>
        </Card>
      )}

      {/* Leaderboard */}
      <Card>
        <h3 style={{ margin: "0 0 20px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Weekly Leaderboard</h3>
        {hallOfFame.length === 0 ? (
          <div style={{ textAlign: "center", padding: "40px 20px" }}>
            <div style={{ fontSize: 36, marginBottom: 12, opacity: 0.5 }}>🏆</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: BRAND.text, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>No one has qualified yet this week</div>
            <div style={{ fontSize: 13, color: BRAND.textMuted, maxWidth: 360, margin: "0 auto", lineHeight: 1.7 }}>Score at least 3 auditions with the AI Coach before Sunday to appear on the leaderboard and compete for Performer of the Week.</div>
          </div>
        ) : hallOfFame.map((actor, i) => (
          <div key={actor.username} style={{
            display: "flex", alignItems: "center", gap: 14, padding: "14px 0",
            borderBottom: i < hallOfFame.length - 1 ? `1px solid ${BRAND.border}` : "none",
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: i === 0 ? 18 : 14, fontWeight: 800,
              background: i === 0 ? BRAND.gold : i === 1 ? "#C0C0C0" : i === 2 ? "#CD7F32" : BRAND.surface,
              color: i < 3 ? "#000" : BRAND.textMuted, fontFamily: "'Space Mono', monospace",
            }}>{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</div>
            <div style={{
              width: 40, height: 50, borderRadius: 8, overflow: "hidden", flexShrink: 0,
              background: actor.form?.headshot ? "none" : BRAND.gradient,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16, fontWeight: 800, color: "#fff",
              border: i === 0 ? `2px solid ${BRAND.gold}` : `1px solid ${BRAND.border}`,
            }}>
              {actor.form?.headshot ? <img src={actor.form.headshot.dataUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : (actor.form?.name?.charAt(0) || "?")}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: actor.username === currentUser?.username ? BRAND.accent : BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
                {actor.form?.name || `@${actor.username}`} {actor.username === currentUser?.username && <span style={{ fontSize: 11, color: BRAND.accent }}>(you)</span>}
              </div>
              <div style={{ fontSize: 12, color: BRAND.textDim }}>{actor.count} auditions this week</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: i === 0 ? BRAND.gold : actor.avg >= 80 ? BRAND.accent : BRAND.text, fontFamily: "'Space Mono', monospace" }}>{actor.avg}</div>
              <div style={{ fontSize: 10, color: BRAND.textDim }}>AVG</div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
};

// ─── CASTING PROFESSIONAL DASHBOARD (Phase 2 Shell) ───
const DirectorDashboard = ({ setPage, username, talentPool }) => {
  const [search, setSearch] = useState("");
  const [activeFilters, setActiveFilters] = useState([]);
  const [expandedActor, setExpandedActor] = useState(null);

  const toggleFilter = (f) => setActiveFilters(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);

  const filtered = talentPool.filter(actor => {
    const f = actor.form;
    const text = [f.name, f.location, f.ethnicity, f.ageRange, f.skill1, f.skill2, f.skill3, f.training, f.experience].filter(Boolean).join(" ").toLowerCase();
    if (search && !text.includes(search.toLowerCase())) return false;
    if (activeFilters.includes("Verified Skills") && !f.skill1Proof && !f.skill2Proof && !f.skill3Proof) return false;
    if (activeFilters.includes("90+ Pro Score") && (!actor.stats?.lastScore || actor.stats.lastScore < 90)) return false;
    return true;
  });

  return (
  <div style={{ padding: "32px", maxWidth: 1100, margin: "0 auto" }}>
    <div style={{ marginBottom: 32 }}>
      <div style={{ display: "inline-block", padding: "4px 14px", borderRadius: 8, background: BRAND.accent + "15", border: `1px solid ${BRAND.accent}40`, marginBottom: 12 }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: BRAND.accent, letterSpacing: 1, fontFamily: "'Outfit', sans-serif" }}>🎬 CASTING PROFESSIONAL</span>
      </div>
      <h1 style={{ margin: "0 0 8px", fontSize: 32, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>
        Welcome{username ? `, @${username}` : ""} 👋
      </h1>
      <p style={{ margin: 0, color: BRAND.textMuted, fontSize: 15 }}>Your casting command center. {talentPool.length > 0 ? `${talentPool.length} actor${talentPool.length !== 1 ? "s" : ""} on the platform.` : ""}</p>
    </div>

    <Card style={{ marginBottom: 24 }}>
      <h3 style={{ margin: "0 0 12px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>🔍 Browse Talent</h3>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, skill, location, ethnicity..." style={{ flex: 1, background: BRAND.surface, border: `1px solid ${BRAND.border}`, borderRadius: 10, padding: "12px 14px", color: BRAND.text, fontSize: 14, fontFamily: "'Outfit', sans-serif", outline: "none" }} />
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {["Verified Skills", "90+ Pro Score"].map(tag => (
          <button key={tag} onClick={() => toggleFilter(tag)} style={{
            fontSize: 12, padding: "6px 14px", borderRadius: 8, cursor: "pointer", fontFamily: "'Outfit', sans-serif", fontWeight: 600, transition: "all 0.2s",
            background: activeFilters.includes(tag) ? BRAND.primary + "20" : BRAND.surface,
            border: `1px solid ${activeFilters.includes(tag) ? BRAND.primary + "60" : BRAND.border}`,
            color: activeFilters.includes(tag) ? BRAND.primary : BRAND.textMuted,
          }}>{tag}</button>
        ))}
      </div>
    </Card>

    {talentPool.length === 0 ? (
      <Card style={{ textAlign: "center", padding: "60px 32px" }}>
        <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.5 }}>🎭</div>
        <h3 style={{ margin: "0 0 10px", fontSize: 20, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>No talent on the platform yet</h3>
        <p style={{ margin: 0, color: BRAND.textMuted, fontSize: 14, maxWidth: 400, marginLeft: "auto", marginRight: "auto", lineHeight: 1.7 }}>
          When actors sign up and build their profiles with the AI Resume Architect, they'll appear here. You'll be able to search, filter, and view their full AI-scored portfolios.
        </p>
      </Card>
    ) : filtered.length === 0 ? (
      <Card style={{ textAlign: "center", padding: "40px 32px" }}>
        <div style={{ fontSize: 32, marginBottom: 12, opacity: 0.5 }}>🔍</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>No actors match your filters</h3>
        <p style={{ margin: 0, color: BRAND.textMuted, fontSize: 14 }}>Try adjusting your search or removing filters.</p>
      </Card>
    ) : (
      <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 24 }}>
        {filtered.map((actor, i) => {
          const f = actor.form;
          const skills = actor.aiSkills || [];
          const hasVerified = !!(f.skill1Proof || f.skill2Proof || f.skill3Proof);
          const expanded = expandedActor === i;
          return (
            <Card key={i} glow onClick={() => setExpandedActor(expanded ? null : i)} style={{ cursor: "pointer", border: expanded ? `1px solid ${BRAND.primary}40` : undefined }}>
              <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
                <div style={{
                  width: 80, height: 100, borderRadius: 12, overflow: "hidden", flexShrink: 0,
                  background: f.headshot ? "none" : BRAND.gradient,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 32, fontWeight: 800, color: "#fff", fontFamily: "'Outfit', sans-serif",
                }}>
                  {f.headshot ? <img src={f.headshot.dataUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : (f.name?.charAt(0) || "?")}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4, flexWrap: "wrap" }}>
                    <h3 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{f.name || "Unnamed Actor"}</h3>
                    {hasVerified && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700 }}>✓ VERIFIED</span>}
                    {actor.stats?.lastScore >= 90 && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: BRAND.gold + "20", color: BRAND.gold, fontWeight: 700 }}>⭐ 90+ PRO SCORE</span>}
                  </div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted, marginBottom: 8 }}>
                    {[f.ageRange, f.ethnicity, f.location].filter(Boolean).join(" · ") || "Profile info not set"}
                  </div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {[f.skill1, f.skill2, f.skill3].filter(Boolean).map(s => (
                      <span key={s} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 6, background: BRAND.surface, border: `1px solid ${BRAND.border}`, color: BRAND.textMuted, fontFamily: "'Outfit', sans-serif" }}>{s}</span>
                    ))}
                  </div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  {actor.stats?.lastScore ? (
                    <>
                      <div style={{ fontSize: 28, fontWeight: 800, color: actor.stats.lastScore >= 80 ? BRAND.accent : actor.stats.lastScore >= 60 ? BRAND.gold : BRAND.primary, fontFamily: "'Outfit', sans-serif" }}>{actor.stats.lastScore}</div>
                      <div style={{ fontSize: 11, color: BRAND.textDim }}>Pro Score</div>
                    </>
                  ) : (
                    <div style={{ fontSize: 12, color: BRAND.textDim }}>No score yet</div>
                  )}
                </div>
              </div>

              {expanded && (
                <div style={{ marginTop: 20, paddingTop: 20, borderTop: `1px solid ${BRAND.border}` }}>
                  {skills.length > 0 && (
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.primary, letterSpacing: 1, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>AI-ENHANCED SKILLS</div>
                      {skills.map((s, j) => (
                        <div key={j} style={{ padding: 12, borderRadius: 10, background: BRAND.surface, border: `1px solid ${f[`skill${j+1}Proof`] ? BRAND.accent + "40" : BRAND.border}`, marginBottom: 8 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                            <span style={{ fontSize: 13, fontWeight: 700, color: BRAND.text }}>{s.raw}</span>
                            {f[`skill${j+1}Proof`] && <span style={{ fontSize: 10, padding: "2px 6px", borderRadius: 4, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700 }}>✓</span>}
                          </div>
                          <div style={{ fontSize: 12, color: BRAND.textMuted, lineHeight: 1.6 }}>{s.pro}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    {f.training && (
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 4 }}>TRAINING</div>
                        <div style={{ fontSize: 13, color: BRAND.textMuted, lineHeight: 1.6 }}>{f.training}</div>
                      </div>
                    )}
                    {f.experience && (
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 4 }}>EXPERIENCE</div>
                        <div style={{ fontSize: 13, color: BRAND.textMuted, lineHeight: 1.6 }}>{f.experience}</div>
                      </div>
                    )}
                  </div>
                  {(f.tiktok || f.youtube || f.instagram) && (
                    <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {f.tiktok && <span style={{ fontSize: 12, padding: "4px 10px", borderRadius: 6, background: BRAND.surface, color: BRAND.textMuted }}>🎵 {f.tiktok}</span>}
                      {f.youtube && <span style={{ fontSize: 12, padding: "4px 10px", borderRadius: 6, background: BRAND.surface, color: BRAND.textMuted }}>▶️ {f.youtube}</span>}
                      {f.instagram && <span style={{ fontSize: 12, padding: "4px 10px", borderRadius: 6, background: BRAND.surface, color: BRAND.textMuted }}>📸 {f.instagram}</span>}
                    </div>
                  )}
                  <div style={{ marginTop: 12, display: "flex", gap: 12 }}>
                    <div style={{ fontSize: 12, color: BRAND.textDim }}>📊 {actor.stats?.auditions || 0} auditions scored</div>
                    <div style={{ fontSize: 12, color: BRAND.textDim }}>🥋 {actor.stats?.dojoXp || 0} Dojo XP</div>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    )}

    <div style={{ display: "flex", gap: 20, flexWrap: "wrap", marginBottom: 24 }}>
      <Card glow style={{ flex: 1, minWidth: 250, opacity: 0.7 }}>
        <div style={{ fontSize: 32, marginBottom: 12 }}>📋</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Post a Role</h3>
        <p style={{ margin: "0 0 12px", fontSize: 13, color: BRAND.textMuted, lineHeight: 1.6 }}>Post casting calls with minimum performance score requirements. Only qualified actors see your listings.</p>
        <span style={{ fontSize: 12, padding: "4px 12px", borderRadius: 6, background: BRAND.gold + "15", color: BRAND.gold, fontWeight: 700 }}>Coming in Phase 2</span>
      </Card>
      <Card glow style={{ flex: 1, minWidth: 250, opacity: 0.7 }}>
        <div style={{ fontSize: 32, marginBottom: 12 }}>🤖</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Matchmaker AI</h3>
        <p style={{ margin: "0 0 12px", fontSize: 13, color: BRAND.textMuted, lineHeight: 1.6 }}>Upload a script or character breakdown. AI matches you with the Top 5% of actors who fit the vibe and archetype.</p>
        <span style={{ fontSize: 12, padding: "4px 12px", borderRadius: 6, background: BRAND.gold + "15", color: BRAND.gold, fontWeight: 700 }}>Coming in Phase 2</span>
      </Card>
      <Card glow style={{ flex: 1, minWidth: 250, opacity: 0.7 }}>
        <div style={{ fontSize: 32, marginBottom: 12 }}>🛡️</div>
        <h3 style={{ margin: "0 0 8px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Apex-Verified Filter</h3>
        <p style={{ margin: "0 0 12px", fontSize: 13, color: BRAND.textMuted, lineHeight: 1.6 }}>Set minimum Pro Scores, require verified skills, filter by casting archetypes. No unqualified submissions.</p>
        <span style={{ fontSize: 12, padding: "4px 12px", borderRadius: 6, background: BRAND.gold + "15", color: BRAND.gold, fontWeight: 700 }}>Coming in Phase 2</span>
      </Card>
    </div>

    <Card style={{ padding: "20px 24px", background: BRAND.accent + "06", border: `1px solid ${BRAND.accent}25` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <span style={{ fontSize: 24 }}>🚀</span>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>The APEX Market is coming.</div>
          <div style={{ fontSize: 13, color: BRAND.textMuted }}>You're on the early access list. We'll notify you when job posting and Matchmaker AI go live.</div>
        </div>
      </div>
    </Card>
  </div>
  );
};

// ─── PUBLIC PROFILE ───
const ProfilePage = ({ setPage, profileData, username }) => {
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState("");
  const f = profileData?.form || {};
  const skills = profileData?.aiSkills || [];
  const profileUrl = `apexperform.com/${username || f.name?.toLowerCase().replace(/\s+/g, "") || "username"}`;
  const hasProfile = !!(f.name || skills.length > 0);

  const copyLink = () => {
    try { navigator.clipboard.writeText(profileUrl); } catch(e) {}
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const shareEmail = () => {
    window.open(`mailto:?subject=Check out my actor profile on APEX PERFORM&body=View my portfolio here: ${profileUrl}`);
    setShared("email");
    setTimeout(() => setShared(""), 2000);
  };
  const shareTikTok = () => {
    try { navigator.clipboard.writeText(profileUrl); } catch(e) {}
    setShared("tiktok");
    setTimeout(() => setShared(""), 3000);
  };
  const shareYouTube = () => {
    try { navigator.clipboard.writeText(profileUrl); } catch(e) {}
    setShared("youtube");
    setTimeout(() => setShared(""), 3000);
  };

  return (
  <div style={{ padding: "32px", maxWidth: 700, margin: "0 auto" }}>
    <div style={{
      textAlign: "center", padding: "48px 32px", borderRadius: 20,
      background: `linear-gradient(180deg, ${BRAND.primary}15 0%, ${BRAND.card} 60%)`,
      border: `1px solid ${BRAND.border}`, marginBottom: 24,
    }}>
      <div style={{
        width: 120, height: 150, borderRadius: 16, overflow: "hidden",
        background: f.headshot ? "none" : BRAND.gradient,
        margin: "0 auto 20px", display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 44, fontWeight: 800, color: "#fff", fontFamily: "'Outfit', sans-serif",
        boxShadow: `0 8px 32px ${BRAND.primaryGlow}`,
      }}>
        {f.headshot ? (
          <img src={f.headshot.dataUrl} alt="Headshot" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (f.name ? f.name.charAt(0).toUpperCase() : "?")}
      </div>
      <h1 style={{ margin: "0 0 4px", fontSize: 32, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{f.name || "Your Name"}</h1>
      <div style={{ fontSize: 15, color: BRAND.textMuted, marginBottom: 4 }}>{[f.ageRange, f.ethnicity, "Actor"].filter(Boolean).join(" · ")}</div>
      <div style={{ fontSize: 13, color: BRAND.textDim }}>{f.location || "Location not set"}</div>
    </div>

    {!hasProfile ? (
      <Card style={{ marginBottom: 20, textAlign: "center", padding: "40px 32px" }}>
        <div style={{ fontSize: 40, marginBottom: 12, opacity: 0.6 }}>📝</div>
        <h3 style={{ margin: "0 0 10px", fontSize: 18, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Your profile is empty</h3>
        <p style={{ margin: "0 0 20px", color: BRAND.textMuted, fontSize: 14, lineHeight: 1.6 }}>
          Head to the AI Resume Architect to fill in your skills, training, and experience.
        </p>
        <GlowButton onClick={() => setPage(PAGES.RESUME)}>Build My Profile →</GlowButton>
      </Card>
    ) : (
      <>
        {skills.length > 0 && (
          <Card style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Special Skills — AI Enhanced</h3>
              {(f.skill1Proof || f.skill2Proof || f.skill3Proof) && (
                <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 6, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, fontFamily: "'Outfit', sans-serif", border: `1px solid ${BRAND.accent}40` }}>✓ Verified by APEX</span>
              )}
            </div>
            {skills.map((s, i) => {
              const hasProof = f[`skill${i + 1}Proof`];
              return (
                <div key={i} style={{ padding: 16, borderRadius: 12, background: BRAND.surface, border: `1px solid ${hasProof ? BRAND.accent + "40" : BRAND.border}`, marginBottom: i < skills.length - 1 ? 10 : 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <span style={{ fontSize: 14, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>{s.raw}</span>
                    {hasProof && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: BRAND.accent + "20", color: BRAND.accent, fontWeight: 700, marginLeft: "auto" }}>✓ VERIFIED</span>}
                  </div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted, lineHeight: 1.7 }}>{s.pro}</div>
                </div>
              );
            })}
          </Card>
        )}

        {f.training && (
          <Card style={{ marginBottom: 20 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Training & Education</h3>
            <div style={{ fontSize: 14, color: BRAND.textMuted, lineHeight: 1.8 }}>{f.training}</div>
          </Card>
        )}

        {f.experience && (
          <Card style={{ marginBottom: 20 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Acting Experience</h3>
            <div style={{ fontSize: 14, color: BRAND.textMuted, lineHeight: 1.8 }}>{f.experience}</div>
          </Card>
        )}

        {(f.tiktok || f.youtube || f.instagram) && (
          <Card style={{ marginBottom: 20 }}>
            <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Social Media</h3>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              {f.tiktok && <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}`, fontSize: 13, color: BRAND.text }}>🎵 TikTok: {f.tiktok}</div>}
              {f.youtube && <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}`, fontSize: 13, color: BRAND.text }}>▶️ YouTube: {f.youtube}</div>}
              {f.instagram && <div style={{ padding: "8px 16px", borderRadius: 10, background: BRAND.surface, border: `1px solid ${BRAND.border}`, fontSize: 13, color: BRAND.text }}>📸 Instagram: {f.instagram}</div>}
            </div>
          </Card>
        )}

        <Card style={{ marginBottom: 20, padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 13, color: BRAND.textMuted }}>Want to update your profile?</span>
          <GlowButton size="sm" onClick={() => setPage(PAGES.RESUME)}>Edit Profile →</GlowButton>
        </Card>
      </>
    )}

    <div style={{ textAlign: "center", padding: "20px 0" }}>
      <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
        <GlowButton size="sm" onClick={copyLink}>{copied ? "✓ Copied!" : "📋 Copy Profile Link"}</GlowButton>
        <GlowButton size="sm" variant="ghost" onClick={shareEmail}>{shared === "email" ? "✓ Opening Mail..." : "📧 Share via Email"}</GlowButton>
        <GlowButton size="sm" variant="ghost" onClick={shareTikTok}>{shared === "tiktok" ? "✓ Link Copied — Paste in TikTok Bio" : "🎵 Share to TikTok"}</GlowButton>
        <GlowButton size="sm" variant="ghost" onClick={shareYouTube}>{shared === "youtube" ? "✓ Link Copied — Paste in YouTube About" : "▶️ Share to YouTube"}</GlowButton>
      </div>
      <div style={{ marginTop: 20, fontSize: 12, color: BRAND.textDim }}>
        Built with <span style={{ color: BRAND.primary, fontWeight: 700 }}>APEX PERFORM</span> — Created by <button onClick={() => setPage(PAGES.FOUNDER)} style={{ background: "none", border: "none", color: BRAND.primary, cursor: "pointer", fontWeight: 700, fontFamily: "inherit", fontSize: "inherit", padding: 0 }}>Armaan Juneja</button>
      </div>
    </div>
  </div>
  );
};

// ─── SETTINGS ───
// ─── FOUNDER PAGE ───
const FounderPage = ({ setPage, founderPhoto }) => {
  const [visible, setVisible] = useState(false);
  useEffect(() => { setTimeout(() => setVisible(true), 100); }, []);

  const Section = ({ children, delay = 0 }) => (
    <div style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(30px)", transition: `all 0.8s cubic-bezier(0.4,0,0.2,1) ${delay}ms` }}>{children}</div>
  );

  return (
    <div style={{ background: BRAND.bg, minHeight: "100vh" }}>
      {/* Hero */}
      <section style={{
        padding: "100px 32px 60px", textAlign: "center", position: "relative", overflow: "hidden",
      }}>
        <div style={{
          position: "absolute", top: "-20%", left: "30%",
          width: 800, height: 800, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(233,69,96,0.12) 0%, transparent 60%)",
          filter: "blur(100px)", pointerEvents: "none",
        }} />
        <div style={{
          position: "absolute", bottom: "-10%", right: "20%",
          width: 500, height: 500, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0,212,170,0.08) 0%, transparent 60%)",
          filter: "blur(80px)", pointerEvents: "none",
        }} />

        <div style={{ position: "relative", zIndex: 1, maxWidth: 700, margin: "0 auto" }}>
          <Section delay={100}>
            <div style={{
              display: "inline-block", padding: "6px 18px", borderRadius: 40,
              background: BRAND.gold + "10", border: `1px solid ${BRAND.gold}30`, marginBottom: 32,
            }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: BRAND.gold, letterSpacing: 2, fontFamily: "'Space Mono', monospace" }}>MEET THE FOUNDER</span>
            </div>
          </Section>

          <Section delay={250}>
            <div style={{
              width: 180, height: 220, borderRadius: 24, overflow: "hidden",
              margin: "0 auto 28px", position: "relative",
              border: `3px solid ${BRAND.primary}60`,
              boxShadow: `0 20px 60px ${BRAND.primaryGlow}, 0 0 120px ${BRAND.primaryGlow}`,
            }}>
              {founderPhoto ? (
                <img src={founderPhoto} alt="Armaan Juneja" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              ) : (
                <div style={{ width: "100%", height: "100%", background: BRAND.gradient, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 64, fontWeight: 800, color: "#fff" }}>A</div>
              )}
              <div style={{
                position: "absolute", bottom: -2, left: 0, right: 0, height: 60,
                background: "linear-gradient(transparent, rgba(6,6,16,0.8))",
              }} />
            </div>
          </Section>

          <Section delay={400}>
            <h1 style={{
              fontSize: "clamp(36px, 5vw, 56px)", fontWeight: 900, margin: "0 0 8px",
              color: BRAND.text, fontFamily: "'Outfit', sans-serif", letterSpacing: "-1px",
            }}>
              Armaan Juneja
            </h1>
            <div style={{ fontSize: 18, color: BRAND.primary, fontWeight: 600, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>
              Founder & Creator of APEX Perform
            </div>
            <div style={{ fontSize: 15, color: BRAND.textMuted, marginBottom: 32 }}>
              11 years old · Actor · Developer · Entrepreneur
            </div>
          </Section>

          <Section delay={550}>
            <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginBottom: 40 }}>
              {["🎭 Actor", "💻 App Creator", "🥋 Taekwondo", "📍 Massachusetts"].map(tag => (
                <span key={tag} style={{
                  fontSize: 13, padding: "8px 18px", borderRadius: 12,
                  background: BRAND.card, border: `1px solid ${BRAND.border}`,
                  color: BRAND.textMuted, fontWeight: 500, backdropFilter: "blur(10px)",
                }}>{tag}</span>
              ))}
            </div>
          </Section>
        </div>
      </section>

      {/* Story */}
      <section style={{ padding: "0 32px 80px", maxWidth: 700, margin: "0 auto" }}>
        <Section delay={650}>
          <Card style={{ marginBottom: 24, padding: "36px 32px" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.primary, letterSpacing: 2, marginBottom: 16, fontFamily: "'Space Mono', monospace" }}>THE DREAM</div>
            <p style={{ fontSize: 16, color: BRAND.text, lineHeight: 1.8, margin: "0 0 16px" }}>
              I've wanted to be an actor for as long as I can remember. There's something about stepping into a character, telling their story, and making people feel something — that's what I love. I've been going to auditions, submitting self-tapes, and working on my craft every single day.
            </p>
            <p style={{ fontSize: 16, color: BRAND.text, lineHeight: 1.8, margin: 0 }}>
              But I noticed a problem. Every tool out there for actors is either crazy expensive or just not that good. A single coaching session costs $100+. Resume writers charge hundreds. And there's nothing that actually uses AI to help you improve. I thought — what if I built something better?
            </p>
          </Card>
        </Section>

        <Section delay={750}>
          <Card style={{ marginBottom: 24, padding: "36px 32px" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.accent, letterSpacing: 2, marginBottom: 16, fontFamily: "'Space Mono', monospace" }}>THE BUILD</div>
            <p style={{ fontSize: 16, color: BRAND.text, lineHeight: 1.8, margin: "0 0 16px" }}>
              So I built APEX Perform. An AI-powered platform that gives every actor access to the tools that used to be reserved for people who could afford private coaches and expensive classes. An AI Audition Coach that scores your self-tapes. A Resume Architect that transforms your skills into professional casting language. A Headshot Ranker that tells you which photos to send for which roles.
            </p>
            <p style={{ fontSize: 16, color: BRAND.text, lineHeight: 1.8, margin: 0 }}>
              All of it for $1.99 a month. Because I know what it's like to be a young actor trying to make it, and I don't think money should be the thing that holds you back.
            </p>
          </Card>
        </Section>

        <Section delay={850}>
          <Card style={{ marginBottom: 24, padding: "36px 32px" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.gold, letterSpacing: 2, marginBottom: 16, fontFamily: "'Space Mono', monospace" }}>THE VISION</div>
            <p style={{ fontSize: 16, color: BRAND.text, lineHeight: 1.8, margin: "0 0 16px" }}>
              APEX Perform isn't just an app to me — it's the beginning of something bigger. Phase 2 is the APEX Market: a place where real casting directors from major studios can discover and hire talent directly. No more cattle calls. No more submitting into a void. An AI Matchmaker that reads scripts and finds the perfect actors automatically.
            </p>
            <p style={{ fontSize: 16, color: BRAND.text, lineHeight: 1.8, margin: 0 }}>
              I'm 11 years old, and I built this because I believe that if you have a dream, you shouldn't wait for someone to give you permission to chase it. You should just start building.
            </p>
          </Card>
        </Section>

        <Section delay={950}>
          <Card style={{ marginBottom: 24, padding: "36px 32px", background: `linear-gradient(135deg, ${BRAND.primary}08, ${BRAND.accent}05)`, border: `1px solid ${BRAND.primary}20` }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: BRAND.primary, letterSpacing: 2, marginBottom: 16, fontFamily: "'Space Mono', monospace" }}>BEYOND ACTING</div>
            <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
              {[
                { icon: "🥋", title: "Taekwondo", desc: "Training at Korea's Finest Taekwondo Academy. Discipline and focus that carries into everything I do." },
                { icon: "🎓", title: "Student", desc: "Studying hard and learning about technology, business, and finance. Always curious about how things work." },
                { icon: "🎬", title: "Actor", desc: "Active in casting, auditions, and self-tapes. Building my craft every day through practice and real submissions." },
                { icon: "💡", title: "Builder", desc: "I don't just dream about ideas — I build them. APEX Perform is my first product, but it won't be my last." },
              ].map(item => (
                <div key={item.title} style={{ flex: "1 1 250px" }}>
                  <div style={{ fontSize: 24, marginBottom: 8 }}>{item.icon}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: BRAND.text, marginBottom: 4, fontFamily: "'Outfit', sans-serif" }}>{item.title}</div>
                  <div style={{ fontSize: 13, color: BRAND.textMuted, lineHeight: 1.7 }}>{item.desc}</div>
                </div>
              ))}
            </div>
          </Card>
        </Section>

        <Section delay={1050}>
          <div style={{ textAlign: "center", padding: "40px 0" }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif", marginBottom: 12 }}>
              Ready to join the platform I built for us?
            </div>
            <div style={{ fontSize: 15, color: BRAND.textMuted, marginBottom: 24 }}>
              Every actor deserves elite tools. Now we all have them.
            </div>
            <GlowButton size="lg" onClick={() => setPage(PAGES.LANDING)}>Start Your Free Trial →</GlowButton>
          </div>
        </Section>
      </section>

      {/* Footer */}
      <footer style={{ padding: "32px", borderTop: `1px solid ${BRAND.border}`, textAlign: "center" }}>
        <span style={{ fontSize: 13, color: BRAND.textDim }}>© 2026 APEX Perform · Created by Armaan Juneja</span>
      </footer>
    </div>
  );
};

const SettingsPage = ({ user, currentPriceNum, isFounderPricing }) => (
  <div style={{ padding: "32px", maxWidth: 700, margin: "0 auto" }}>
    <h1 style={{ margin: "0 0 32px", fontSize: 28, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>⚙ Settings</h1>
    <Card style={{ marginBottom: 20 }}>
      <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Subscription</h3>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0", borderBottom: `1px solid ${BRAND.border}` }}>
        <div><div style={{ fontSize: 14, fontWeight: 600, color: BRAND.text }}>{isFounderPricing ? "APEX Founder 🔒" : "APEX Standard"}</div><div style={{ fontSize: 12, color: BRAND.textMuted }}>{currentPriceNum} · Unlimited AI analyses</div></div>
        <div style={{ padding: "4px 12px", borderRadius: 6, background: BRAND.accent + "15", color: BRAND.accent, fontSize: 12, fontWeight: 700, fontFamily: "'Outfit', sans-serif" }}>Active</div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0" }}>
        <div><div style={{ fontSize: 14, fontWeight: 600, color: BRAND.text }}>Next billing date</div><div style={{ fontSize: 12, color: BRAND.textMuted }}>April 1, 2026</div></div>
        <GlowButton size="sm" variant="ghost">Manage</GlowButton>
      </div>
    </Card>
    <Card style={{ marginBottom: 20 }}>
      <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Profile Settings</h3>
      {[`Username: @${user?.username || "not set"}`, `Email: ${user?.email || "not set"}`, `Public URL: apexperform.com/${user?.username || "username"}`].map((item, i) => (
        <div key={i} style={{ padding: "10px 0", borderBottom: i < 2 ? `1px solid ${BRAND.border}` : "none", fontSize: 14, color: BRAND.textMuted }}>{item}</div>
      ))}
    </Card>
    <Card>
      <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Data & Privacy</h3>
      <p style={{ margin: 0, fontSize: 13, color: BRAND.textMuted, lineHeight: 1.7 }}>
        Your self-tape videos are encrypted at rest and auto-deleted after 90 days unless you choose to keep them. We never sell your data. Full privacy policy available at apexperform.com/privacy.
      </p>
    </Card>
  </div>
);

// ─── APP ROOT ───
const AuthInput = ({ label, type = "text", value, onChange, placeholder, error, autoFocus }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>{label}</label>
    <input
      type={type} value={value} onChange={onChange} placeholder={placeholder} autoFocus={autoFocus}
      style={{
        width: "100%", boxSizing: "border-box", background: BRAND.surface,
        border: `1px solid ${error ? BRAND.primary : BRAND.border}`,
        borderRadius: 12, padding: "14px 16px", color: BRAND.text, fontSize: 15, fontFamily: "'Outfit', sans-serif",
        outline: "none", transition: "border-color 0.2s",
      }}
    />
    {error && <div style={{ fontSize: 12, color: BRAND.primary, marginTop: 6, fontFamily: "'Outfit', sans-serif" }}>{error}</div>}
  </div>
);

export default function ApexPerform() {
  const [page, setPage] = useState(PAGES.LANDING);
  const [showSignup, setShowSignup] = useState(false);
  const [authMode, setAuthMode] = useState("signup"); // signup, login, google_username, confirm, done
  const [authForm, setAuthForm] = useState({ email: "", username: "", password: "", confirmPassword: "", role: "actor" });
  const [authErrors, setAuthErrors] = useState({});
  const [currentUser, setCurrentUser] = useState(null); // { username, email, role: "actor"|"director" }
  const [stats, setStats] = useState({ auditions: 0, lastScore: null, dojoXp: 0, dojoStreak: 0, profileBuilt: false });
  const [profileData, setProfileData] = useState(null);
  const [talentPool, setTalentPool] = useState([]);
  // ─── WEEKLY HALL OF FAME ───
  // weeklyScores: [{ username, score, timestamp }] — all audition scores this week
  // Resets every Sunday at midnight. Min 3 scores to qualify. Ranked by avg score.
  const [weeklyScores, setWeeklyScores] = useState([]);

  const getWeekStart = () => {
    const now = new Date();
    const day = now.getDay(); // 0=Sun
    const start = new Date(now);
    start.setDate(now.getDate() - day);
    start.setHours(0, 0, 0, 0);
    return start;
  };

  const currentWeekScores = weeklyScores.filter(s => new Date(s.timestamp) >= getWeekStart());

  const hallOfFame = (() => {
    const byUser = {};
    currentWeekScores.forEach(s => {
      if (!byUser[s.username]) byUser[s.username] = { scores: [], form: null };
      byUser[s.username].scores.push(s.score);
    });
    // Attach profile data from talent pool
    talentPool.forEach(t => { if (byUser[t.username]) byUser[t.username].form = t.form; });
    // Filter to min 3 scores, compute avg, sort desc
    return Object.entries(byUser)
      .filter(([_, d]) => d.scores.length >= 3)
      .map(([username, d]) => ({
        username,
        form: d.form,
        count: d.scores.length,
        avg: Math.round(d.scores.reduce((a, b) => a + b, 0) / d.scores.length),
        best: Math.max(...d.scores),
      }))
      .sort((a, b) => b.avg - a.avg);
  })();

  const performerOfTheWeek = hallOfFame[0] || null;

  const daysUntilReset = (() => {
    const now = new Date();
    const day = now.getDay();
    return day === 0 ? 7 : 7 - day;
  })(); // all actor profiles — directors browse this // stores { form, aiSkills } after resume generation
  // ─── PHASE 2 DATABASE HOOKS (invisible, ready for APEX Market) ───
  const [phase2Data] = useState({
    applications: [],
    projectHistory: [],
    matchedRoles: [],
    savedSearches: [],
    directorNotes: [],
  });
  // ─── SCARCITY ENGINE (Founder's Pricing) ───
  // In production: pull founderCount from DB in real-time. Stripe coupon has max_redemptions=1000.
  const [founderCount, setFounderCount] = useState(0); // real count — starts at 0, increments on each signup
  const FOUNDER_LIMIT = 1000;
  const founderSlotsLeft = Math.max(0, FOUNDER_LIMIT - founderCount);
  const isFounderPricing = founderSlotsLeft > 0;
  const currentPrice = isFounderPricing ? "$1.99" : "$4.99";
  const currentPriceNum = isFounderPricing ? "$1.99/month" : "$4.99/month";
  const pricingTier = isFounderPricing ? "Founder's Price" : "Standard";
  const founderPhoto = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAQAAqsDASIAAhEBAxEB/8QAGgAAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/aAAwDAQACEAMQAAACwWi8/bnw68NZ5c956YyLmxAUAAAOpcu2/Lrjt2VlrjqLWpMNNXMTU81zryYxuEpb5ibpAA0DQAJDcspIAaKebLhhKqUTCgAAAAAAAAqamrubx3bRNtAiY1bQEXKSwGArEM1nWdnpCXPE4a5bzv3dfV0x4vm/V8MfMLTOwAoBgAVpltnfV1YdXLvdlxJfOzHk3j05NFakjSORCBWVIAACYAAAxMQxA0AAxJioasAAAAAAFLnSWqVY9ABNjGg25JVSJBdJsExolSZmNIs9JbLnjlWs7z9FeenTmZacsfNcvRz0BVJ93RL5B28YdGPRnfX1cvTz67OUX5GvBrmmG8MQJObASGmIhgCAAAEDAAAAAAGkUhDGLIFgAAAALWkaZ6VSeO4mTQ0WW4qQTRINpUNEMZkasM9c09iaXPGMbzXd0+bprO/n64x5ePo8/TPN6PD9BrPXpo5eXwvp/KPB6MNprr35tufboxfDZiqW+Km4pSNJBUAIAAAqAQAEwATAAAYhoFTIYDBrKpCAsAAaa3pF471SeOwmKgEbQUgE0LVRTJNQgJ2GekM+3Hf5+eaY+eqqahTXRqRXcejl4nX3cZ2vKorzOzxTg0jSa21xrPWua89c5GtZWdIkc2JpiGhA0BipMRAAmCaYCBgCYAMBMExFSxZAsAAaqW7m8+h0njqAAmACVoSMQU5YIEBOnFwz9X5fbxTgmjnuyZjT0PL9DpjtE+3NcXZ5ksXynLpXn9WBlYaluXNzI985hyimlUOoRpOhU4gtrmasyWxLguiLMilZIxBMATAAKBQZEoLBpkgUAKXOktWrx3GPO5bBKmsrRriaozrSjE3kwNZIKQRUXPspHPi0EpFTYa4FetfkzvHdwZzNbGZjRDiwQtZoJWNMtOmM5rKy8yATsV69MvLXWTXPfQ5eeemZec3Jcc+rNOTPqy1nA0WswrEhWVDGg05QciTVg01kCwAWtM9M7rXPTHagcqKSlGonpSZLVLLpyTO01jG2S5xrC5565WeuhceTSQ4MtLWT1NphklTYCkcEpVSzSaRjrnr0zGO+dmVaMz6HvNVq7zqHZLmtEZmhm5TrK5xtMc2XVnZzrebOc2jWc1c6zAxJaKpIhKlSaogasAFrSNM9buKx2qpqKFSVpGhdTSKXC08yXWZSEPO0kFjPXJPTULHJyoR5PPULxrU1ebltSipUWNqkKTl0TDNj64ZMlXlsuus743VqpUUiVSlSaiVUyqaREaTLlOs2ZZ6xZlGufTnKaslOUGnQNCpOITWg0ytJvHaqVZ7OpqSmNK0yo2M2POolSSXQzYS0oAGWuNx0TmnHQirFNxZkKat5qzQyZoK4qlWaMctjqXCnXbnGe8kbRvnd9GW+dNqgTCU1Kk1EqplSahTUrMaQROkGOe+e84rSdYidJ1IYXLKUqGGaa1HU3Lek647joz0mkxtNGKZdTMXRQ0QIGhppDTGMrDfHXME7560zseWmJjLneRphSuHpN51THmjVFXN51nUno5Uq3zZ11jHR0ENhTTQJqVTUwpalSZLKciTUsxcpmrVZLWbMjSrOWezHWMinqTNwmapbj0jTPTXSNMdqB56QUlloZECjGrYMpNNSIaKjQuqpzy5+3muOcS356rFptkopS1cuptXa0zotVk2nKMcVc3NZKp78+3ozvnuGVNA1YOQtJDSUrQoUtSiJUSUUSrCCBkkUlRBaBpkc/Zx7xMB0xAOy7jTPe7zrHbS8rmqBpE6wQVLTaZbQwlcLE1LT2x3Nbm3JcnZyXPEnPTzpJWNAgDp6RpnVXN4raqVtMGtIrTpp04J3y6c+2lGNVHGanTOEazssZOi+QzruOUl7Dn0zbSSkLMqYzs3jKblwlrKKYVJLvfI83sM9cbOTq5dZxGuvOKnS13N47thnq7iprSptgm5IVw1LEt1FM3FSRFyPbHY2vKmHy781nHIuvlEFgAFK5TRXm0x5rY5WDg2y2Xbo5B36eLv4t8OuNHLhWhZKcrGG8nLPRnGbuli6qA0mXDDo54iaNZlUUtJqNKyqWk3LlOwmWqqU5unm1MVp06xPUly7Y49GW9ItXUsc3VzSDSYaYsK01FBKA7JVJVpFJo4TFc2vPZzlV18mT6dZeA7M0xu6lVlZqbJWxwNirXOjozu5335urDfLeptM89+cyeHLXoc88W+e0czjr6ODqz079I2lM+jOTj5+vmxvGajeYqY1jofCXPacejXQ+fTN6HltjboebPN1c2svaHNVjUtVU6a0LRLktJaGgCRKrOi1RCViwWiBioEjipuZy1xsrbp1ebLTas3CepHFPZFnFPTgSMp0rmm6c3mtRJ7OXoU59sG+7SL3xItGOPTJyc3o515b7plx2fQXY4qWk5uTs5efTBaq5570NziXctZ5q3cuGtaY07p4sFyRltjqJZO3aLc2rzrWtA0M1sGK3hMZ2TUaXaQaNMlcSolKQ4sZLqk1EZb5L69up5m20U0ozz2zOfDfCzNjp6RpN3U1NsYsaTSaZ9GGm9xeubTZnOilxjZS4GzsjSnZIyUmpjDm6ufnvGhinZ2cy6nXNp0aGN6IzmpzVLROWudnOtDdunOdRarWtNctUtumYjaDF2mnc2yi5TLLbJvKHLRNzcQ2K3NS3ltknr0nONCJGgSc9JObDsxTnNJpXLl0rNt6EEtuaOlrTrIuKZpp0pqZVLnNZIakVrLQ4UaYy55Xnz3mqk0vHUqk7KqHVIkUVMspqJzvLUm3TTllstq3S8bTovC2blomXLV3laWhpGW2TWE7Q2laZynSG5qRvWHLn7Q1ngAAwZFQZ57qTmz6szmW2VIAdK5Xabptrlp0zFw7LcOnBMpJOaEONdcdNZbyLLxeOdTCnGrrNwrzrU1cUUSS0pStJDQkUtWWm5UC3sklRw03vHRnYhiipU0yo1cDLzrNoSTdyJIzrO6GidCKi8/oULHnBEtNO5bTQTUKNJMsejNrmNJsek3KyhscrUu861iiS1ypghTmvXHezXPWtZ8vp6MrY59ufKObZRhu2r2ms1uEaEBSSlZKKJBhnZ0GUN6LJ66XMpqnNM6XnbGjzC4mWrrNpsoGazsXJ0TqpaSM9Y1JVJZi87j6JWufCShUwkABoStItU1JlGkQXNrQNoGWTSe8KailNRGctS69GGtzq4djipM8N85rHLriOaqWbRIEEWXfO63eV5rQA0ww259abkvSiXNsG06TkpyXnUtCFLejzcm2mW950VTOM75zpitZXKdZsznSVjHfHWPowfPzoaVAKIUqTlWSrqpaJi5RWVAx2oaFUmsubVkzpNnLltzxr1ecz1X5JqescMy9sc7mt8+XKXpnmlnqXHFnZljVg1pZeqfPYJyjQLDTPXUZTonVM5mktS05aqaZZTuc53lrnLhdejk6GOi87c3ncpnNw1KEpFS1OG2Nn0TRjztMJmpaElKJKGgumhiKKGwQ0CaRFNmQNxTUmMbOV6FWY4d5py59815+foZzfnZeplHA+tZctdBJk7IydqwEStoGiKgTvodS2tLm3JRpCZDluqlm146JSEsRpBOsWm14WxqZiPN5gpdorUuWPRhX0FSc+FCLSHE0STLQUklFS2lGFrAkE0DVMtlaxnl1Y6RLTSY4qpqgJRqYV5rOacJS0k5AbiU0JMqQSAnVRs9a51vDrm25qrzpmpEkjFQ5C8xrcyctyNliLl1iW7GJLrCEdLRlt1ZjzdnKe0Bz5ASrh5tIRLpUaaw2NmVaIVDYyokoZmgSnLsqQs546efdHNTVVNAMSI1UvPPSl5p6VLzreMs1UyyhWEk2CFqPrx7kxW2d3nGkzrkrltCS0pIpxVrQJKclOLSqloIViTLZbM7GyStMrvPWsnY+XflPcaOXETSxnpk2OdKq4u4upq4JpEApqqmkAdiHMARVHFPTHscnbO55xrnz6O8rl0JFomhJTK5UymZGaSQhBnqMlaj1fWzVxaPHTmbrN5T0OUnRoQAloQMQIFcVpGgylEF1c51o0xW0y5ukJuUBS08NMq98Dn5iaS5565tq4sulVxTTuRNEjFTQlklzSnn3N+Tn5d4fq+T7dd2uO5y8vp8edcqFndPIl1MVLrnlEu04ouYUVKiwT11nLp0uQoY88/K1noOU3n0Tk6sdSdlnvktFOmbumsjVmJuqwezuc9KuINBIqqZVU2M51lcVpEszcNTNQ2stM7PfQufmaSaWWmbRUO3a8rudHFMMQjRFVOcdMbrl5t46fOQIA297xfoxbRYTQcPne95Wdc65d8dHNozKVSrlIWlRhW1JF04VNFZT5eszDN5BA3IdXV5nVL1JE1d5aTtTunXNaiZrUIdtIdMl00ltyQrRlG0rhn0xNc87zNY49eFz7EueeKSSqaSyNWF5FdNc8Xn18/Bj059WELWKSYAqaAADq+l+U+oNFXmG/Lhob6+TrOvPx+thJHVjodOm06xnj0QnNO841kaGbLcixrg1Mshay0ADBDAAOvfzt5et53LpvytrsMNnZiatohtFNyxiJGgUVBE6oyWxLz8vocjPYnPKicgDBHNca48+fXntkjeABAAQMEOkxAAP6X5r6I18Lv5Zcpy6M+sYsejPLTNiAWuPreh819HvzGdZyKaWbI5WYrGzn4KWsoAAAAAYAADA0zZ0bcBL6d+Xqvq1w9U67CHQEFOQoljExtEUIRgC5Ozks6GVx1nOzTDn7PF6crzR05tBY0AAAAAAAAACYP6H573jhSU1mdHLj1aw5z6Jgm8M66635V28W2sds6589SUETpJl5PZ524KlZJShDBDBDBDBMAYAMEwDTMX0unxeub9Ai53GmAANBQgoQlCCuTq5U6qjs5TPqeffj4fDU3AmlGgAAAAAAAaAAEAP1fJ9GWnrc1hyer583Ed3RqcdLPXGFFZ1pqbS63z9SQMzYy38azmlrcABDBDBKlAAAAAAADQMQMVAPqlw9WanS2DsgQNA3IUIKEFcvTys+n2xevOvN9LwLnzwaoGIaBAAAJgCBiYAgAD0fO783tc650UlvMPDg3Ojz3fLt0d8dUxK1uzmvojWVOuMvH42kWCZSAAAAATBAQAAADQAMQ0DA197g9TOpnaJcJ2h0zG25KUSNWgnTcsfL08rP0ILfmPmPoPmkQCppghAAAAJoAAAATAAO7h7pe7WDGnzzg7d3m+odfN42aXL0+r3/O+/eWuueusNUrM/K9D5sQAACBgJiAAaAAAIQwQMAAADTP0ZfR3nSVzSshUs3OdYzuFam85uNaQLVYA+Xp5U+iTW/L5/iep5aJNKAAmgAATBNAAAAmgYAdfJvL6kHDjotcNc+31ubl7vR83DyPR1zfN9jxvU59/S0mt+dy/Nrz+MAABMAAAQ0AAAAAEAAAAAAA/f8r35S3AkXKovCBNSiDHWYudazGtUAo5unmT6IFvy+HwdfJYlSlkAAAAAAE0A0CAAAaYa41HbyZa49NaZ9GfTEmOuHpaY9nfxcZ18vLr7DVaxh812cIAAmgAAAE0AAAA0xDUAAAAAAaHtehDUhPJ2Y1MlY0kwlOc9CbmbidI0QLdObp5k+iA35fnOfp5rBDlkaEDENCaYIAAEAAAAA5omtccddNs3j16mQ1XseL39fFl0c/oMdHLt8+ziwoTBAAAIGIYIYIYAAJkIGJgIAfdw+xHpZpq9FAZFZ0DmAAlN50lZnWcbRWU6RvU83Rz6v0YG/L4PD6vlIwVomRLAE5GgAGIAE0DASaBpnZx9JnQN8/oSWQo2jXLs7ojXk4fOa1kAoTBACGhoBgCBiYAAAAAAChoCve8f2M3TeIVw7hO4pS1muakVTRQzGpmyMo3i3n5O/j3r6BB18/L899R84mYnagIQAhoQAwAlgmmCAABNMv1fH908vQrn7ZbMd47OP1NeXTwuzy9+ZgagAIABMEAAA0wAAAAAAAABEAB3erw9mNVRoMc6imiWUEEVMrpMZLxqhNEqlc+Pu4q9tNd+U+N7XEeG0AmCBAmgBgCAAE0AAAAhler5Pq6mvF6/jY7aTWPH37deXm9PnZjW8AAIAAEAAAADAAAAAAAAAQ0KBrQ9fpy357emeuolSsJecqpOIBysrMFJz3pWdWUgRcfZx17Ka781ncnzc9fGMECaENDAEAAIAAAAEMTD1vJ9I9Dg673nzcHlw9mvMnvygFCaAAQ0AAAAAMAAAAAQMQAKGhB1cvfL6W2emNXonvKRAkVmkVIqLU59coka59KvOk0SLDk6uQ9pNejlM1J5vk+/8+NzQhoQ0MQAAIABAAAmDVC1zR9FWU9MeTz9PPz2AACGmgGgTBAAAAMTAAABABAACECaH6vk+5L06x0SuDPUabzUEiY4dPnqQMaQzNTQU5YcnVyHtpr0clNSR879F45wtMaYIAQ0CENAAIaAYA2gADt18xoA1QmAmAAIAAENAAMAAATQAAChoKQKBNGvu+b7GdaqSwqgSaFNEq1M7IzZjSHMo0ZoNIxCvk6uWvbEd+STRnw9+J867gbQNNBLQgABANAANqgABAKgBAJgAAACAAAEwTTEwAQAAAhoIEAIQNdh6PQtsauqW8pCVAQaOBYOc6BqCWs1NGdMSpiQ+bfms9u89O/KU5Jy1zPK4PY8cblgDEmhAAmAmCBjaY0IBAyQsTEAJjEAIAAAAAAAQAAJiBDQQIBBRfs83oZ1XRlvYk5sENVo0TjWOKMJRNCms80JWd2Q7WlNPm2ws961PXhU1NTnpEYeL7fmrwtOxtAJgk0AAACGhtAwBLSzB0gBiTQMQwQAAAAIYAgABACAFDQCADtw9aXXad826J3kQ1WjSLKsc2UPOhqiAIWG/NNJyZ2yVbSlWVheNn02O+HXhrDKmKmXHk7OeXxzTLWacUCpCBAACYIaBplaY9SaZVynb5/o+ctksaaBgJoAAAAABMEAIEAIAAQQVPWdPfl0Y1XRneoDLC2gzeUs5sxoYAxEpqDn6OebkZneauNWYqKMrxuPrctZ68MNcblM9czLDXLN4OT0fO1kaKoAE0IAABAA0w1xD1seN2b+e7lFYAMSYAAgAQwTQAhoQAgBDQQAF+nyenm66ztLdD6ZViCHETk1jQ2yRik6ZIk1nRz74zUqpm5zrO0zrOxY3lvn9mmt8sM+jmzdEissOnGObzPT4DFo1KcsaaBNAAIABoKTBMBgJMAAAQAAAIAAAQgBACACAAKnpOzuz3xqujPbcKFYSTBjU5qoaiEAqKw2xhAZ0sds5qI1lrnz6Y1eeOpWcmXdjc/Ugb4rm6c4wcPOpzrMz8/0OKuMT1mhMoTEAIEAANMAYDAAEAAAIABDTQAAgEmgTQAQAABR63D7Gbpc7y60G8kigh5yoHKNqxJqU0m7MsrjGgFKKi9IWhdZLYXBbhhz93Nc+25rfmUsOWN+fGlnpEY8nZjXllxvLcsppgAJNADEwGmihMABCBoBDAEDTQIAQgBABAAAKgW8ej2Zb51fXGmskiCSFJbgbBJoAB3IYS1z0JpaY9dU01ABDBcnZyWeu0b8wmieXrxlwkMXPLTGvOlm8wUgvOikAhoGmMYSwAAaATENAAIGmIECEAKAAAATVAgPQ4fay37TSnKQBIpdSpspAoQAMZWevOZgc9oGUJb7USLQiRuWPk6uWz1xPfmJqRTSjjnfmzqcN+c440y1lplQNGkpiTQNUMQMQMljSBoAAGgAQCcgCACAFTQhiADc6PoY3gkVAKEm1TGCECagAClVPl6ObNQGNIC6ElrrRItuGlEhXL0cyeyBvygIlOYXF3csuGG2MvFlWes7AVJSJGhABU0AgAQxAAAAAME0CaBCAAEAAgBiZoX9Mt0JBUNQIYmAAlE0ICAAdzdmXPpnjaGs0lzrqAXYADQMBDm6eZPaTW/KAgi5ictIl4sOrCXi5ujm1nZy6YkCEA0DTAEAAAACGDAAEIEIAAQAAAEAFP6HzPoxpoQAJkIYIYIEogBBA1QxxZhFTy20SsrN776PKi1IUSiyQvm2509xNb8ohQ0BGeuUuPH3cMvmxS1nRooTQgABDAAQDQMQMTG0wCQlyAECaoAAZCBg12ntdaKE0AAAABAhAgUTQA4GOnlrzxmg57ObfgurMze9niLsZEamSNjENsKxT6ROd+YQpWgQz1k5uLt5c68gHrNAUJghoQ0AIK1kzWkAhgDG0hIQgAAEDACAAAA+h8L6qrAEAAAAACgTSiYIAGMAEObfnzqQMa5uXXLfRAUxNQQAJGIHlpkn1E0rxkoJKSJUHNx9nFL5Jc2MFTBDEAmCBFXnsZr0OQ56ixuaFLQk0AAAABAAAFAB6Xvef6KCBQAAAAgTBJioEDTBggxGOVRz2J5S8Sa6dEAMBUMRJoAYstsU+maLxoQjQBFcq4YNZvnxcaywVAA0AAyUwLkKxtibQCAlyAAAQAAAAAAUNdJ9FtNCAAAAAAgTQIFQwGCFJkw8pc0HPRzdPBdQkb2OWNoUAEmkGmGO2SfRuVeOhmyiWLzu3glkVR5sudZpNUAACGCBoGIG5BoBAgTQAQAAAAAAABR6nl/QJ6DBUDEMEAAEJNAMAGDAJeZOVRjaAynyu/zNa0UFtvMNTNlkBZm1t5uryrNPpUqc5GrAQHF24y8Nyo80T1lgUAxACAAAAQ0AAgBAAAAAQAAAAFABX1fz/wBElAKAABAACYIYIYA0CIDJxnSmoxWAefx7ZaqGCAAYIaACgQOKiz6dtIAgTEUaKuTg9XjzfJGtZbRTAAAEAAAIAAEAgAAACACgAAABgmz2/SzE1eVraABqAEMTAAGkNJChxLKZjUyyCL5Tz0GqAhgAAoMENAmIo0zr6mbm4lOZQSLJLDHeTwsPT8uygKYmCYIENAAgaAABMQAQAUAAAAMTTDq5e1PdTS02iqzooQNNQxA0SUkhyKWYqc0QpZacp5fpeFYyTayHFEhZIUSLakSiQqHJ9ZFzrMxpMsKlEsAchn4H0vzusyBQ0DQAmgBAAAAJoAAAAGAACBoAYB1ctn0+saCVCQXKjGCaBCgQSgFKazylMzpS5gYHJ5PXybgBoAQxAxAAACG5CpFX/9oADAMBAAIAAwAAACHbdssEF1I8SSZnuvwy1ATgzChU+EEEEEH5O2OoRGfYsTYmDg93kFG5cDRx8f1+NcMuM9ftoUE2kj303WvdyFSGlJZWPf3qbYN08ahWxPcsMeMN+Md+532lT2dsHqMq/uhM7VDntMxEn5YcguR+N6/uMs/sfOvTr2ECSNOtYgYnaluzrE7Taus5Qt2jGhyMRMtOs+e/d2cKkFtS/wDbW/fLbds6oCXJmxWsMLLWLZjOtW9orTbfgX5rpE5lPHeIuGsnSOJo5WhiGqFNtpG6ftJF8XKpHYp3HBkpUOu/kYRcfUEUEvTAEIV13iBuFZZBidzEBSHjkvdPgYhU5B8K1J8+/kAuAnHRWyEzuZRrkaqByXq9KxOFSP0hrMtnM9RtZeXLvfjSyFmR8RN+SxDhra68/n3m1mgnwlkccN5040WOqHvC3ZrqVoi/sWJxdv2313CHb6lsfom+3Q3wORbir7zioJMlKwXBXP4hMT98LiV+Ge/z0jdl/D3xV97YeuGCl0GlTMvW3O/5C7aN7wer6dyiBbtZ8dpyKX6P9s6vyzGlk1Qb7HqSd9q1VRfpwJ4Kw41gbQyKwtJArWMvLsVKAnqoipttV0EgvSJ2HkldwM3GVx043AAnL87YsuQSFXQorFXSHyudnWcA1vVUAdnhkcfaeNOd5z6Ad+3jlLYt7wT3FYqKH0hqdRe+vpSHozPgTqKNx4Znhz/Aw6eOp8iUEViFnwKHyRngTJRXXuA2/wCFQdnnGH56vyobJ0azUDfkQdUD8ktg+pMbkJRHzzQR9qpGkuNutzuplWcotcTbRP02yPht9h25bOQZ0cNjwoAcnT+m+7WoCVypYvf7/p5GiFCdVFRm6m1GPNFB+ErKVtHh4VIzJitoMriDLLnaTMHvA3V/T/XbohWiAw6T9zPAN/5zMtAR1LzVNQBAbSrRaj/O5vINVYmxmEHhMWUbyXxFN1asrcRoo/lYjqkbklWxKVpvTbDef6k7J+7+HhU7JtvxH3eEs+N79uAOeuI+kTS+Mph/VuyyJtSzbtNRd+bu2Qm52kUWILw8XO3jssTsesfP+OcQ6q6Btvrbs4tmXS8bw6RpJec43urGOp/JMfegxIRDaIRBqZDgZItBSMV9wdKcXZJySDfS2Qza5oR5BZf3gu/9IGvfMaJ9AWUbF1VCfe1X8pCYHH/44LoOVpi8jnovRcEVm6Ue77Uz2tAsidGzJwxWYHtO1mqEky0wyBnssntljyCb4LD3glaipxcF9Sq4+2ZePNsBjDKVc5KOzjjsltybnEQPRCEJl/7TKyXmVZUEPIEOZGGBro96R7AEggn+558bWNQLUJFFVUSiNVDMGAPogOOaPtt32bT9xCPAEgg3/wC88kIGASCxRQExXgjZyRBwgCD967J+s4fF/ijTzgo467vffiigyaJkjVAvKoqBQDgAjTmZYMbTQKxADgjzAALJvOv7BmHfm7XFbzP4hQBxQgCzCxHQpITsRzhAARzzwLJYquHKQPWhiPWIQXL7pYBTBiSgsiCnEbRSASABTzyiY5659Bv3Lm0RZzKrnqKrKhyjxzhj8Y1AFLhCwDjDDABLqL4fFkAZ7pgNVgLuzo4RjjhSDTz1xebXMBCzRwDiACBCZ4srcEZq2BPcpisiqKLx5ihySg7nGjbACyhyigAQhgA7YdPba353gGYf7Ib6ZRgbhSwRgJxrzSBiDjxwAwTQAQbfIrYLkL1qxuFIia7LQawyBCQiipGuBSzSBTwDgAwzY6aYKtsPBGCRCIL27rbZ7hgSggDjkDwRTDjzziQATqI7YnhQI6dggFSgf61ILK7RTyxATyzdBgyAwDTwBDTgZi7bb5cNKHGSTNxCyjXqYJDiTTQhxChyBAigRCiAziQJoa3/ADMvGMhaGFhhBtR5CqMAQQYQOckAA4I8UoAk4IkSS6ZhnYw3FprXIsYnRbA6m4EAAg0ks4SUkk848A4k8ma+hrno3z+qrlhyjO99CwECysIwk0f7sY8gs8kAQgkkweppunTC2umXBnhYkslCuBkyAIAow4xAYwYA4YUsMgka+zrskxjPo9SIcHTdEXgRbEOUEA8UMAgwQUkA8g8sk6WjbUk/bCGNBi0iCRfwbKiAYUqIss84QAogcEUoY00iC4ZAc+CiF2l+Ei0+6JIYavSIE0g080UYgsIwMEYEECCEq496MVS3luDU7rHjU04wL98okY0Mgg8YkYEossiiCUsrVuhaQutjFi7tM3rQIgj01jIMA0oMQIcQ8Qs0kCEUM4qErwYMHPgUAR9cNM4Bk/V8XEkUoAsEIoAoUQAAYk4kDY3LvOUv/pY0UkI8xwR1ruQJoA8g8EwgEQMsAAcMGccAoTzzscbK1/K4JR1xa9f7py2MggEUogMMMoUCU8y6GcUAN/f4UK4v++VEiGGypCT1e6QQEkE0oQcIggA4CCCMg859nUQMgfw0i1IMlVrCy3H92EEMQU44EI4wAACOMA7YQp7TSkslnl2h9MxVZn0Hb8+7EUc4UAoQgEACGe+8UqIAkrTYwlrtriJpkg1pb+I6AZm04EE8ssQ0kO++++8pi4wsL/VfLR0B0a2bzKoxYN4gp6woAoAEQkk84+++88vUMDDTDnXnB3RxDPT3J5xU0zU+2E0oIIIAI84CE884UnYUnHLDnr96b7BFB0wkREbiFVz98IQsQscAkiEc84oFUGI0/PXFaxJov8K/BwR16YQpp+h4sc0cgQUsM4AMcgAeH2gc9KArSLhP9/PLz3vc/9oADAMBAAIAAwAAABAatLKwyW5TfvAabFlmRHqJWJliWAAz330W5MnFTLLj02RAz9qBnnM0go8qU7flhjzgWH0m7X3FXTNvpnMu6KxpalAre5wjy8vI4RoS5QAzDzTiQzT02kFWz4kKBiC+FT2p+zT9fnmRsfyXVb62njADAhAiRixMIF20KM0uDMCSwBMacjVfaYBcvtwqS6bzplRDiTDzXehhX2fiLXGEaaDenMzEmkqGj11chZT7A/TVPo7whCDL++FXiNt03ioGyfw8jEx0ocy5eU2U1xilwcEoHOJ8nOY+vpWieN0J9BxeGU8PrqYo+VHWenIcLx4VWrjo+bhVmgNZ5W3Rfvli5mNqTgrjO/7uv+DbHv7Fu6YzyN2/Nt+FJ3yfAXDH7YwzMaP9M76mVKe8b5HGMVzhtkOiSsXgSgqzzIuhc04hGeEn/wAobRQlvLibg44+AtZn2cEYMScK5qWo5OpxwxkIC+w9X6qjCHbJzAYBfnFlupS+f2uJC2hMuFhWWYnf1jt9znNicCVxBMzRkNpQd1G2NvlKGT9omXDVFftMuCVkXtEnbiaXRsZdNFw5BGZ24NtRs57Qg/q5dWN44Cs3giAU6is1v5gwiHtKZfm0bf4AvwcJBP8AkGbfGrnAc3kSuXJu1qYsrBTX1wNQ/mBkBpsglO+SrXNBP6D3ETD89Q4wLGEtdl+Fh8TBX5kTUCvwDcY6X+OXv2IUcOmcF++6d8DIiAa3a4CvVab3Mzt6DQP9iItJ5uFbg15PmD91QCcLJRL9rKTiHhIPwiYsosWEsrXAf7g9JA+QuGMJtSidQAPPbS+mQqJMvsCzrDC2pbX1T9Bx+x7D2hgwB/8ABrqdEWaSFCYtKJBRxkEbZWTqhr95g0/jIizXjLaUVqNdP8SndbA8k3bd0S//AP0B2Wc5ATE2HRU2dYHSeBa48epNqThxxe/wMKWjHq2KQ90bjwCKzuoU/wBw1IBY/niM59NsDQEQpP5baxnpDXIWdLQ9Y9Jv5U6AhpV7SDP1SZieHfEwsUr9VBGYmBxoythbbXimQ6LoN2dxF65Q1evogubiEFZq52Xnq61ewaJ2ReCfAkdQIq6w7kevQ3L5EhJ+9qjdBRQ7NiJt+VdHDJcDEqu5ZvL2eek/enoX4THXeepaf3TelRc887Rgr6c4u5vXRcLlsHfeg1pd1YRZGG7PQ0ZcmjE7VxhM3/8AFTwx9kE6CrBq1OPoI8dQN5F4xxfCatqYlz7JKDed/f8ADbqg1dGFY7CFXCHHG5Nnu2D7QgXzSw4tMj6h47g//wD071K7hkyeJSeAhx1BZP7FGnq51z0xHUrTJ3hs5oBZ+94gqkM51CbGIQfHdUi6Hy53564bdx/DNlkWsN+E1JOQVz7ogoq+9dbKbRQVDwLu/wA28tOfuc+NolWipLsbhFUnxz/vctqbQ1bP8pvqVuSymGVtd8fuN/C4U/3RwCp2EgjyUk+Po4w70kewg8bIWa1VuPcuPeuteNVnzioV5wVlE02Gn8+vMaT1JLLvCo9kbHkm2FN+e119NWS/8FGIFFkEH1W3dP8A7yALWb2Yknl9kxLdZlrbXvlVp4Z0cdvlRZB55RRdTLjTXZKu1x6UUPqp/tThHj7vHzV5C1vAxupRR1FB5l5dFHTtknUPxtwKXvPj5rJpjpfv/J9aou+yNlZJdVFtR9l9vfBBb+vt2KXkjRwHbVzT9HXDJZULGflpFd9hl9xNN1lfgyg3OLhiTV5HtL6Dxn1j37j/AGfcO5kdeYTaRVZSTRT1wuj2IufCQiF2wZkPzXdVxxx+w05XKzdZQXaeeaZR/wDPsxtXb2ePWAwM71KhU9mP91HlG/d9OkllmCVVkVG3sXNPDeJhk2aUSRZy+lBHNWuBWE3+tuO+00FRkmnml21NMt5Nfu1kDwuIZ9OiRUhnEO3kGENHP6JvIQChAA3Gn0suOw30lqr7CXysFguzNP21dkWlUduZMh6YSVQRz2HHMeO/lIJjNVmNufdMLt3x4MmV+FFGmdMbYYAwhABBz2AhM/NZcYd7FH+DiRBJmhg9NvWcW20xbF7qL5AjhDTkXQce8Ln1u1n6sRXMu6yoDetCYm9F232P+fja/ijBhjESesxJjSztHqxvh9qX+q5B90zUtmQ333FfPYsgRBAzRF/4Cpfbuf6N8dEY1Nbr+LkLdlX3/wDJg1UbDK88MQ4og/70zlDjwfXJdnTCjLa+dPhYZopJ7n89zt+XoAkwgQGf/wADMxW4+7Q+3OiNdVF6ue/UrwPa3GkGMinnNMHHHIPtHKCL+XiqhkoISwsi5vPTsBTds5A40te2pKNFHPABOFBKKATcjUZIOLE6MnihpoT0REUYhrx5gBqPHPCHGJPOMCpDMsQl+xmXP0/3eii98pPY53qN42jjMAFAGHjJLtDM+i7ofcErXpf9vHO+TE43JtRA4yL6zkthGhVPLqPIODvw4K4RAD6iPUJXXmO+qu71Kil2vU7cpjpLvmLnBFAHssKMf7VJo+CIF+Cn5Twq68sMgy4ubrKlukCkJhOIAmoxhKKIUWdl1oC6KvTUfKGn/sITrHLL2PotnvLCKEIzx3/vB3AUfRlcyZo2N0FLso+sayuG2tE5chqsgFINKBE//vPL7uTvmqkkuDJzwIDoBtHpYIPmvY7WoloDNPPJNuANOEF7/UhGNDiOWdVWts2sND9JlWJaBtHGvPCAIICmJBGKC74h0VjBGy96Fkva1M9nSbdvHAAIRBGDDOINENGADHIKHOxUUX17A8bd0wEg59trqP/EAC0RAAICAQQBAwQCAgIDAAAAAAABAhEDEBIhMSAEMEETIkBRMkIUMyNhcYGh/9oACAECAQE/ANxjmyEuBO/BqzLAkhoZBOTpEMDXZGKSLrwoorTaJUJ+cuib0WqetEFyUYY2ba4Q7jyLnwyrgn2UbG3SMGHYrY6RyJaV7KflN8E2WN+FjYmQfJZglUlpJqqF1o5JCkmZmS70w4v7MsrkQl7l+ORkmJ+Fli0h2WfUoj67imf5TkzFm3Ik+DsXDMvJLsxw3MQjr309WZGPRD8FpDs9Ti+nLgmzk9LjeSdEIbVwS/ibkKSbJsZijURi4Fzpel+2tX0ZGPwSK8MfZ62SclRJChZ6NKMtMslGDZ9dmPI7N16LiKEtOWUXRuHkR9VCyJiflenzrNk2Mb0TLGyyyyHY5XyyyDE65RD1LqjJklNcjjyRQiPMqK4Eii6HMlMchyNxvMeTgUzcXo/LIyb9qHeiRjibRKmWbRRGjH/sQkLSTobGyxjY2RyUiOQjOxMs7K0euRkvJi1x9mwjjIQocBxNpGA+BmP/AGIXRdDkTdsYxsY9LEyEyErG7F1oh9C6GZGSfhZfjj7FiNlCQocH00z6aJUkNjZjdZEJUS6JzLLGMY9GxsjIx5KIzRGRZZYibMkiy/K9EY+xEiPZFcaSZN2NjG6kmJraZJokx9iYxkhjHohSI5GfWaMfqL7N6+CL5F0ZGTYy/YRj7FEeMhjEiTonIb0fQ0Qd40Tn8CEhIa0aHo4igLG/0ODGmizpnp5OToUaOkZGSGvNIYiHYkUVpkZJj0Y40j08rx0PlkMSFFLs2xolEcSQxRsjCyEEiMVXI5w+RrGyfp4PmJKLi6Z6T+YuWTdImxj1rSxMQ9IdiWrZkkNjeuOTc3FmB02hdm+kOTZchyZvHySW1EJJ8CkWyW9koyLkhZGic7PTP7zJ6hYmZM2TLKzDOTjUhj87E9Ma5HNIeeKI5osnkXwSkMbLLKaypkWlIRZCJ9N1yx4o0ThtHwZl9tkZUyFPsjC+uEf48flksCXTJ4ZfKJqhyPTOpGVucjHFJ0QfLLHq/FCMXZLNZKbYptH1GKVjY2WWY+WNt5aWjIyHma4Q88xOUu3wNmR/af2I5BZ5/IvVP5RP1DuzJnk+2SlemO/g+lSs3OLIRpc+bRQojiNGN8iGXpBljY2NmJ1JEvsyqWm2xxaNzXYpWfGk5cEuyyORo+sb3IZLSDpCnwQ+6Y9bL0rRIQ2NmPvRvWMqHIsYxN3YluQhImhifJfBt3cIyxon2UbSiIx6QSrklL4RgXbGUVrXhY2Mx9jY34Wd+EH9q0TJskR7I9ckXXKMzs2NjgyK45JRLLHp/XTGtsa9mxDQ0Y1yN63qhl8iFkaVEHcUWSZIxxFFNUzaorgyQZB7OaMmVy7G76EyUSijaKLkqRHFK+dLL1ssQ2WRkWUQXOlD0RWj0WmJ/aNkuhIikiyxz5JyvkbWkYjgxrRmDuxoeli0rRDGhITLMffgxMvWhLTDL4GcbRNEU5Pg+lJLo5XFEofI4ylwL09uiPo322LFGH8mSlFLgk7enbIcIssY9L8FpRQjH3qxs3CYitLGyDalej0g6ITHbG18kpRj0S9Q7sfqZM3tvk3XoyMbGtEUUVpeq1oox9iejYxRNotGzcJkTG7VMkhoRZuaHJ/sfPY6RYhCFEUaQ9bE9HohIoZYnpDvSxsSEiitGjaJCYpCTlHcNC0Y0NEtEiMRRKrRjZeti5KEhIaJaLSHfgkLRjKKGiGOU3USHoUl9zJY04UhxKrR0SGSFFkIWKB1ootrgfikJDLEyxlCLMfejQkJCWtaQxym/tRD0MnzIxY44lUR9C6MuK/uj2KSfDJw+UUOLZsPpkcYkkN6YsO7l9H041SMmFMeFroplM2sUBRHE2G1lFFD0xrnVIoWsMM59GP0aX8iEYwVIcr0fQtM2LcrXYm0cPsUY/oeLi6GktaMeG+WJVrOHyhxT7Hjo2m0oaNptNptNo4G0x9iWqYnZjwSn0Y/TRj2JV0X4fGk8dLh8kM2HdU2L6UnSYsKi/ufBGMY9Ik7MkVY0JGOAlXjKH6GiivKiihxIx5K1xYp5HUUYPRqHMhKuvYUqdmfNKX2/AyPYm2Q3bLZLKSk2URiJUvN0OKHAar2YrkSFhlN1Ew+gS5mRgoqlrXk9MySdjMeCUuWY8XNQX/s+yKrtmSO2VCEY48X43rRWlDh+vYj2enwvK+OjDhjjVIftZHVG4lilNcGH0fPCtk8cMX+x2/0jJlb4XCLJrfG/lCIRt+7JqKsc1Lzj2YsaxxUUL283WmCatKXRn9Wox2x+1DzKX8dIJtijRPHTtEY0vdnLdKkSg0KX7JToUxO9Y6fHt5v46fUqaR6n06SqXKfTJYvplp8mLoZ8e7kltjZij8kq+RmTq0RmQlqvdy/wY3SL5PT+oWzbPmL/wDhnwbHXaZscJUyCpe/NOcqRxFcCTkzJUeEMf2yoxyIu9Fo/blymjLFx4KPT5dv2vo9NU19Kfz0eoi4z2v4F17zE6VsfJahEbt3pmVOyMjHMTI6Pv3MnMbJcso9Nlbiv2j1eZZczkjG/t97I6iN2Woq2Tk5PXKriUQlRCZH3nHlx/Y+HTLPT5HGTIqyKpV72aX3JCairY7mzYl2MY1aGtItoxT0+Pc+naUv0erhtnf7GYo0rMUaVv35yuTIK3RwuENWS5ZLs+BiWmJ86L3PStPJ9N/2R6vFcGn2hK3Rihf/AI99ulYjEvkZOVKhLi9J8RY2J6Y3z7yk4SjJfDPVwTkprqRHC1kaIxUVS9/K6gxEI7YkpUVbtkn8IUbM36RIiWY+9V7SGrMX/LgcPlco+fwM74SMUNztkpFXyx8IStk3sX/ZLoaFEox96r3Izcevwcn3To+KiKIxqziCJPc7JdeGPvwXsL8OUtqsVyZVDenEeWZJ2xk+tFpj7I9aMi/YQ/wsktzMMf7D06Mk70Zk60QkY1yLh6MTpi9mn+Bln8IjFydCSSpadGSZ29GZetIiRBck/wBl2rGyTpidrR+UVyNuySp+9KVIbt2Yo0r1nKhu3p8aZehIihGNcjVkHTokiTsxvj2E6ZaXI3fvZZXwQjudayZOTbFB/I4k0lHTIRRFEUY46ZFTtClasnH5Rjf48nSHy7MUaV6Nk23wiMUhsStmd80MlGyOMURIi9Jq0RdcDkQfOi/Fyy+CEdzrRskyrKoZCJldy0hHgUStI9j0yKnZ2R4/GbpWPlmOO1DY2VZQ9Ootknb0j14R71yRtaIj1on+HkfFEMe3ljYzvViRmdQ0St+MexDOyapkSHX4u1J29Hqx6I9S/jTErZRWse/DIrIkevxOvN6IzSuWmJUr8Y6yJdaQ6/DXLH4vRiJOo2TdsSt0JUq8Y6smhC/CZVKvF+CMzqOmGNuyiiiihLwkrFwyPlXuJWx+L8fUS5rTGqil5Lxl/Ij15IaoXtLoftZJWyKt15rwnKlpDr8J8exWmSVRY+zCvu81pemR86R6/Bj2PxfhJ0jJO9MXCLLLLL0QpCemRfOi6/BXQ/YbMk74JPSPCLLLLLLIlUWKQ0miqdMXX4LH5tk5UhjIq2UVo/CD5GhvksjP9kluRjdr8BdnyND0elljZOVsb0wRt2bTabTabDYbSMeSRJDWidEH+CvBjL0yOlpLTDGoa0VpRQkf/8QAMBEAAgIBAwIFBAIBBAMAAAAAAAECEQMQEiEEMRMgIjBBBTJAUWFxQhSBodEkkfD/2gAIAQMBAT8AonEnHkqvJF07OmycEWpIlFGSco9iPVP5MvV7lSJSbZTetlllnJuZuTGvPh7nTRGhoTpD5FEUdJdzNxHTLKkOV8vzdPNmOXA5mT+TLkTdLVljd+XsXovP08bkYFwUNDYuSMbHChjZm+3TPG4vRLVUNHTRIrjTqcyfoWljG/bsry9LjMUBxJIcSERR4JE3plfpEONkum54F06oyYkuxXJZZglXBCVoz5Nkf5HyMft8FaJj1j3OliY0khokhwIxookmxxHAzx4ME965FpmnsjZKdvkXcpji+xBcmLsdTPdPRjdaVpX79iijsd1euNcnSrgi+BzFKxsbLKNptTOojwdMqTEWdVytMcW5JHgRJY0uxVMxy4JvdNsb04QjbYoCxNnhDxDi0V5EhIfcXbXDG2YFSFLSMuTcWbkKSLWnU/aKKSpFDJRtUx9O7MeNRdlkmMUqjZY3RbFFshj/AGRxkcaFE2jhZlx0xwHAcShHYfcWvTRMUaLExuhzFOxyFNikKR1H2LWRZdiNxKRY/tLGrEiERIoQnpRLHbJY+CeOhoo7D7DRHvojpYEI8ElQhjIo2m0UWJHUP0ljkSlYpCY5Epl2Il9o++kYkFSELRCXzrROBODRVD4YhkVTH3IK2dNFkXwSdlFGwiqLFGxQJRo6jiI8lG+xs3G+je2dxIQ1cWWR7mOFjWi0QnohIaMmOyWNkolFCQ+5hjbMEeBRY8bHEhCzw6HEjGyOMUSZ1XYZFDJPnSKEhIRjVpjXJjgRWq0QtEtGNEoHhpmTDXY2jQ+500DDEjElFDiQgSjSGjHFCiS4ROZ1DuI2KRKY+SKsSEtEY+5NVkohD5HwNlieiEJCY5niIU0WmUNWZ4qI3ZFXI6WBjjWkpEOSKMi4HwyEqFkJy4MkjL9oxvnWCFqu5CFdzqYbclkeETyMcpPsbpWRmKQqFwOVEp/olOyTb7ChP4E8iIZ5LhkZKS4OpXpEYYts6ZURoa4JojKjHMbslA2kSXYmuTLH0jleqVkUIWkFyZOni8CyR7nUq0hujbbFBGxGxHhi4E7ZNG2zahKKFRtTHjTIxo6n7DD0/iLkx4oY1SRGNPggxPgyJMcXZFsi9KFEnEkuTN9pQsTY8bRGIkJFG1keGYMyl0zizJFtEiKROb7Ilkaf8kc87MeRyGY3zQ42ifBOe3vyz/Uy/RDqW+6IZ4vsJ2UdQrgYVtRHlijyRjRFjpm1DgJ0KQpI3EpWONnURqCFioSoas2laY42xYzwbFFwjRDHHwXJjENCxRl3F0sPklGMFx3ERj6hL0koHgQY+ij8Mh0ySohhivgqtJKyKIEOw5UbxTtkZUieQ38kJWWPIeIRlZ1DTxr+xoa1b0wMg0cGStpjnvwuGnYTWjbG+REVyQ7FDimbR0hNtiRQ1yRREi+CbHMhI3WTZudmIa4JdxQsUGjqF6EUNFDNukJUyOU8QUtxKW3sUMihIa4K5LpEHZHtpejRGLEhnyR/QkUSXA0J0JktMTE7Q48mKFnhJo6zHUUKI4jQ0UbbNmmNNshAyR5EhxsjGhIkuBrngcb4ZjibqFJMYmISoZI/yIt3ZCNm0nEcTaJMkuCjGiMHQ4swuhS4Osl6F/ZEZIaKIxIxHjdmKAuBwTlZLiTELTJIUpRdolkeTuRZKO7hkIKPbTsRkJjY2R7kMdsx4xYzLAcRY7FhJ4xxowpWRqicSKpm/g6qfp/3Izo3jdlEY2KAoklRjEPuZVUxCfI5Im7KEiMOCMX2KrRsjNG4vTDDcyEaIUJWTgqJwpkCKTJwMqojNpmPMSy2bi+Dqr2iERQkRIxKokrZBUWNmb4YmNvdwNMa4o3xum6/sUIv/IjB/scYxVtk88US6ldkhzlLsiMZWRXGvR4fRb+R40hypkMxutGQXDIZKN1mdE0QlQpkZEWdSvStEQGiJFjei4GyTMk1VCdiLJdzffDRBwv7SKx1wjw4yXI8EF8DhEo26447pUYWkqJPgyyojkdkcro3WONiiJ0ZHZOFmwUaFaIzM8rgLkiiCHEbo8SiORMTLHIyTJSITpiZYyiLFOjxH8FtlatlmHjkxSN3BkhZDFyODQoshC0OFE0MWOxYOCWKiUa0zP0ESKshEkuDISkQnyQycEsg8lkpWNFEJ/AmMQhMsQxjY2Tn+jBK4mKyEbHjI4kSxI8MfpHNslbKIMjTMlIn3Npmj6DaR4MXJk4RNMkiKIk5DkJkpKPLH1Fuoox5Ns7YpfssURppiQkIkyUhyJTGzpc0YvbJnTwT5QltNyEyxyJzO+k5JHiUQzEp2XbMcLOqgljX9lke5iZkJEkIRJEml3JdQl2Jzc+5EfcwZq9MuxtfwRnfDO4mkbzxCWQchyvTJlrhG93Z0n1HLg4i+DD9ajPjIqIZ4z5iyM1R4iHkRKYpjyGSZKTIzYpsgjGdW1sX9iIRMaoZkRJCRLLCC5Zk6u+IkpOTEv3omXp0+dwe2XYdM5XZjcv2eJ8WbxyLLJ5K4XkjP4Zjzzxu4s6b6pfpyHjWrQ8hvN45kmMREhKhZEkdTluJDHwKNCdG4lTM2SGPuzJ1MpfbwPnuV5PnTDKG71pv+u4vo/WSjvhH/wBsn0/V4vui0eJOb2QXJOc5P1MTIyZY2Tn5oy/ZZh6qeL+jFnhlVx89ikOZmlcSK4HplzRhzJmXrW+IDk27fsKNo+j/AE/HCCzyVyf/AAI6hWiUYxdnVvG8r2MjASosbG786NzRDK4u0dP1qlxM7lFebL9pu/RPLGCuRm+o36cZKbk7fsoSo+jdRKS8J/A3SOu+qYMXpT3P+DqOrnl5m6X6KlLnsRdrSycr49iy9em614/TPlEZxkri/Pm+0y9THDG2dR1Msrt9iKpc+1iSd6fT+th02XdPsdf9ay9RwntiQlKf2ql+zHiS5ei9L0lKl7qVujontnT7eStc32mXI5ytkv17eHuxmWLq0dN0OXPK4R3P/hEfpzxLdm+PglK2SdDlZGVobt+7FUrIz5On6n/GQ5oUiLvXN9un+Xt4vu06H6f4mGWWa+HR0nV5MM9+J0/lGPr31f3d/wBGbFLHNprgye/FWybF/AjDld7WJkHrm+3Rd37eL70dPh8XIl8GCMVi2/B1fTvHmklw0zBmlFqceGjqc0Oo6dZIknbHwL3YvarOW+S0iPIuDHzFMihaZvt0h29uLpo+luMoN/J09SVH1rofGl4uNepf8mZuL3x/3Oml/wCPOuzofcXPPvVyLgScmLjTpJXFo3UKZdmb7dIdvc+nzrK4fs6dPHGx5T6v06x9Q3XEuTDDwunUH88/9E16q96KtiVHfhEUktcM9sh5COQhNMy/bpH5XuY8myUci+CFTipR7MUOT65hg8EZPumZJ27G7d+9jXFjTbo4ijdYhCfJYmRmSyXHTtL3N3eP7PoPU+N02x948CR9c6jflWNdkTlbr34qook6R3E6F2EfJQxMlL06S7X7ma1Hcvg+hdV4PVJfEuP+v/v5M2RY8bm/g6nM5zcn3fvpW9JvSKsf60hzI2klpLtqu3t1uTi/kwTcV/MTrvqSy9FBp8y7/wC3cbt378FclpJ2yKsuhfsbMXexMkUSXGvz7k/RkUvhibqvwMS5snKuBRLrsLkboitzI9xyN1iZJ8av9+5KKff8GHET+WNiEz7mJUiPcaKEifbWr/MirdDpI7i07kY1pHuJGw2mSPA9Wqf5cI7UZJfAtLshHRGNWyMSijN2O61kuPav8DHH5ZKVKzu70uyEfJ06uQkUNGXsQ/R2YhcofHsS7aJ2veirek5W60uyMRKvJ03diQlwSRm7CdMkrViEia59mvfxok6V6pEVRuEyLt6dO6tikKSonMzTvSDtUONMi64Jrj8eKt6ZJW60SIqhsQ3SMfbTCuBJiiyWNsy4ONIumNXyJE1x+Pjj8knS1itUSZBUtOnh6LFFa5vt1g7Wj/GSti4JytiEjsWLTu6EtMaqKXkyv06wdPRj7/iwXNkp3whCO2i0ZjVy0gt0khIoooyr06LSDtDJd/xbdV7DMK+dOkheS/0JFFFGZenyRYyXf8SvZZjVLTo4VDd+/Lm+3VC0l3/DfssSti7EY7nSIpRSSLLLLMz9Pki9H3/D7+Va2Mxq3p00edxuNxuN5vMsvT5E6Hyh/m4lxpijtivLZl7eWPYffzr8R6RVIiraXlemXt5Ixt6S7/hL2L0hG3pgXrstF+XJ28kFwMff8Fi816xVsiq0hKjxBZDxDxDxDxDJPgaHpB6P8H59lIhGhaJcFFFHJyWycnRdlDRdF2h/gpewiMdFpZZZfkmuBMRQ4idE1T/AflWlFCRFC0bossss3G43EpcCEy9GiX4L8i8kFei0k+dLLLLLLJPg/8QANxAAAgECBAQFAwMDBAIDAAAAAAECAxEEEBIgITAxQBMiMkFRBTNhI1BxFEKBJDRSkRVDgsHh/9oACAEBAAE/AtI4kokokly0JkGJl8rCiKIjUTmVJ/kkzVstzLieTH2CELkvky9WTJEiSNA4cpMiyDEKJoNJpGitWUR1WxsbztnbnKXEuPnoW6xbmPrnIkyhhXU4iwEbdCp9OVuBXwzp+3JREpkURRYsWMQ4xjxZN3kN52Og87863YoXZvrnIitVRIw9G0UaB0zGYZSgyrHTPkIp9SkiKEs61eNJFavKrL8ZJXLZXOvIt3SELkvlPqWGiaMLH/UR/kprhnXXkMarV5fzttmimimQFlJmMq658Ml1L3Hsvzb9ohb1m9lt0vUWGiSKHlrxf5KUrxycrGIq2iYqWqtJ/nOMdTKOBlLqP6dwKuDlD2GrMiUyBARKWkxWK9onXix8Totj7G26/DmIW9c2XqyY0W4mHrcDxSpXMRVckVIcS2X07D63cp0bI8MqUE0Y7D6JXIlMgRYmV6kYR/JLzO7LXG7H5Z1L9zbJZPkIXaS9WTLGkjwNTGTiSpk6T+DTxPpdP9FMtn9Tp/ptnuQIMTNVkVXrkPqdeA0iTLnTkX5ly5cucOYhC51y49kvUSg452FkzRqZDCoeEi10K/09dUYBaKajs+pz/RZ7kSImVJ8LDYxEhiHyLc585CF2kvUYmHl2LPDwvxFGxYlBNH2pkanA1k6tkY+trlpEiOSZPjlbJ5vNIfdPchC7SXqMT9t7blzDehbMZwiQrtDxJUrNk+MiwskS6lhkvjPqy1tli2yxYsW7J7kLkW2WNJpLbpdTE1eD2tiZhanDNysYyrfhkyQ0W2X8wxvZeyL59SxpNB4ZoNJoNA4luVbY+QhCytusaTQaBQNBpHE0GktnLqSk5CHm8qVTQyFdWHWRWxRKeqVy42Mey9kLrcfQeXQuN3yUWxQFSPDsKl8ipGgcTQKBoHAcBotlYsW2LY+QhCFtsKIomk0mk0ljSOJYaGh5S67nlc12JVX8jkXLlxsvsn0IviMa4F30XuSduHucTSRhf2IU2+HsRopCgeHxNJpJIUDSaSw0SQ0WLFixYtufXkoQhbUhISLFtrGPJjJddrY2ai5cY8rlxsvkhFToI/tJEvL06kY+7NP/AGKF2QpEIIUSxYsWLGk0lsmiURosaRrKwxra+ShCzWcRC3XGMeTyl6tlxslI1Fy+243mhE0JccrDjxHGyIx//SEeBGPEjEsWysWLZPKw0SiOJpNI4klt996HsQhCFsQhZMbLmouNjY2Xzl6srlxsciTLiZcuXLlxvYhE+gll7CtdjfG5CPAUSCIrlsY0WGspIsIfse5L1b0PrsQs1mhCLlxsbLly43k9k/UajUXGxsZcTLly5cuX2IRPoLJuxqsh9SJHoQQuQ9jHkx5PqdLj6iHvRLrmhCEi2S2Jly+THlffP1Go1GrN5XNRrNZqLiFmhD6ZIfT8scfYURLykFdiFyHsebyY0SzfIfXNCEi2+5cuXG+VP1Fy4srEhl9yFmhFuBbiWJRWlFuJHiKNiERLnvNjGhosWGt3QfXNEUJFt9y5cvuvtn6s0WymS2oQhZoWXvl7EYXkU6Vnc0i7JjzaLGk0DgW2MeSIkRbrl9ls3lfJCRY0k4+d5piY2SY9qELYhZPqJ8CPmKdJ+5bge/LfJeyxYsOFyUDSdDqMeSERFylseyKEixYqet53FIciTHsSEslsQsn1yw0PJk3cS572MedixbJFiUbEupfJ5IQhbLDW5ZvNEBZMqfcZcuXNQ5DeaEIW5CESVmP1Ip8IoeSyuXyuMuXLjzuXLly/ElIc0eJE1ov+TUXT2+xUdnmxCFmnse1bHmiAsmVPuPNl9qEIW5EUaScfMaeKI9Fk2l1HVt0PFHXP6l2P6gWIv7njiqHiGovm2akN8Rzsxz8xKZJjkXZqfyKbFUI1vkUk9lb1bEIWxcm4smPKJEWTZUfneTHuQhb4opU0okolSIvUhFWemP5JSqf5E5M42HGTNNlxOr6liLsKXuX4kZilwLjJDY5XX8EpcRyNQ3lobPCZ4TNBYRCpfrnX9WTyUJfAhbELY9iyuPNERFxsqPzsvyELeiJ47ppfBCcakboqR4H/ALVlOFzwripL4NKNKJQXwSoodK3Q0FrCRbJDKnQv7bLCgKAoljSaBwNBpsLKt1ycW5WRQw6jxfUsvgrUV1QlsQhc1CEXGyb875CEhb0RKq/SMIy5b/UoRbO45Dmvkc4/I5xLrJI0igaRomNbLmtHifyeKhVEai+ViwllW6kFdkICJTSNepFixbJci2dsrZouXGyfqzsWLZISEi3IiPjTMN9waJr9eIiwyTLzm/L0+Twl/dJslLDw62KmLoLpFMliabfoFUg+nAVSUfyU56iIomkkiZJDycrvgKK/uPGpxP6qJ40GWhI0tdGKb9xPYyt1Ka8pHgORJlMsWLFtly5fZYsWztseUvUWFEjSPAHhx4dipM02LbrFskUuPApwtUGyf3Isjk0VIv2K1WtHpFjqV5/gp4NT4yncrw8OpKJxNJG6jcw8lN/kghCRJFSJIY1fgSajwRJS0XzSGnD3FVaFUbFf4IxebKq8xFcCUhEilse9ZWLZWLZX2MZL1CpkKJGmKmeGOmeEOmOBbYixYsWIuzIFWVhS86I5tDiidBS9jRKl6SvS8fj0Z/Rz/B/Ry95Cwqt1KOHjB3QlwyRIqomNDR/SyHF6NLQ6Uk+h4cv+JCm1xY6bYqPyRpxXsRRYtkyauy9jqJElxI+VCz0mk0lhosKIoGk0ltj3Ml6hUyNMUDSaTSOI4k4jWaIosWNJpLFF3iVyCvIjseTJDuWEmynTsWzZUJlixxLmrLhnGAo7GTJcSLIjXEYhCRpLGkaLCiKJYsWGhjLjYy+yxNeYURISLFiw0MkTzRHO2TKPUrRuiiiOxoaGhxNB4ZGBbYyoSWek0mg0MVNkaBGikaBrYyfTKxBDyRERY0lho0iQkWLDQxj3osTXnYkLayRIlmhC20+Ehq8S2lkem2w0WLCQltZIkMWWk0mgUBLJj2MZYS4lrIlkkIiLN5oWTJDJZWLFs0In63vZImhrYs7l8l1F0LXFyltZIZIQhZrYx5seUIjH1LZIQmXyeaEXyZIkixYaGs0In63yGiURxHEtncuXL5WIek9hci5cTzQyRLJliLFsuXGxsebJEYF9ItlyMhSE8mMvks2MZbJjHmmTfm5FhocRwHEtuWVPL323Gy5cuIsMTsNkmSex8JC2XLje1i65OPHcmJiYnkxlxPK4x7GMb2Sfm5Niw0OI4jWaEs6fTL3zuN5tlxCHUUerPEjLoy42TkORcUjWvkkyOdy5cuXLl84ltlxsuIQtyLlxsbLl8mPbLry2NDRJDWSQkWyi7DmR23GxvKAkVqPiRP6Xj1sym5RVpu5OViUiUrFSVSXTgiNOT6kVoI+Z3EXL7L7k+JcbLlxsvkhCyuXGy4mXLlxvYxj2S68xjJIayQtscrly4xsuIgLKUESgSjckiTzUCKybNRcuX3uVmeIiU7ly5fNCy1Goci+Vy+VjSaS2bLFi2UuvOY1khbLC67ZDZe5BEcrlxkiXUcbjjki5cuNikay++p6hMvtW65cuXEJCiaRxGixYsWzaJerO3LY8kLkPKQzoQYnsZIsaSUTTsbGzUahMvufXmvK5cgRFk0NbLDWcvVzmPJC5DLEok3YbIzIMWXAuixpOhKSHJF0XRcZJmoRHdL07LFi2azsWLDWcGRFmx7GPKfq5zzS3MWaJE0TRoqewpYmn7DxuJp+qmhfU3LrwNVQ8WVxVX8jqtE6zY5P5L3JvSh1OHDqap/LPO/dnhM0EYkVuqP22JFiw1sQixYaGskQYs3kxl82S9XPsWLcuQzRdkImhDo/glgaU+OkVNqNvgdF69RKD+CUahKMzw5sjTlEdNvqeEKgKCRY0iW98XmhZseaFmxotlAUi5cuMbG9jJerc+xsaTpmxoURZ2LDSHE0kkjgNGkty5vYiObHsTEy+THkhMTLlxsbL52Gifq3MfZSjtQs7lzUOY5jmXLl+Y0aS2SFmxls7ikXL5rK4pGo1Fx5ISLDiTXne1jHks7FubUjbjsW5sbyedi3JXE0mkcRxLFtj33L7rmo1F8kJCyZU9b3N5rsXxROOl8hjQ4mgcDQaC2bzb2UKXC7JR4lhoaLbL7nlfmRELKRU9b3N5oWdh82UbofDYs7FjSWLFhoe1vZQpandiJrJjHnfbcvsW6xbYhMuXJMm/O9rHkhCFm+XcUk2Rh5SrC0i2SFyGMbHm2XLlylS1u/sRVkIfQYxsuX5aFssWNJYtuuORP1bWPJCFvW9sxGJ08EYNynO7IekrU9URoayTLlxMuNlzUOQ2NlxsbG86VG/FkVbJE5aUeJcbG+ahZ2NJpNJpNI0W2PKXq2MYxCyXNcjE4jQvyOTk7swcbQRT6ZV6Xusmi+Vy5cchzNQ5DkajUOQ3kouRTo24sWdXERpIq4yVT+CnW+RMsW5VhISEixYsWEixYaGi2TyeUvVtY8kLl3HIq11DqyeMv0JTcndkeLKEbQRSysV6NuKLjL2NRqHMcxyNRcvs0tkaPyRgo52MRiFSj+Sc3OV3nTq26kZJ5OJpNJpNJoNBoNBoNAoiiWLFhItm0MeTGPKXq2yY8kIXIuXGyvilHoTm5vjnh1erEhHgUlm1cxGFv5o9TXZ6ZdS+TGaTSaSxbLTcVMjASytlXrqlAqVHUld7VJopV/Zl80aTSaTSaTSaTSWLFixYtlYsNDQ0PKxYkvNtY8kJiZfO5cdRIdZHjR+SWKiiri3LoN32YFasTEUeAuBcusmj6hhL+eHUhWadpCmpZ2PMaKjHSqfJ4bNBpLFi2VyrWUEVarqyvyKNX2ZfOMhcSxYsWLFixYtvaLDiOI4Gg0k152PO+3UKQmXHNIqYuMSeMk+g6037mqXyXe/Ay04mAumTK2Kp0urP/JfFyj9R8SVkSxUJeV9T6hT8OWtLgynVnchNshSnP2I4X5YqUI+w0SiOJpLFi2TZOdkVquuX45VGrfg9ilYjNPsLFjSaTSOBUj+ox8lGqxPEqJUxEp8ylLTUi/yUZaqayx2O8KNomDh4n6tV3MRjKcfJTimyjJ06mv5J19TT08StiqdWg4TgTeH/p9MeDKLtQvFq6MP9R42nEumroZYaGixYtk2SZia1/KuWuBCvbqRqRlshU+S9+wsWLDiVV+o+RYlZEqyRKvJ9C/NRgpXw8TFVvDgYmLnUROv5VRh/kjC2ch5/TcRqj4Unx9smMexsZia2laV153QjWkiOJ+RVosUkxSsRnfs6v3XvckipiV7Eqjl2ETAf7dGMqaqlh8UQXnfzmxjzp13SqqUeqIy104zXuNj2PKvU8KFyTcpXfZKTXuRxEl1KddMhU7Kt915WHHOrX08CVWUuyiYXy4QqzvVeVWOmWoi75NjGSnYp0Klb+CFClQV3xZg63iaqduHsPdLgrmIq+LU/HbQryiyjiFITv2FX7r2Kk5GK04eiN3d+zj1L6MGhq4uBZSiRVnbJkppEaVWv6VwIYGNPjN3ZKtby00KH91T/opy0yTXsS8yUl77bGOrW/Tj3CbT4FLFW4SI1FJc+r91iyp0rs0qCPqVbxK+n2XaR6k6mqnFFjSWJeWq0NqxGnVru0FwKeAhDjU4sqYiFJWifqVuvCJrjHhBf5FxFHgYd+XQxrZWqKlTcicnOTk/fuqVSUZdSm9Ub86r91iKVH5ErGInopSZKWqTl89rS8yQqZ4YqFzG0pU60bL1GGwF/NW/6J1KdFWiTdWt+EeFCkrzZKv4nlh6SNNkIWLC8rueuOpbMdiPEqaF6V3WFw3iu79KJ4KEvwUqbpxtzqv3GYelfi8/q1XTQ0/PbYb7aE8oyaK2myqP2FOdb08EOlCmrzZiPqEY3jTV2SlOtK8mUKJCmaBwNJSel29hqzyx+J8KnpXqfdUoeJNRXuUaapwSQ0WHHm1fuMhHSsmfVamquo/HbYX7aIiyqJTpOLJ4+NFaIR8xVnWrvzt/weHb2KSWvzFGHASyjA0jiLirFSWiLb9ivVdes5Puvp9HhrfuRLDWUolixbk1fuPOTtFmJlrxE5fntsH6COTY6/6y+DE4RVl4kPUSbpy0yRKdy/EweIjNafdZLrnYsfVcT/6o9ffuqMPEqKJShpikJHUsaUWQ4Z2Hvq/ceeKnow8n+B9tgvcQ2V6tvKupBXkilUdLyy6GKw8MRD8/JVhKjPTIQrwqxmilLVBMiLPFV1h6Ln/0Tk6lRyl1fdfTqP8AeRWSVhvNj2PdV+48mfU52w9vnt8I/OxMq1NELkZa53YuDuU9OIoXHOVGdn0MTQjiaf59jTKlPTIZgZXoogr5vgrn1DF/1FXSvSu6irtIw1PRTSIxOg3lYky+17qn3Hkz6rLjGPb4Z/qiZiKviTsuiIDdomExLw74+hlZRrQuv8EKrpT0yMRhlXp3j6vY4x8rPpz/AEyHTP6pi/Dh4UPU+7wNLXWv8FOnZccm8kiTG77nuqfcef1OV8Rb4zfaUH+rExFbTHSurEItq4FW2mxh8W6UtEvSVafixvHqYN/2SPqeG0/qx/yfTn1IenLE11h6LmyrVlWquT9+7+mUNFFSfV8cm8oj4InK4s3yan3Hnj3fFSzfaRlpaZrcqrbyRHoTJU7n02px8KX+CtT0PWjEyVTByv8AB9PXkuU/Tl9TxXjVtEX5I93Rh4laMfllJaYDeaWlFSYtj2PbU+48mY3/AHU+39irHTO/yIQp2NSLoc9E1JEJrEUL/JiajhB0/kwkdNNFJn1PF+BR0R9Uu8+mU9Vdy+C9kXyitKKlQ68loeyp9x549Wxcu4rR1YdS+CHQitkldH0yrwdN/wAorLx8fw6IhGyPEVKLnLojEVpYis5t/wAd59Nhow+r5HK4hK3EnM67XkixYsNDRYZU9bz+qxtib/K7dFD9ShpIrTU0lixYsJHiOhVujCU7LU+rEj6liby8GL4e/eRV3b5KfkpqPwRVxLSrsnO51Ei2x5LZYaGiSKn3Hn9XhwjPuMJL9RxMVS01lJe4uOVs6dPxsQn7IpxsjF1/AoOXv7Dbk2317zCR1V4/jiQ4kbRVyU9QkKJ0G9j32Ghoqr9R542n4mHkjo+3hLRWTKtLxsM2vbiU/jZN2RhqemJwjG7MXiP6itf+1dO9wMLuTF5UdRRFG2TyeTy997GVfuvOXFGKh4eIkuWuY+qPp710CtDwcRKJbNeeskUlwPqOK4eDD/5d9gY6aKfyLiJEdrESyiPeyr915s+q07TUxdsva59PeiWln1Ol5Y1P8EOMcpOyMJG7cvkr11h6N/f2G3JuT9+9RRVopEcl02SeXsPKJPK4tjK33XmzH0vEoP8AHcU+kZr3RJePhmvlEOEmsqr9vkoWp0rvoivWderd9PbvqKvVivyUxC2NjEPNFRly4ttb7r2TV0V4eHWlHt8F+phre6MNLrFmPp+HidXtLiX4C89f+DFV9S8OPT37Ju75uDjet/BDKK45sbzeSPYfHNba33XsZ9Rhpr3+eS1brzUfTJ2k4kv0q/4MbT8XDXXtxNdosU9MG/d/sGAj1ZDKC4Zt5vOKKsvZcmt917GfUoXpavjkt3487D1fCxMJexXjqpqRQlqp6WY2m6WIcPbr+w4KNqSIkI3eVxsttSJPRE6vk1fuvYzFQ10ZL8dvLoYGr4+DX44MjLwajv0MbX8ev5ei4X/YFxZQjaKIoXlQ2XuW2pHoVyctT5VX7j2MlxRXhorzX57Z+k+k4jw6vht8JH1WslPRHr7/ALDh46q0SjHgRWlDkdS21CWlXZUnfl1fuPYxn1KFqqn89vBuE9S6olKVR3l1EPv/AKdS1NyIWQ5XFEtuUdKuyc9j5FX7j2sx1PxKD+V2/v8AsKV3Yw1PwqKj7iIw4b1G3Fk5Dd9j5FX7jF02MmrorQ8OrJdqy37DgqOqet/4IxIR474xtxZORJ7XuuXKv3GQ+NjJGPp8VPtemV+/o0/EkUKemIiCstyjbiyUiUs/bORcvsbLlR/qM6T2MZioaqTH153C3LfdxV3YwtGyIogrvbYUbcSTJMfHN5y65XLly43lU9bKnUXTNjJ8UV4aKrX7phaN+LKcbCIRssnkkKNiTJMbvsedR+YuXyuXLlyo/Oyp0IPgPNkzGw6S7LoRozqcV0+Wf0svlEouD83fUaeuRRp2QkU4++ywlYbJMk+RU9Wdy5cuXJvzskLhLJ5MkV46oNdlh6fi1fN6Y8WVaqgv/o8f3law7TjZj8smhd3FXdjDUrIiiKuzos7CVhsbJPa+myXqzeTLlyb8wyfUi7oeTJEyvHTVfY4T7U173KtHXfVwVi8bxv6USVrFV/rSFa3Uvx7rDUvcpxEU1wzsJWGxsk90tkvVm8mMuSfmymiLtlJDGTMXH37HD1fDn+GNwqQs+hppKKjoVkVqtlqZ1Z/gXXuacdUihDgRQhLhmkNjZJj2pE+ux9c3kxjZJ8cpIfBkXlJDZIrx1QfYXyjUnD8ksU7ekblN8SMbd3h4FKIinH32N5NjZYtsXQl6tlsmMY2NjY+udRCeTJokTKitN9hbNd3BXZh6ZFCIqyzbybJMsW2vhHY+mTGSzaHEa45zR0YmMZNEzELzX/bsNT1MpQshFKPvm3kyT3oqdNj6Fiw0OJoNBoPDJw82bKiyb4DZJkzE/tvVmFpaYiEuJFWW1vkRRUe6xY0mk0mk0FSP6j2TXDL2GMkYpcO7v2WEpapamQjZCKUffa2PK21C6E+u2xYsWLFjSaSqv1GLNlRWeTGSK/p/bOrMNT0wQiKuyMbLY2PK29+kl12Lk1fuvbUXDOSGidO5OOmTX7Xhoa6pBcCKKVPSrvYx8lFTptXJrfde2RNWeTGTdkTlqm8rZX/Z8DDhcgilS08X1L7HlbkIqvnVvuvN51VwzkVPSSVp52yW5X7+EdUkjDUbJIpUdCu+pcvm+ZUexcqt917pE1aWUiZV67krxcuHD9k+nUHUlqsUaKpL8l9j5aHwiS3X5FX7r2POrHgXJEysJ7V2F+zw2GqYqrogv5fwYXCwwtJRj193tfMRU6EuvOq/cex5y6E1aQyZiGQ/Z8NhZ4qrogv5fwYbDU8LS0QX8v57JFR8efV+49ryZWWU+CKvFkOu57n3VGjKvVVOHVmEwsMLRUI9fd9pN7Hy6v3HtecyXBk+JWjaJHryV3v0vB+BS1yXnfaS4RJbG+JflVfuPcxjKy98sXLjYX7L9Mw3jVtTXliJWXaVCXXObsjUXLly5cuXLly5Uf6j3MllUV4knwKzvUF+yJXdkYDD+DQS7RE35h51p8bGo1Go1Go1Go1Go1GoqPzveyRIrcLk/URz9v2H6bQ8XEX9okVZdp7EnnOWmNyUrsuXLly5cuajUajUTfnfIkiRiV7lT1EeXZ+x4UvfgOLXJvzvpVDw6Cfu+Pay9JLPFS/t5s/VyGioVuMGVPWLl02oL8vqx8BMmrcULa+fQp+LXjD8lOOiCXa1WSzru9V82XqHyKyJ9Cr9xi5dyzj/AHcPghC+p3Jryi7T6PS1VnP47ao/NnJ2ix8XzZerk4mXAkYhfrC5aIQjUkry/wAFOhSpXmn1XQxMopaULJdl9Jp6MLf/AJdq3ZDzru1LnS9RffKVkVp3YzE/dFzIOP8AdwJV/ZPgNuT4kVbs4rVJL5KMNFKMfhdrN8B54p9Fzp+rfcrVBu7yxP3OdpLdpgKfiYyC/wAi7Rsmx5153qsuXL8ufqL7L5TlaJUnqeTMR9wXJW2/afRqd605/CF2bGxvOb0wbHK7Lly5cuXLly5cuXLkvVlcvsr+gll7Ff7rFyr9x9JpaMJq/wCXHtJMuPPGT00f5Lly5cuXLly5cuXLlyT82Vs7lyXFFWNj3H0Kv3GL9hhHXUjFe7KUNFOMV7Ls2xvJ54+V5qPxzblx9eRONya0SHLgT+4/2L6XS8TGJ+0ePZMbJPdiJaq0nz315EkVYakSvF2Knr/YvpFDRQdR9Z5X7BsbzedSWmnJj4vnvryHYkjEUtS/JU9Yv2CEdc1Fe5TiqdKMF7IuJifOvlJ5vrnjp2pafnsJdR5PO+bROJjqeirf5F+wfTo6sdT/ABxGLNPmsb342pqr2+C5fnPrm97ifUKV6V/gj+wfSv8Aer+MocWW5d9jHm85y0QcvglLVJv533Lly5cuXLlx9R5PN7cTDVSaFwbXI9+4+ny042mPi7CVo27B7Hn9QqaaGn/l2L5VyXGJWWmvL+eR79xSloqxl8Mp8fN2DJb8fPVXt/x7L//EACkQAAICAgICAgEFAQEBAQAAAAABEBEhMSBBUWEwcbFAgZGh8OHxwdH/2gAIAQEAAT8hXAXQNfCh5vFDLG7joHqGerFZoZfIw87MR7FLwXeyvBTP3LhV5MDL8lILV3sZXSx+lBMscplwcIXCzYKVS0v4GLoar4E+Fi2XiCOhSXKvP2OdvJ2rPtzVeyiWi/EWNbZfg62XwstFWUZLaK7NWUu0hr/QEFwqSoY4XGx8xMbHLHRQto38IunYap/Aw+RLnVPYWlFs0Uql+7NpeB0IOg1wvcGZiy+SZsosMpxRXxoUQXBFFFDhlSkUONwmNj4PdDFrVpCShDRiAvF7+EljAoqhIaSWR5fY5tv6FjfRCwwYsx0O4OPsuKhU4KQ0i0XF8q+JBRBcEJFD4qKEMoaFzFFwFl4omhhSa4Eri1CmYxkTEJW6x5EtTJpeI9djsyNizZ+BsYvhUXwsuF8lnSKr5FFELgmND4EhCihxQmQuHyFIhAS3JX2pOoQhTSjoMzeg+piCTsJS2N3GfbEemisX9FeR5PSPAbGLg38FrwVxUW4k8iQ0PmplyaXCQlwcI3CWBYsbmKmxpWxCWxwQ9uxsoydYQlGCtDngx5YYmRuCGBv6Fm+QyZKGf4KC2H0Rr7lKNx0OXg+yooqfpFFM0NXCviFMpqUXDhCEhoZcWbBCDGxfQw7LstRf0LC6CFU2xQatCPUKobTTzR7cukMlShW1D9oWD6FVtn2N3FxYtD8IobPfwLwGEKUYZezs7EYGP4UuSixuUxB8BI3DnIyhBChBPQULaNQj+GmWBtChsVT5Ygo9Q1UMo7GfRhixqQzFrIxtlYLKGxHqGvj+irEKwjsRRTQmdD+FL4LG4sTLLlCNgtMx7hDFjcIhNFDWBr6RT2GgpmTFHhQILEDNvSGtsVnbY1l0ZMoZ4I9Iao7BiiqEhtcq4sSweh6PA0IocLmQWCi+V8FxQjYf1R7LEy5kXAyGITAK3kW5iKye2rJ7mw3QdLC1+SsWO6kVw7ML7hlnkwEslFXwDk+DOjuOyyqhv4CFFEhRQkNFQaKhBQONFTtENV7hoRcihqhO1CkLHuJjDGaC3CKYQ6BuOqhdy4SHqOn2IJjEweIaxsUUVCxCO40EJ4zGLjseuRYpCFFSlO5FSrDoM1G0eW+JuWP9A9sJLYhJpMe9hQHgzsQwb230YZbNDF0h+S9mLfkexYpwNeEMrR6MlWUENxsdUOsDlVAxUGNCpbBUdm89fEtDUK0gp6CmXOEGbRiZZY2OWIptGeSGvbEFMMWLYkYlgS1kc7spsHae0Ldj32KUPOCeheIeKPqUrBQO7g8Y8RlGWcGMqByjDEoOLFofLQWEUVytKEhIoQUUaFEEzHFlyrCjexHYscHYvgWH2zYzVLvozV/wNuR9C6bDfJ7O5iGlDXqDsMZuDDLUeQym47Q1TglO4mjsTpzcrQ+YTE+BJkMZYnBhhy57ixjfIghcNjY+QbkVWsxVFsPt6KVW+3BYUry8+gmjRcKFgTCoUVkaEGuFaYPCCp2Psq4q8DDLGdFQptK5IULjm+Eqh5KFzLGHwMLOQgww4Ddi4pZ+2RLf0PSt+TedCrMv/Sjrb2Yl4G7KEUikUUVNDWYQSBxGsGwewuWVX7BaMwHlS4rilKhQXAcQcgYQURuCU7YMOcObFJmIOBllCRUqC47f85KjVDA14f5lVSu/LFWW2YBCoY4caFwxBBoQUaOzqxq38Ismlx7U7cBBRIEEIIQnAom+Mvk2cHE3YzUbzwDjdzIQSKkWCUIr5BjpFaMxhV5N4ekFxcq4GMQaEMQjorFlUyreBqFFFCmQgsSFFChQguDHyUM2zsbhgh8wsssQkKIJcB2DrVGaGvJs1ZSe/pCNq8j6LsfQiihGBjhjGMYxyY0JgXEq2kUJCRRXBIWSQamyxuCiQubLGEJFDNpYsiiDVDGxZcIQQUTi9GNhZtdDwXXdibGX5FX7EwJCljhjGOWMfAaGp21jsOQ6RtlVDeSCCCQ0VwMWJiyIVK4XwlxhsT4gTyhIQQQXFUGRXkVvgvXgNEErtChcGMcG4YxwxoQasooY2EhUwNvQ2uqEq5GrX0b0biFFkTNjQ0PglLPwKRYSK5mCNoQlIJCC4iNqGs4ZRkaHNS0IEU4UNlyxjLGMWVY1iDRUHBVD2NGKyQjdh1wPZuIUSLCYuBqUKTgxmwgokILAY2FBs4EEEKELgQQcNmkUTQhaW5LKPTGg84MWMYZdxWdDquRKW4bC3sr0FmLRZRVmixpOhclxtwSE4ExCEGhoYnBQ1FjNxIrgjGhfEogkIXAxiZbQ53sWcYKGbFQvAP232UaTfQ+oYrJaCb9iwrdCibGykZY5pCpr8H8hlPCeBnlCHZQ7WxLxgzUsoqEyQkaHvkExhCGNDQ4TEGNqRyuXJVjDcUIKIKELhrTq2XrRSzU9miLSmLWrbsS09d+WOzumneFRX2tD8A73VmaGn3Q6rVfWhnb/AKNS7Dvvr8Fy+pBsDNeiva/dH2rF1vZm89lmrY4psQrzINy6Y7TtbNDYWUPglllC70IIUVwlDQg0NQwmYIaxjUzmnCI2PikIKIQhChMijYGrCUwvcSpHsQl7F3KhHpZ6x+NDaHUO2o+lDb/7RQ148iZLArWTPDkPEXR2UPwLdil0IQlGjKUJKisNRxpZKgGAbCqqhQ1wJFFSMWWUNDQ0KLhjUjcTD4pCQIJCQhCjaFgbodlQ/wCYIM0NjKTsDxh5iG/QmmW6EdViqis1MwzEUWxL7Enj+B7RnsSOTSNQ5kVd0IlG5QsosUIJTZZsaGKKhQw0UNwVs4osXG0JMIJCQkJChbGNMSmUFDplooVmCSvILb++UaX+/I4r6xGPKkbE3+xx0ovX+BLQo0iWixwbGUFXL2JXCVnVQtmjqV+x/wDFsUdLRYJiQkJDSMB1qB7sWcWWUJljgQUUVmaKhRUmzcKDf0Ua0P8AAq9CQn6CCRQkJCQoKGGSNi4ZQVfsGkXI6axK6f7GFbp7Elr6FOWlY+nQsLFqWeALuZYjfAtCj8H7na7M51CtjG0apo7qbL9DuCRQhchQiKFSMzcTIlkoaEGhIaGoscSkqDDxBsscmwbei7aKVo9B9C9aKeD1lRgUIQgoHE5ZlmA1/caiGXD3QvCzGv70Wlo91spdWE6qkvRjNC3lspQSNBIEzA14XZkvZaM0ymKwrdht/GjoxYeYgqJqCUsanGU1QXirg+Hc5ZSHiHFsbFDEEyM+j0QKJ8CFThSFwRxBMD0mooYg0ZrqizvCF8v4P3Mb4Nt7EKFHUTJkM49li16TLTsSTovwhJtjPBQUNDhgO2he4b5qKXwXSFyNFFzDVMaCZcsnkYOEuBRMwhIJCUGhB6ZQKU2aihrkG1mU9Crx6GY0JXB3G8TfZdtnQFFAxjglsNCyMRodzKLgdyRck7Y2OEJmQpQIJS4JgxM2UJcEixjUBRWHUIUNDgPiBUvFBIpSpBQlLgMY4dhi0IOlFQLUEEhwa+ALZNwYfBaIhcHwBxQkIYTE5LGxGxZVLqKljHK4nw6DUxpJQUORjg9Rms2oW4FuDwINwbhhoMUSFHSQcMPEoRZZYx8QzEoQgpCyIZBYDCFDGxsbGFA3CWYjDjYll4HExMT48MMcM9FuR0UebKtlQq8AU7k2ExhcNIUIJw5zLK5UPiWXXghKxRGkJ5CYmWNjgMMIOKiMBaF5XA2IrAmSCYmXwCyyxuFGEWXKxDGN8eBuRQk4PBuKg5dNmR8FQfClU5SJIQwsvITE4sbGxuBl7ZdM0Qi5hf0+RKhbZ6BrHwWJ/AAsYlsUGxscBh8jjiY2NjOxxcEHBY4498NsNlwoUsTg7QJSSFDRiHtCZY2Njkl2xIkUdl8rI8Cv9xK6ViDJ+gcZMQlsR3NGEPQssbhZY2WMqKCkuGPgGE4ODtIYcBsUNFIss2j4KEWXwJLJCRUMqNyMNCy9sTENjET0KG9lj1gWTPRY7eSguQrSNlllx0JzioGS2LFBhMVBxMixBQyHA6DGIMMMNG0ooooXCyyxjQsVSKKhhBsbGxjOWh4CcGHsYTwFpoauhYgg8BwnoVjLihjTFlyghFjZYwokHsugchZZYYaGoNhRUK42WWWNyvgKXuHCooWjSXFnUJiDzkMVD1KrISXCuJmbviihCLLhoSEEGkqQaGhocVoaFziiuLGyyy+AxBBKLLGLUIKxiLFD7yzOldCGtlKi/IfQNWPIdJkUR5A/OMGhQQuxhmxWxLi9M4ooXBWMISkcVlwviKGLBoc0GbeVljGNjZZcGVcSQoak8MwHwyxjG6Q9250x/ZnKHlChJbDqsopkZwNux/seWWF1sy9j9zF5LSC2MxjoQ4rhFCUCLmITGE4HWUPTMQ4mXF8A2NjD5woYyyxsbGx8SKFcLGLBfBuLJE0WLKsV4NDyyr6wLW6Ssiv0VXUBQpC70NLQmpG3CPkNKhl5FRcKW6VjWOFBYaFgmWOOLgmKGqJRsNDZDHDdClwbGxscqaFxoQ0NqcpPKIsoUR2v6EDW9w3VPBYynZRDKsaKK4XGKpQ2YVw0hCxwg3DYSG4BfCRMqxwEzhSxhhuKKK4KXKEhIvVqWyuBcHlYyryILhlwbKZoYxjiyxDWxwVBxMuCSsxjUVj4o4GWsSEgfDZZY2MMMXKpKhcKKEhISKL1NDfAhQxjomyxkpiCDGOW4sRsLCuNKCLLGlqGIQQuWxsxghmWZRIULxVjcTYoISKGhjhFFFFCEIsVUMZ6IQhCKKEh9A+AMShycDY2XbjdHCJyuDZYhyuCYhDGxsbhChhhixhpmNjcViY8EVBCihISKKhFlllxaQTFBDHC4WaxIMYxuOyxsdTYEpUjDY+AY3CyyxODDYxCCUNmypKEijCBcMi4Y4NCWLBBFCDhCmpsxKRYo2yGyE6GGFwYxjDxMNjcTgYdYCqlBbjaNhix8LLGy4QQooaEFE4qijRZjA2fBjxQkiEWMclLHFZRsyWqHwMstnWx6E4EHQtHhCy+A1yO0suxr9IhaSFBeUqzn7LLL5Mc1EhoRQUDDgoUMbGLN0tQQWVIQUscJiZZY2NiUIYkwwsyxbA4rEMxD0KmGN0zMVBzZzRlwLSxxSQvusShCM/eR9SVBDwEtDuN0UUNRRRRRRYbxYQUm+EDQg57oUOVDwQnwahiZZjAisHaSxliUr3ENYdlQ6yz+w1rJ/AU8xo7jaWG4w2MbExhF4UYQkJCFaQbn24se9aGlYqEMcCnLgK4k1FQoagQQcjRuGWWNwMIYcYT4sY6GYlbELTWy3tL1vZWuIKKEJTKTwjNwIZDpiCX2X8lxhlivReAhdQJCCVDI7yOvCs0jZaxViyl1FBBcQIKeiihQw+BBWMYZzBssbHwGkEEy4NV2d8eWM3blksRj23b4VoSljSnsMFiHI8SnhQKMOGhuV0bFroQeQuxsSiCKCFDoNLsdWeOuadF+YUEyrZX4gISKKKKGoHwisuULLGHkYzQpaihyzRvI/6Icbjd2LO3zs3nA9qUIkjWtlXlK/Qtjna8o85uh1zXYIeh1jYu6r2JLSBdYXElBDUFw7GOXwk2naEL2C1CHlbxXxUMMsMuZjRY4aKGh4GF2MX7yMt0hu3kcpcHPoEWH0XSFsZbMvOaT6LJF49DZRX0HPUSeBkRtoduqvwJfU2mO/AsSnInoyHyXNSNy/7+Nm1ofgdYy7KE2tDVgJYIU2WWWWXwqRzHfC4oYbYzSmJwGz5WXw7jcunoxKeWOF5TeRixPkIX2K/I7aguR2ngVrKHuxkzjDhwMLuMh5dv5U3ozsTxjvjQMd3EKKbLEyyyy+VFDQv9P4h8EI8sWwH2WXCLmuOJuD19Y7IwoLE99hPAkPSio0N1s3SgnqDMTDHJi2Nvoatz+aip17DjsdvTLMMTtRZcXwXCy5/B/AjOBorAvFseZePhUXjnshq36LIxGErHYlC8QNFGmWMbSrzZiT5GXrC2YWmMoaGhoo9tIY7x0UNTRXw3y0Zk7Qk2JXHwKLLLLLj8X8CQkND3WC5b30Pc23F/I+Ogdf6NwuG4TLDwZ1D3g0y+x/8AlYFbBmW22GJ1JtFNKFFFDUHpZl7EoZRXCiiiooooS4XNyajEwF2T5qbLLLLPxfxBZGZkIHH3xa59cehw2H2NsehRIp9sJZCSyvIWp34ymab8Itrbgg5d72xwtZn0UOmUUNDndaNrjFCGUVNfNZuKEBKiKn4Fll8PxfwZukYLC1wLe9Ic+21w/lUuFgy3ouK+TzDM08CgnGo6x0jVjhI/bL7RSd+Rzo8Q0HaU2htJ2dlFDVF20Uh8ajr50hDq7/6CzCt6LXzUv4bj8f8ABcBKlR2YI8vU0JFZKKHy1Fw5TGhssf50PREG9K/KVaX5Z98R0WZfQqlgSloS+IPqNtLI+sGZNFZy9/BUV8qhuzMJqwkdo7FU0UV8H44pKjUyxqdlcLi/j6hXY1goiG1o7Qhzfa40OToP9g3csKsBCQxCQjbGniDbbWhWNoaguuai4r5ULZTWzoLeIVjV8AYoa42WNHZcvUsLnovgud8Wt14cFhGWy1XV5PCV/I2UmjrMW4uR11CNQkUMMLdONY/SJ1xai7eRSxFSLp7MxoH4BS0UNQQc2WWNFcbmtt+eLfFKO5qL4dnWx0kYTaMigeR3tNnWOiDeh/8A6ZlyapnsxCZkx5t9PZv2L/TXHZsst1vCgrpGyeOGoINDH8QPvqhjh75r4FFxUm+jAIYwxm5jUeAiib/A1X+pZF7MNmumhMJn0csS6Y2kMY3Pj2LCH+oas23QhWtIdswL2JWzAQjMssY4P4Iu/fQ/hQ/gs3FS+0UIfZE1MXYeS3IreG2HdWDBryFMaaaL3XhizZbYc+kJD3+p0a0a97DdKatWVouFY4OD4OY9H0BwXF8r+Kymz6MtxNxs66CIviZuNn30JxXsPT/gsxFUg5JDSNHRPpeSw+x1+qWsGbibsS2OFoTgsYxoalzOj6jzPk4Z1yZVO0zuixMbItXLsZrss8HZlWmkMynkVg9qPQ1+YV9s6/RPmikwSlKNuxZdIVk2X4Qlu+LuGhBjhzNBv5xUOGNcr+CuC/Ir+mRoXselFi0VrRo207FvwHfjEasYmjLGP+EJXn46O/mosTSjpodmLImxnQhKwlPUUUNQIMY3Mej7nwaOocPjVyuDhaKe2Huhgmxg+pAWz7P2ViLaUgaaab26XxLi6j7l80ZBt7LAlilsX4RlhKGxGkJI5C+JqLgHD4dfD1xImN9DHN5oVFIoqQbeh7N/bMR1EGq+fvlfJi17UIlXSiwI/oIVOQeDfLaGh8CqyXUtOhblqbwNTsQ+NHQ5WytjvJ1a/MwJlQoSoaxR0BRDV8J5NoZw+GjfK/nvT0SXvoa02MYYx5SSCrnaEsTRQ+I3Z5YrBsTFwcdcFDGWLcs7hYY4dNGtKMe0KEijQlZ5LYZSStjn2ehfjf6DuHfspUbZuYgNjFWzBCyzBHYlYeEXwaEFFhYlqPH92ha5dD3wahx1D44NQml7WDx5dw1C+jyylDOb9v8A4ZZVFcOpeIfw9xUtx3sWxFJnKCgQbGVYlQ+RBhCZMUWWJyxRf6fxDhS63hwYzItZOh8XF/Clvosa/swWIdZDUFGyL57D334QYRbyZdD4Xw7HG475MuGWOdq8np9UJyqDbNDJwhoXBhPg/B/EOGB7yQnT49Q+e/gWhfQgj0Jfsa9XosxJHnAS8UgfPqPEfUdWdfL0Lj+RyzqOiYhsJYmhDWxB6VQkJSMlDCDCcMZ+D+JZbp9noRiLjY+LNnc2bfJeKPcaD8QG1AUasx/Bynht5FjhuH8Sw7LBtfxzuWOKB+AuEIukxcJCwh7YkLkeLD2sYhhMssY39P4lx9TQTHqL4VkY9JT4OLL4XFk8Mvd92WsVqxcVXiKJPopw1nL3w64dnc+o7GKLr4Oi+H7m6EEUBjcaQkPCRbNOEJlljY39P4hjNSv7PCcUVCNDGtlx0Mc74LYhisxbDKl2hL8rWK9H06K8G/2+C5749TUKe+Flx2azvIsA3SGOsQoboeRIsYv3DeRjioRZY2fi/iGOWzTosQ+DEMuhll8LhCQ8F3fwKu7QkrOkmG2Le0/uBYnqH8Gp3ysuLh+hjhKF5Kj4RfgRURtgpsqDFrYz18lLPx/wOHBLFFrsTMS1ieowdjL4o0WVsuywa6F7Enq5CVGBG/i9R3yZcsscOaNV9mEKse48uKkMcII7jpDGEoc1wZ+P+IY5K+WlCEVg6LijqNy3wQuCLO0y0xwc27yx3fo0hx0bhT2fudQjE659R+5c3vrR/BG6DnsVChykK/gkXG3fwLLLPx5Y44x5EaE4TNy3Gocd8Eo6GYKuTHCN5jUPnuO56uP2Ghs6hyxCbYpV9hGyhCoY4SsUoWlzmubLGN7UYxxU1Psf7EQpfFRXBCRWDqGvCMEYNR+0WbOuFY5VxuezPKsVhCpF0GNjirEIFpfiOuG4ssscDA+A4c2IfTKKNdlw8DH8CFDwXX2Kg2IXOo64VF9uNOFGBvlcXwaldCVJIQ/cSxuUhSwVRuHiTSWWXwEI2MctVMIIWWUUUOa4fyCE4dZLt2NliwJnQmRx9/grJ3g7HiLn941+5+89G0Nc2qQrnRQoysDHCsKS0NI1iuNxfAuJYxJVhrsMcq2I8DbhMT9CLNjXG5RrQsm9aQ3FFZNCtw/uO9HReRlQ5/c8xZvoxG4vleqKQp9mxsaLCpblbgoRtNMqxhlyAljUgxza36fDSKh8VvhY2rryOkFdFEqW8rSUWjoS9VwxRfgyL6n0fR+4hoqdDO+b1+BCsRX5aGxuFYrW528SFGkdzk8uFwOMJgc3qD4dzVN2WJy004fFyhLtiWPT+z0WB/sgmVIRtUxapaen4GbXpmSLP9s7OzCMm8FUdXD/ANiN9n7R9fmHN8mrQQrBWjGCqhShWt8C9inDg3lDQg4MMZImBKtCoPcqnoDzKhlHfOmJLyN0qNRsjMi9O3g7Y3Fer2rFP7Ii2K0bKzw98LP9uP8Aan+v2i38FjsitIUotFCGw+AbdsSlGnDZwtwYYzJrkjTYV4ynwa4aiyxUM3fgHXeQ7INSLxmekW2N9idLpgz/AGlNw4/Yeodjj0ftH0fZZZfOgKEKkIVoihIozIUjWxIooouZ0cN8uN8EyRlii2ocFDMygGnKcWPhuHF5HkJWJN08MwSVPyXOzKVuPct+/wC+F8Fn7j/bNj+hv4cqMKELnChKoGyouYrC4dzGtpemPJjUHG4EPmMZ3lRdw7VBMFWhCcOGrhmhvJYtxTcOihKjrZs1F+D2ez+jcVFVHZ/tF/FeJOitCW6KBFCVQNxWisKDGxZcB7nZwbDsaY0YZ8MsQ1g4DjswKFCheIXD9ps8sz2JQ/AkIeBmxSzo6j/amzX/ALF/CyoKKFjsUJQNjFhQoblcjVxDDkrjZfoUudRoVuxPgIS0YOoUKXLiiveeC2KOi2YZRddzYj/aj38yVKRWXsWkXIigQkNjY3E4XBKLdwZUrhfDQtQy8adDdhosb8p8fuahb3KNFR+/9xU964P2Lz/030aN/wDoy/hbMOYRUCGewkNjY3E0IJDihBKD8FXyO5n9f+BpW0ZgvAhjHJx4YnH7nQlidGhuFTZ0aFH2PC3Xq4a7PqjKZ3Gzfka/1T/tDM/E2JULyVyNckUA2NlwNZsQofBGIbhXBRUUUUUUL/T+BQxl41iLIq7hRoTEKKh1O+9Chl5iz/bmzJX+qKYvr+jReMH+0NryX8TcVnhFQsPIA2NjYwxQkVDlG41Kh5co0+H8H8Qhwlozpct4y5DQwnQubXRtD+oQix2d6/qOyjReP+n+1F5dS3gY/jpd+x7pUKX/AMAw2WNjFWIVDmhIUySxRZZZfH8H8QpMtF9DHMmRfFDQwsDcH6OhKYlCTLo/24/guLR3/wBMxfgeS7/8G6Gx/Gxb2MQIV/5EYcGMUJFQ+K2LRY3LhZZZZZZZZY39P4l6GWJainFhdhQ0NCwPvE8G8jHmLF0Ku4v3F9Fuy/8AUXXf9llZ/wCC9fkX8mN//D/bLP8AaL8DY/kpKz0jynzGG5aEipfI1jHzPcNwssTLLLLH/p/HIy7gWpcoaGhoaHFCaF/sHiU8/wDS34LG7Oi4X6GWX/qG/hvikWv4EMhX8gbG5aEpfNBsUNnwsbLLLEyyyyx/6/xFxoOFuB6wpwPaljKpjNGRW2Z7Rgf+yP8A2C40fxNmeNnXyK34QgtfkDDY3LcV8SEMj0OGdDY+CLLL+JmOxvA9hdrHlRWCjKUsn2N5Ldzjh3Gyq7z+D+Yb+VUls/gQh5eZjfKub4IWEbpY1F/oGexi2jLQoVcYKIuLGMbyIfJ1jP7Q4uP9uP2lKoY2N/IlboR7I+vjfByhIe3hc5ZZZZZZZZY3GcmpWw1ZgKbCmxvgobOo6izv/hcJf6jofscP5P8Aq4YqhD+NxcoQh8JDXK3cq+L/AMOG4uCDZcFDFwbCiyy+F0vJc2f7RdKUVj/hVHsdVr+R/wCyMfxuWi23SEVWaz9j/QIQhC5hszquoIL5AAzi41Eo0M43iZFJxU5ovwMubfU5ZReP+jG8lj+Spddn7iEobv4XD4pQjTM3McIawx7kXyPBHPY5mMb4Li9y+hiY6S2+kijo3hsS21jyswqr8FQhfZWKsbHgP5bVXYG/ifKuDU4000nG4ssssssbMY3kblKLkJTFBsNeFWyih6OkOrUVtYV7F6M2rPCWNF9DWaOz+o2Gx/K5F2FJel+iUIwUNmfpny74MooqGVZUrM2EpXs0UXOENoeYzYjQwW/QGqmzXQyzK2jCexOy8DwMfzW+sLSF+hUotYe4sHhD2vyP5N8UUUUUUUIwGKGNI1Fw4rJ28jYwwqkg0uHRlhDQnbuKpPeTJXUMY/mp3WWsQ+HUdfApSixY+3N97x8L47xC+VxBtyFlxcLbKK7RYyYfVyhYMj94Y8FqGP5npe1Cl36IShvMV5y/Cvjtmy8RY8Ci4B6hXFiNFiFmKKPoSIX9j9n7w8D+bxEmE+Nw+FCHBc6Np+iY4Cyy/g2iFllwsumMZ4EJga4uuDj6G8CYFj/2LjT/AKdjlv38986q4qK+GihKXLmXNufSaLBvv5s4D5xhG4szqhKFsYa4l4Op3PRlJdSvJ+S2/wBJRNtwh/ExKUpbheDGnF9tXzgg+QXYw+HmlixMMWv7+SjSh6LP7HFi3kdFw/nfuSkI1KoXx1FFS3Fcxm0+k187LLLLLkfMTLGNFGi8GYhvpMk/uCLFGUfQ9DOqKP3PRv8AS+BiwhfJU2NwF8PsyudFFFFFFRuhKLhqS0XY7DG0Wp7jM7GVXDR9foqtZMfRYhfytjcGIeRmsqc9Iax+fmo3jWS4vJfAV0ZBLAVp0zTgo3GPcuaGP9AzZGo0IKXAF/HY2MNnRDGuVF2csuL+TaJJjcEzAiD0ManUI9cO0i4Zrl0PHy0x9gxsUKBMuK4tlljY0DcN44Yy8YyWWWWWWWWWWWWWbxrhcWWbLkXPfI05+xvOF+op+9GWZ4hUJll8bGLLhhpfAoQ20ljWu2ssssssv4gA+RoMTAxyss2J88hLTp8Wy4f6hdvLoR0OxdQaKK4IcNjfFxy2ZwR5auNllllllllllljZGMehoaGihqFQyyvjqOuL/UKS6GUVeSxNFFFCRQyx8dBsy8Lhjukr9C9n/8QAKBABAAICAQQCAgIDAQEAAAAAAQARITFBEFFhcYGxkaEg8DDB0eHx/9oACAEBAAE/EArUFNQacQi8S04mT/EoZmIBUvgXEUIxqLeo3GPLU3DuK0XqUrN33nGv4VKHQvmJN4HaGWCZcATHMAZBXuAWGI3ciUaIt7mxzcvMT2PSSq4UfVwJpPiFBs3ANlvuC+P2QIA7keYyjlxAjTFYmf8AKb6RDiBRKI4xWwYMqIXIsTealrioi3BlwEf6PqVqAqAzCRitoi/QxVk/mShlFStMxEIoibE8MM4lHSNduiE5fYaxe3HlNQK5S4qWtr+oYy5YNWvggleXeJHCXd2bgmgicS/EeaZaq6eJYisGCSvFksq2BeEfbHPswLdicL9MCt8KZUwVdheiAlAIkp/yG4ekal46MLQUFDGBK11DoESXGGhTMcwswDmVYR+NyqLWMTce1QoYrTURB/idL6dxI1JgMTGYg1qespUF2hq7WDkAuLgLuf8A4EHsBq/+Q4oKnd3AW0qUMV5iq4qbJTk12lqowRK5i9k8rEEEy3tLZcvxB7RQpLJQt1F94c31BWJQXshli2Yf4xbNE0QSugQQvCdIki3B0VKmGNOh6JI1SpxReAg4AUQ4xGxRMT7TD5jPlUh/hUOu8pIMMZCgqlkpUqAPC+ZUbtgaIm3yfgmUTsQWgt3EKvL2I5aF95tOpnjUeYv5h5TbEVZZhOMqu8rMDlPZUFmrJR3Im5eNy27uCumDV22wD2y+JjoT/Dc9QESVAhvqxNo76V0EjEMb9WMOpQamZBOMJ+4Y0QJUXXNAAutRYtWopGWMoE0R2EwJTEr05LUwLCvlEUB52wDQQN9iIisHYwRSp3+5ytxzURXjygmC0iJXEewhicyl0Q5sU4jFs3FrmbRRB8jKu5QwDSSgvf5jBTiWCZPqNecvibjcpj/iAwRJzBqVvQUSKUiZlRGdyVjSCBMpV8H1McKpeNEzrACZGlhCNwYQfMFxaVdKg01WOQD4i9x6hTYjkI4CoFk1wVUVBLCJEAOVjVwgyp9ERkF7O8AAJooYCUJGXUDq6hwTbepjHJxMFXHEoigveo/ggc1jvLiM+55YZi0Tc5xBOZZqKLoh6Sk5CN7uNM8GUOdQqjGZZliD4nlxBT/MZghhhqMrMqG+hbK6azMkogTnocS8yk+n9SiLyWjBGNjc54EzMOqgfLUAO1jlJAzBy/R7gcAxL9CCCWyA1JH8yiKkjMSjEtIAFoobzO9q1SycDFdoGkhghxvqy/cd0oOZbQtRs7y3OJcw2xoJtjUu8GiVFo0QLIqUSlys9pQNzE8p4EbOIK+CbaT3FHDPEr2n9VEduHidvMr8kpTd6xBYG9fwepzBDDDUTo1OekgyQ1OesL0VTGeYK8Rv4PqDEshQDpBSqotVcNtty6xHTUILb8RBE5jqFswgoJUNBI+sWrhd9x0JgJoYCJquYbDbIqFu72nEtwCLpt7xG24NEZQfgjqlvHaDzpAWIFseEC8uojRCFmdhiLflgBtlnqBynNzc1qVAxuYd5nFv4iGIqb1EHG+8cBL4PEwg+Af7g2l3uDV3UsmWA3tCwc/yGYJx6SVKiSs9BChLpcGpkgBCSLMvMIEB+H6laGO8dxszNCgKg1CZI8W3zKot8Qhr2cE0ftJkdAC2Fu5AgtPmIJMKasxNge0tIrPbbPA3gGUwZMNc3EGm2UFa7zuTNBKGHyyy4JgW9I2xzhLwCFsZWY4xHMKgnzB7kWEsqXQcpaEEKoJXyRDhklKZm+Yg6DTlMX+RzBBjoCEYw6X1Aw6gyxiiuH9H1DeaLmC6LoE2wyI2wIAimwiIpMxpMBMANxcpHK0lvuNc1R0mOO1xBKbjmVhwTA8EC5Yqi4rztHLMalaCK3ZcpK2cspBKG3xKvfaCWYKNsMq4ATbFxaT4hu2O7ZuGExxLJlbmAyxKeIqF5mLBHY73B05JRSQFxo13gedxxHmmVI/wNy56AhlVCk3EldFqML1tLlxZeep9T6jMs5qNOmAI0gF3PiMqVElS8IlQ4LZG1uDlgjKZtlEog4gvUcGr8RVXnTk7wK7qu5x4iHCcs7QGb5UW2NHaCpKSgDP0gb8xWbdR1mDVSmBEdIoa2y6hbRFZxLPESVRKYqwSr3AxDLUsEGoXXo2RRAYJU86ZTVJ6lT4Y+YbJSv4i2aOihDKiriJEOINY4RTiWiRFjMsEQ4iV1CDTF+r6hN0UQyyrMdMcYoxO8YzrEMEZZG6sAg7WzFMO5YMtUaQVA4jwxBBMuUl7UK9xDFz37TCZ1EvJvmNHI8yjOAi22jiCcfll24yEvetsUtBriIAq1uJQBay7kjRVUd4Yg9wtxuY2SUuCV3iXt7TvjDqClzeZk+JXygZqopCQCZgYCYRGBo43DJlzDEXbB/EX0CQXqkwKjL4XJlxMGoO9TwSo1HHU8UudReEQjXp9L6jFH1FbMpWZWINoVhnOTAWP5l5r+ZZhewxmfUwbmHctlOki0uGMsr4pfWtmo2oULuAlRVRDrg5ThryW+JanXaFswrwdseDs5e8oqsvEtvl4lYrLrEQpohbgo1iHW05gnUs4lxRDBsm5qp2XMoxHeZH6lELKCIbJWpZS+YhFDcz+ZenaD2KhDPECkOo1f8DBiNEisgTKUQJY1LpaangiO0B2hHENNRMDtDOIF66FNw0z6X1N5QxmnRFajUlbUOyEppi9xVYWt3MG43JgmdjeO4uiGWUDXz5jW7cp+4lbHg/uIcj4X4hqiThbzKSlNu5yY+IBpCGAIOLlGCk5rEpptzZKrZ1BbC29RF4GYNOzDFpcbTEDVQtCX7INipjYnhlDmcjUJJSpGjVQ0keIFM4JBTOKiZ9M3qc4hSG1Nup0CZpQQZSNiF2ZJiMdAx1EytwZmlagBBlDLOitz9F9dK1Kx8pQYgXudpmWGO5SiMNQIixhjMMVdwvFmZkBQfxE0A7XiJQrdGYAtQpEzDyKU/SZjU8uWCUUfK8EqBf2TEDg40QTO32wRKMVPCt8QIGDHxARRzADUpclzliBlmRlPEuuI0CZ7Wp4pacS1KI4rpiz2RwGtzanDAKxxKrKURw6hXyzOr4gsuJySpvm3Uhpms4zFNHRiBmDiDUGIIQizAHR0g9K6MKJcFfH9RhSmNYVOZVeYNauHOeWN5ZUKBKozzBuDiLM0hE8kCzndBMas2YxUSa6wCGAWWw4lK4sUKg7AdGnaOAAMqyko9XCoyYqszaaWJeP1Mn/ACLPJCnEoNSzUtvEcI2txFxCsBMcVmEKjzAKT5gUJek9ohgZH9Yjkp3VwSw2TYPJL4YYZ3MrN9pdgY5Y0xC53JQVdcmHoE2gvoLhtgg1BiXRMEpdx84G6uFzc8k80xuZkwIjL/h+onvCnmlfMsHMdXMq3gpLDLSU8y3nqFrpNTeaTsme8wweUNVnHd5hsEd3hMwLp9OJmGqk7EbxT5fMFLAP3HVTPHlh0X7SA7WZsXFEbZ5jylXExEEdtaRMSzH7hwVmaXlVK9MEvOTxLQJ3ItNXRfxCuGcmUNAYLEcXcv7SKqVzBuk2QnGtxMQvqHvKW679AhxDFRGdDmYMoOlgmFm6OcxF3OK5bzGeYllMqJB+v6j5Q+8t5mHcFN9JULygeU8s88rCDcuYbekYQwYlnOUFh4qWTILakcTJx8MGqytPv+sp6iufCv8AkBnY0lBWArRbgJiUYMXUofEpcoDctXDKRx0YZQTF3GrgK89DZLcztxW65gpTwwBcXsmDmyMreKjFNGIc0cMyJfEvNnEEc88xD0Q1AqfilL10JZLaj9Cgg4mSUqMOjSbmLcb8ywg2xZYNTBl2LGoNRYs/R/UfOeaWXcrbhzAilfRsO4UNyzmZ8xeUKpi6GkMOI05BBw5gYJxeZanNwBrtFKY5jiEz27BCEOVY8y4rd8doExSzb2lLzqeBEfEcRqM0mobncx57xvmUhFhrU7E2NS/NSvD3Edy8xzUwfuGcwIRQyz3KrUxlYHiG9xUKXFa6C2XMvqYZ44OGUMIItdDBvpIvY8w1Kz0WLmCJR0D9P1FxVxXMLhW4LLlD6G8Zyem6aeoVDDMfCHQMAqF5qVCJax47QHAFg1xfMrsfBKxcUerDg4vvAFVXuwVLfRAAFSpwytswXm+hgXnoF9CziKZRCoKgzz0MjEvTLzB4il9pmDGylRxsjGYxNpdkcgY8Y1BLV0M1zRMEq6NZg1CQJ0MGYNxhY2iWxalKj0TVlhFwURfp+owIEISSpNkefTe5uD+IgEqGDJAz9Q24FwCTEHJVu8xQi3nHHYlajbaAxw2mIfuWEsOYOdS8RDBeonMEvHUylXENwSkyiVmZXBeJuJlqoiNETWSnmcAuUbDMV0kV4mqe8RBBmpd9o7tSK4IdTISmsQunjih6KjCFYwnWGkqYZi7jDlBbLwmcZIgFdvro1sK5g3MDMTLlYuYQX/H2OIEqGDM0lCvLLqV8l5l5CgcQQKnJBwBrEzBAgFVWIk4g99++h/EfM+J2TSugXKMS5pieZ0veGy5ROYhHNRouLjd1C7ShF8YFgzCL6EynLiXlc9ovGhFhDUjM0ypIiiPEqmnUNujGYIKYLUSEeYcRxGBmXpMJC7Ss1D/H9EWNC4VdzDvoLLzLWMyZd1qqugIEqGHUNkq5l95QCgP2wARa8pEDVRBgG2CBu/MDVB8x0BASaZqWXRKGZRbIuOnOJuaRZ8QYj4hYdoBFc1KGo5xEX/7HLeZ2sxLuC5xhmbE+ZhIxEK1CCHEd2Yrk2zV0FVSmXMWJuZSqKI3DcGJtBguUVBDibRTKNMwkw6mGfpfoiJSRRkyjmYaGPyi30Gf4XlGGCBKgl8wxjXMAFAUuoZg4iUsq8cdpTTiOCi5V1KN0/Nwq2rU7AlPJEGbqUUcRFTDGz4ilTMDm4Ns0mybh6gAcKWW5ocHeCMqPaPw1C9WvaXlkyurSeIRgs4jGDyQVagmIkShdo23HOSbYYKmkddHNLZnAVMMz9AUzBKLNITDcEOJtDcYCGDE0n1fojHRKZeLi9CHM0dKiBqGCEqG0lIArA8pNIitT5NUFBwQYJlB9mOOV5eCZrMNMI1Ah4bXxmAaEHnbG+vLxyQcFF76Zr3tW+ZtXVYfEoua8dvMtRupm1eOOi6RB3JiK0yunnT38TZLpr8wlrAMTFeFmB4JYlX5ZgRLG/IPuHO/mU13JSgntiF1vcqJ417TBm9y6Jn25ZiIxlJhggQlTL6msMOOpkmmVsxzmYmSGiDZDmDJFVdIxmKfo/oiOjZLl9RM3UjDoEJUuTEWoUvMBykXVfmUuOhMA8SqZpjmoCx3m3R8ywdi2lsOFiCtcM1m4Zcn/AGMmhdWAio8I8G5b3R8vaBW4GqcCFlhpL14iWqBbOV/WJS4dvNcxkKwwrvpnEhg2hxcVvJDGGLlxGDirEE5pl74iBgUiHTXmGYGIdqj1DIFPiHnHkgWgyRyDrtASIObqVjH394jBBZiCrcwO0dDA1grABD6RTjoFiYQMxUxzWOeklR4sRHpGQHQxWNcKMVVKYQwT9D9EcOmv4BLpnlFQ4hggggSyKEnEoGASbIKKlv7dYbSWCW8XkgCgHiP2+ZUCKTZprM4xdzhlGm3hR5MxA2iaU2HnnvBKrDgOTvKY5RVuSVnZS/zHRa64iwB9xJ7icj5JnLXEWlrmnyTNr5bjbfMV0gM2lNhDMko6IZ57xwQCMKA91MmK/EIa47zM94KLgHXZLKwcxWFhW7zJqvUthFyRTjos7Q5liYY1lEjaHfRFIKYYzM8S7gJYwUxygjUm/MN+L6IsX8bJb/G4FQQQIcJxlE1qAstU6l2jNSsHyJcS41CkIzDIBpSA0DAOfzS3V3zHmxMA0wUYEQtP37jUOzMwieYgzsgbY+IR9Ic4MMQe4vecsEaos+MwP/ZA8KPZU0hYNhgWKMRKXiUN3DiHH1Ms6I0VX3gMEQywY0qWrHMwNSiMJcKoBUYUYCtxItlEcdQUIxiPRGSiYxx6SPw/UqLYI4J4IDiBmWs0zHKv4oAlTGKalFGYvERKElo7WCyZEsw1SAd5eDL1/BzBZVyFH6lCBUxe37lIkGXTMETyGWKNu1BjPg7meeTa2TdkoDWYjhKRwZ7z8aXj+pjKRXASnV93gieb8uI2HDWIKKwDFG55J7k2SHvhN9EhaKu/EEXcsl8pJUTUPaCCG8wUxKtjZtzMBM33DDUxalUFdKpBiHUyRQCpmzBGnRhhaMVlCNVHWpZF+v6ivEtNRmMGazmhCpKE4Cb6PHKYfwAp0NGVV0wBMMQN4DDkjRAxBqqCFXwOYGUzyKqZM97CZVjYo9LNKvZxDQs5XXmNmdwZgXqGENLyJgHvDoZYy1wiF3MyNcfMGLUBwcjFp3LUtMm4NEAs2tRLWOJhlX3MbWDVhvsRRcucdFRHGG54CJ3qiVDSI62FeGEFNQ5SxKiRpaQyiNEdJtqW6aQagtAaYRmZdAgqX/B9SmhEMDKAqEOWDSEHMDUZJUbIQIJfKjU9ZZxBjGDi4RB5IhaZdzcZBgxBKUcbHtLuPly7m/zD1VMtdP8AcYTCriEQLt6bf+QDuAD/ALFlpHmKbDjLcOqZuZxqozCFMjHsM8cNMbgsBz7XLSgbDUeJ7Kg6FvqAaBNGYhd33LFi4QQv1BCgxMGo1lBBiIDiGZY2UYRGaw7HbLswcQUNoLxLHEacdIaqXuppxDDUaRoQEWXFiIuVMt5jjNYixvw/UEgRTBVqUGprqHWSFd1ApxAFxLjEqCCWExwwwTLibalUoB2YiFo5BpuHH10JcNwLbmJzC0KuQwUN8Q2krFCNW69ko1g7EqiXF+zEwZiR3ctbES/MqI+zZGixVK+UfEoso71BljDwTMEMGlfiXBhhkmswQw1cV7lp4iFCzEll3RFSNEepgTH0Z8R7EYdR3iOupkMSs1PBMWowTC76JvzLmZY0YcyjnBLpqKD6+ofaAYqGSrxKEN6NKllyiKgmaHpeGArUG5gj8LMrUdUzUQE6PEsgTwSzmW8rG7qXCyFWhKmpVFEDMCiKhmSCZEC0OHkEPQp6fP2inD4ivMw7SV8BANShHf8ABI6VGJQtHTYW2lrmVTAS+A7RNag3qZtQjiFcFIUmCGhmdznKOg2ZWXOgLTFKfg+iUQZRCqixSjMyMT0D0Ap6VGQwilkVPmUDmpb0YZ+p1Kx0ybmToAg3dQCJXQGcRhVTNWZ1qUMFsBlHNTKOyy1qaVKqOOo8xXHMoLpCF6XSkDSCWUiIj1c1TBABCZgTFxlkpMVNJWHca1QtQwnilDAg1HmXVK/i+iYRwZcvpwIlGMriXnEWOegJV0q4Q5QmtPMRBFtQaCaQcziU+YIcxzGosxCbildAzBRHjMVXMlmSFCxmUDoAqaRmYzLcE3mc0ZXfMS4uQisjifCQMNQipqlVXATqaIuZn6LhGpLCY2ptalDqB4QZRMIOZWwlJ9b6JtMJp0EZEKy2Cjib8R7qpZahGEQ6sSy8NYx0DGUVMzXePEyzKx2jAhVPNMrANdDsQV4+ZSS5MTU+Xp33KzECyW4eNw4T0KYQiU5u6gMtmRNIsQqCEAodEzCt7pmMaEWoq30bOZablKaR1KQd7g1iO4pUQEyWXRowoTB0CEINZhgzCc/b6IylS5fTfRYS41L+IOcR7cRuESulpErHUrICpf1mKlXslxMUAlX0i4ia1KCPcuZlAmI55lDubRxDSEKPLBiuViqGnceCU4mGH5wZElcstxxHzjg3GkCtxXBkypqBZzKGEqjo1lDKmX1mVTBL4rJixr3LiH0YI4UKuUqEIISxUJcGMdydvqcR6iQIEcY2mLU8czOJjcRNErMqZ+pCAViCVuNX0KW4ip4xEOnmw4lbGlQNcw78i1GrT8DB1uVZWULnpN8QbCe2DmE9MNwyrFcoDoYRpm5nG3Mdo0IhJlHhlzEGVjMC5glUGXMsgAirMXQxdIkURDovOtkjrcatxo4GLiO4v1fUvHUX0kygXEgvo+CBTiZ3EsS9maBUwRXEZp1L6jmKiubmjrX7wqbYneeWHJmUlpHNqGonUuwqpYbVQ9/MK2YywVQvggZZcb/mZa7zluWhr7hUKGiGlQpLO0vWYmpSRlu7l7g94S8RsWoSR3bKruPnBqXS7m8bKmXkaHTANw2QiATcyRwjLEWFNxUJYQTJfRpHKL9X10NxuHSRVCG0uMJUumBmXUpegIMSppiKXMwsmEtHym2Ptm7NBCeYJ1KwxgQQZjNmHvMlIPmKb40zPLV2ItFzyioWGJSKoEzLbzAIdHZYVdyluOUbQOIm8RdzODFgkcprGIUOJY5h5y+Zx3FXSAnIYFbnnloKTySwgrBCX3iNGLFiK5Z1DtRCfS+o4RhyhjAjDoLNI06XcslgzNGrBDNJUz6BJnBHOYlrcUNzKtgjGDvBxRBQJSQtzKiImUH+pZelsvNLjuFUCKqJKmCrnCZUalGmZD9QRncDylxc9CnoctocEA3EszhCrA6BqOGMSLOYMLVxhx3MTosEtNSnieCXP8bAYFQ18P1NIzlMZUDpqNCPTRAqMgtgvorCCFRqKhHXQb5hhAo3ZBpuWioYMzGfuFs3AYVq9EXJNzL4iNvMEjiOYrEodZla1K4uYekDM8e4PKIDcuMS0m2NahucR1mL30MS4MHoBEEVsJLS7mCLKRncmSWVNDoLkGpnZUw+0vZaRiU9Or4fqB1ElSoxdB6lbOjO4aYixYlwKjSKdRuGZBiQVqtzOCZ6GoyDEyGCCIyauE8JsXLNXUo2JUyPzLxuU244gygRNSS+tIgwfzLGEjCrjyyTfCENjZHCmGDKCe4sN9L4hmZQvFYKWJkmD0VcthhFdp4JU6gqCJUhLRHiKGzpDpHMHiAYEJB+v6gwYxuXGkYeIuoF4QsdLd0aSDMqYJVSmpgqJcMRNgdyXmNQqStwWHTkgxR9FIXZnuS4BtIZI6xsezMgS+45Zl94TdmItBh4ijG8srWyd4g32tEs5BuF6Y1yPmKLW/MthUvrEE+8VS1YJhL0S+h7YIEulsCtQO0qiVDKIbiWEIrWSGjiWGiMMEtGeruEVwxEdR7I/Xf1P1CCVATCMPW/lil0wbI24jaZJVDCVUuLGDcC7hYjTEoqWqAVcAKQxsl0AHitTMHsaR6i5dj8QF6Q2Wo5uv4CUarcQBo85jiq/EbWqYkSh4SM3dWiZQCFdyZguWztIDJ2xXoHGJdS8XEdyBBDnohUsi0zB6ZaKMNCaxILuXMqhdxFJMUGtwtCZX1ldvTeFuL9f1Bi6JDiYTL1S0IlwsqBcIEqJHEcwbO7MoRgX2jmXQFgYYIFRoyiZlnBClp5ibQ3D22o/LDmD3wQUA3zNUBA9ocaAq5klkTHLxHc1LmEG5TW5dwxBi6TSEJRNIbYgzImSEJmBW4zhmTBB7gErmHcqQe8vvPSusuhLtkeU4e31BYpcXEeJk6iZmcxmDCEIIEWKNsICYenjLJLpplldJtuGnEVQyTBmMroYxuGs2myL5YdtstP3OS49zBpLCVTozcTh0LT18y46XMWLGWJe5WdFLHLGE1TNIJSyswK3G/MbG5mwYi0zCD3nlntLjfRJcvZjlhqAmpUXr6INMMoGujh67kzKBC8fGMYwKlIPRIwZfw/1mDMtwCLc3BUM0jCxpd5gnTMOsx2ZmiJfUs3O7MkCa1GkcqiNTJFuOGITAuVCnuUrUAdSp1HKUTFhjLRGBKx0EYcxoxe8vg3mbg1Me49y3KZu55JaCzDAXDiagFwH4foiy2XUYq5myZ47Z4QyyJqUwQQUYL6DpEmGKoiKiwxSVfDooajsmeOhEtGbsSzUeCIGty7xFhdR7Ux1BFbEVionY6rYAglTKYIL4wxFQJZKIlTXRSDAxWQRxFMGEZ47iAi6VERgMtLQx1IImoNM/S/R0qYdPHNkc5mmSZQwtFdF/gDToqCoU/h2ZC6iJGCc9LbEUFkFzBEVAeIntD7RDRAhm5Ujwx2wQ3OAY3jNrAWB1CIKCXUEFEEpKRl9DCOcyhSU9Vd0WuOyompURWMyLhJVlh03UolPMzNzC5l3xfRCBil4qJml2y5CIOpQnQFPTeCVK6NS41iBlgQi2IumyWAYckcpJYnlhOIoUkO0QiCZMZdQBmeWPRrHpiG5ku40JZDooP3Bx0EVsBIqWGSiX8zJG0UYMH+AMLbLmYoQ0IixHiI8QuainEacQpAthWXyjK+Uwblq+vqXLejCY4swK9LCOOKuhx5lzaLoEwiiwCq1Caw8AMuiS8SwvEBSxmROkxMqZIogyph6uGMQxbh8wYoalZcz4Y17g5blhud9g3uCcyxGbKiAiTt7waYCKGiIVBiGbYuGlksdxcYYYWEOl9Qu4JcECpfL54ofaHhPFMupRMkwIZRGq5Z3Po/UCB0BMUoZtDfWBRCX1ElHTMIVlkI2wNBzLCSwEZgpKmZZYCAaOpap55JcUTPIzKYPaM9MUEZizLW4Ibm7MyVBeYtbxO6zNuWbZujJlmAVNymDwwAAUdJ5jZN4hHXyrLExKYKpub4zjrijDHCUQLgpaW7RcXHsRTqOcRw1CGGnj6RhCgjjooHo0QTTp9H6j0KV06xWxl9B31Ay456FTDoGERylJZiKQWRRG9sYOTKmLsEq9ViC4DEJ0WMetu5EqjgbINX5ReC3HajtuKGEtL3GTuYlbcZ5iRMZwTOBjMdexAAR0LZQXHLiygj40/XQpC7X3yqRzFTOZkzccmU8cPCHhPDHxj4z0lXE8Eo4muoZ6njlHSKmv4c+CWCKLmKsWL9P1FMI4QZgaljH0tOZb0Bl9HUw6RgcA2oXThBihzejtGcQWF8o/jpSMJYcBYwsUs45jRl+kZWDwZ7xuGIuHuKukS5uLywDmF2Y9sG9DvJKChBOOrFkxIjHBEfbXB26XLhDYmrzGJ88MMCZGUdxsii0lQEsJ4YPaU7T1le0PGUcdAw1DqCjqLyeKeGPBcQruWcRO0QP19TP1rjKhOINMyzVMW+hh6AQrIJd2bmTifMIKj8ywAr4g9sd2LVJyyiownbEyw4DiVWovbUs4SlpILneCxt45lYm8EZbAuLcFm4LG2kTbAeScYvBOVITiCcQ+3XQkAR+aEcFTT+aIRjkyjSwMMVckYYOGkBCQn1nr0hhBJB0JSHQeob+JbxL+J4IxoihklIV2+iOpvNZijegJcOMs5lvMKtxogQ1BewiYguT8EUt/NOZ+abzL4hF6ippQTe5EMQLghSeAuCaa9XaL47CBVBoi/EdTAwQ1Z21BwLHYgZLHMGBZ8ENKb7sLQITeIIXU9JhF6FAlQzWACHBwfzOP4VKlSoSSkg9KPeIcIR1HLHHaVhaZhMdSCBCECAdWVcb9CzieCeCeOeCUDXb6JbFjKXpcxmojtHvEAXBkAewYuB9sYtit8zwjb0wXK7S8y6gt6alXNVP7hCt2IhF0TimNDDJyd6YmyfCGECZ7K4nI01SloEcJfeVmUYKqy6AqUZqYhAtLojmA7RDaVQUhMQSsKRASomBVxLHDNj+NSutSoBRE5JWBYcwWxvtA6MEsRtNyk0d4RY/wAC5fQQfwAelXM+isDtAeJUXr6JpFzGLUpLuFpdD1CWYvxLlERBVVeWGC5Vsoro7loWwxKhKvmJUUVcdF8xmnjASpjibMQ0GBQdu0uAe0Ip2lwrHlOkKLJe6Ys4jLUh2nk7R7OzcVECXQRJgdJmKrRccRLJa7elSpUrpUCECVKj1sPiL5tNAnmO1Uh9gzOFiEM0xQZf8FP4AMGDCYeh6A/6OEcwJHUdxIcZjpDEuXt8RcqHaLWXNsxBqKJHULZjVysTnEqLpFCLMMTaoyniK2skdwltYm7E7mJCc8TURLfQyQRlRLR0LjnuTWUb4MPiIvUSPFQ3KKL4HmMLaXElSulSpUqVDoMKYdGqhY4minzARgjZ+dBog+YNgxY9AYRcuDFBgwYQRccwf2dkCssMxAxFHMFZrBG1b7CNhRcDFVu4suDwy45juXEcxc46Bn3LRlcxu7Zce8zwczjOW0S6lEs1EPM8OIUeJXTUZW491FjMWSC6i7OA+JZ35D8Q0gS1zFUeGoJl0aCXyy9Bbcexy0JpqUyoBz1KlSoGJWOpcKQb6VKlMFyMMLWHwwFXuLDCo9CHQZcUHoIIOhcf9HZK5ggsN6QqGGUOVjU2ly5a5cdyszUuFVmOpXMqOYDeIpbqOZUUnGeTEstyzdeS3L1OSG8ImpmLYRE2xMWYG7diYtL1xCYxE2cCK9olGI+18kVosadpxAr+Y59L0zGpytnBMFu+gtiAm0TtKehHh0MV0EUlDA6CXqU1ElQAxHaXvAX3hcbcKdQIHW4oMuEEEHQf9HZ0lVBbCzijVosIqd1nmJEvXTmGNy6xHOuvPQNoM5lXuN3KqE8SncQetCdrpZLjUMtRwxLSw5EzrXaOhDV8H5lOUbR0jYgxXRFtL7TWIrUa2+Y7wU5YbLEO5ubxX2EYcekxZYw7sXtzH1DCBIMzLfRWcSr30VA/hXVYM+4PePiD5g2wQI29RDQuRgjN2QJWI9FgwegggcwZcf8AR2RpBazFLL3mCohVCsbm0pZeKlI5YlS0I5Y46XmYqG43RNy4s5hdxyRdsxWo8EdMSvyIQMwgcWGXnHoByS4y99nzA9lgccMQqPGKi5XMqYjqTqTFeiCVi1K0KmKNLmQZFDt0MEFdEXMZWOWYCKpxNswSh1MjUp1Ery/gysbz1rnqZjucQLYBDeO8t8E5Npeq3SJfN4GBHXQsphBlwYMGEXF/Z2RwKCYKItUYmDA+HMSmVzGzMsbQCpjlgqVfPQjiDZvMe6GZ2ELroKjCyJxAV8TFLay4TygSpfaaucSpYSPjNtEbEJoMW1hcHX4nYaHcIc0gDQRRt/iWOa3xMcGWRhogMCqjOjvLJzJzFxHdzcSZZdQ6K7xpEz/HMuYroGYnTaDepfxsPY5giwBqcYhikiZEcRzCWGKrpcuDmDLxF/Z2ITCsQbgyTiOTYsTywFi19CKblDiLb4jaaIlk4llS4qsN7lC4i1iK1KvBzKz5nAqILspLauGNQGkUzGkRjODQPKxBprLYfE3BfdjSU49xEA1iEDoaDbxHmkE0QWecRNqCtxFHKh2IFFRI94E2zNSiyqZtibjAbYziVydDzGCwF1NXK5ZW52Q2DtLIfeGiYH4xphJcUhRyEM4TRHomXBg9DhP1H0QxCDR4UzVYoPRiGCaMvcNRqMGXTLj7labjHDvpc3BRuKcpHYQlQ4LgdwYVqiDI7hFjQQw2853YHEMlGpbA2keIVmwjPdGBSYCmHBBYeY1+OgmVNmyYz1lHbtDTO5eI/no0ysw3MDDHRw4i17iUeYVeZWIHDKx5j0uo2RKuJ2gfmBiEB/oSgkBUzHM2zTcWc4I7u4pqELlrLYxRDTLlw6DhP0P0QjRg3VIq/EdDatl5jykumXxKJfMW5ioBU5IkehGWqO96lmXqHmIjcFNI7cbI1MQlcU/Ma4JZLVquFSeBeCJ2Nh83CtstLodyOomo2wgumrlN8DKCwYIHSkpjXc4RWluHoxsi2EPUqcyiGrSDElX8Ry3Ke08Sq7SpXfUolR1DDUcFwrKJaif+AjMwdoNKIGRzLGoRZQ3FqBdwYYYYsuDLi4i/X9ENzFjsXJRSAIucQXHMS9R3qczcwHmWTEcSuYy6JkiZiGc6gu4DW46XHdSvbCGPSJvoxEntMeJTHK40BQqzamwAr07zACh4LFEoyQEGeZSltFTKOiaYuI7FBaynI4Pd3mjz3iLxHceYNkM10qoURtrpdGIDcPMW4YZzmIX5mpxiVRdypr1B7zndzLmIVKSFBFFiiYMRMDiJDFmCuYrKLWOEcMOGCnodFxPr/RLhsjCOC0TbCrGjHMwuI7goRWNr4lRMx4qUvx0zHEtwxZ3ogpBczMa3CBVWwrFoCIcg/LKGOLcRGtbQ7eYjQrQRUl2nOo6CsvunaZPCnz07KLRlzEDnSDN3BpHUN46NVB7zmKTcvEckYR1G9JFY25lkuy5oqcxKDE4g4qG8EYecY5WUR9O0OgiMq2FY3CSPWTCkSOMRIaJnDOYdX1fo6ZRhT3fmJTd9LXcVdwZhGoMTmO5xHCqnMrDGpiKXBgMO8yviOGIy1tY9wCuCGt7io1Ct7QS7G+0aKCMpG3KWDkmhAXbu7Q2WrRO/ecBFht+gmOldxwRzk13evE1SMrNOpVMrNzxCJUdQ2BK3KxvHaXnLGZjrmOo4nPuf0m6bzKML81Ee8BdQ3N3OdsLO+pQdGxKUqBcsZQZjtjHfVbDfUCXHH+n6IRcvUyfkEWsRwYlmI1mACXBL1K8dAvURubgcdonUTFwRPlK7w4NwqpiXnEWIgC9CKjbKrtC7y4wTBmol5uE2PaNZBS/oQhjkDhgsbKdmXi5ZSu0QJWg3NeDA+RgUHkl2x8R/cuaO8vFy+ZfmOZ63MRheemH3B4jvVzAj5nmGqNQJ7j25grf4iEbSF8cwBgAAlHMVQOwWWP2MsqYi2JVR3KmQzIolnVDBUuKP9P0dMH6iVv8AdSzcpeJXeCmBVkrMRuYNRxcW2W7QavvHRLYoy3ibVgXNJWYtFEENwdug3EMKAFRWU5JiQinBN8LhqF3Fw4BXeYFvZ4ZmHZjHMU1c/dYSZkBPkZYbrecyqwsd6i3uLbiDBnM3ipefMvE/CIlpZCrlZuV37y2YYg6Y9/EKhlSa4xHFVLaMzJhklw8csG04i+KBwCcgqllriJYygjiOWOIc3MmCJb0XOjDoL9P0S5miNi1g/qGrmV6Es0iDTmDkjV5m8qOJtnuYNxMzIbgu8ykgvxKO8yxEzL2zxqVGUC67T0abUTxBZZ3FZWTJAs3kLxyQTzr8IIw0RHNxVjjmA7jBDWI95j8dptTVywjlwYnM3MjOWpqsS80yuJviiDYl1Ly8vMMtTBVs/KG/iVjEDOY41sirb/Sb2ZIc814hgGXfxxE8RH9Z+MpFSmIFqVlSpxQcxVBplj0vRXyl1HIEYv1/R0ZgfH1QsKlUDMX4iLlEpcFSuI43HLBLHMumDept9S8xVY68wWrJdtTGDGuGN3ucxF5+IIGEXBrpEiVhUeEae4zxuDUF67UO9wSLtT5lEEYmhR37QGBOXtENGY6zFx3ZiWVOHMvG53uG+nGtTFZjmiV2fE5LlBuYP+zZHjM0uCOZh13i7Vj7gVzHUbAfLMJ4MMDMPb4hWg4gjMoMEsHbpVa2BFxDUGRldQtJ4J4oheIwPr6JcWOFa5PuK4RxmOw7zBcoYlSmGpYCxItRygogiAUxw45msEs1UezUv06KlPEuCi4yYDAeZVaitfCV7rMuJpVZhXR8yorudkF+WEIKolEbMS7RYLUryzDnNwA7zCo1WNwcVL8PmLljLnErEQ7XArbLt4zMeZSMUXUpMvMYmv8AsG2Ds3UTduJzUHFUZjd4m9/EdbmAqCoslKdtfuICh5RTRPHYrkiKsojj9zdUsszmoGLiuWVBhqbIw3hPRJHEI+L6JcWIZ4Jb7EB2Aait3HtFo7wq4i4mLIsPa5UD8T0nMyVg51DK6gWL4it5m9VCyNxOF+ZerIlp2mNhlEsEabuJFpyTkSC9eyYUUuCuZmZkWwCS2Hgg6B8jFd5zmVTfDHmfEyrmXRW7jk1B5lXdOfcUd49TDDucWuJbDXb4gXzEOPuUurYEfcxv8QDbiWT4uHnUfNQMS9NQy1gL3GbnIcfMqO8tc1Kwhd1mU6lhLSB5oIOO0ygIKSaQYMC+hgmyfqPo6jT0lTD9fhGEyuY5jS0TUdS3ZqGcncwRF4hc7CNWvLM8wWZlYqZgcGo2xWXleiIyzFSiBe8RuuVfaL4TKVhzA1ZEtSB/qFlvBtYBGRy0SUpL4YBth6jgDcyrMSrO0VVbvFS8zaq7nE9wFMzHbEw0S8eYmKi/mDxDE15l0Uzxq447mb4j5wy9vRDBE4myPd7T9HzMZiLuFReoQmbXS2i1BEvcuzOKDEsv0msM5ZBiwy25/cdnRdDYIN31L0dugdolHMo4M944pUUrzGxlVTc+M94seSOablLitxlZxM5GVUpl2wu8XUoI0GJaMCwv8SibboDh7y3XrDG2Q1BVVYxmMCzg9EbaJZeV7y/mrPLCh8xZ8/7nP7mnvGg+ZkdpeTO4lx3qfh4lvmLY5gACaO89J9xcXLK8yvErMtWWGG/HqYeX/kNBgPiHIIhAWP8AcTXJ+YFArIBSCNo/0lIQhoMcxLZUEoQ2MMkUAnJFR9xxhlLZgixZSoT+7h/Aqwv9VGQYVFpxHJiK1W5bgwcXMmB3mcdoNYYpc+ouZVO1zG05l06lW+YmY7iZIFDFd10lEYKoYp3I/mr/AAQhthaPcik1G3I0lC12rHWa2cAlFVs4lfh2l4W8sfyfcw2tvtGX8RtLuP7mb2YhfPE4us+ZRZich/WNXQ3BLiM17SjzABwZmmXW+It+D3ANN/SCnn5I00X7iPLVeYMa/Uu9oj2bKnrMxoKAgsEwI9olMKSPLWFQgWy56Dh9nRtejfLx0Kf3vCMY4Q6wVGpqFr1LR4VB/Ex4R3i9RMQ3qXQm4NGdReYLFVpiKN1HsylVzF8kMjxMOzUTniYhVNbjLtbGHtMZYCAc2TCpvY48xBShQrSYSJCjjhlQFbn3ALm4cu0xFriDq881Lw1Kxspi4F4hkxBzuNMXO5bdMSi8Qcldpnf7gr6ZbiB+WOkApmksiEhaqCv1Kw1g1A2S83cTxNYlllP7gM19yszxREvmoyjGY1VHzmVaWK37xKw6Wu4IkqGXLFEtYC6WHQtjPeAjr5S8VdWMIwoH9nCMenRiGTbvyS0q5TKVyxoe4so3KbviKQG2PWDwxM5jvEfMVa1FMrKSmtLBq8S1vJLvMwTUW9GYg0C4zC1ZR6YR3ixzY7h89EmUrJLAAixvcto3vsIV5Lbjl8sDdbjhlDmZ8Smo5NzTGuEXL1B8wL4qAryrU5pwSq5TJu4sV+5lbPqeDMExmZvcKXzGrbqVZqABlm8PsjWSV8TDJ9xaO4zDjn8XG1/Uuz3QPiUVDmU6mWMMQQZc0RFz0MKQLehcr8wRGwRMdNR10jHqv6Tsj1DcEaf6DBJZhYqHeNGp33ipSEVtSw7zxLctFWxHdzdTMpAd45NTBhjk2wxc83Cly0MXD9zHZBmUctVXwzLNE12YqAWyikgJs0uzcRswIFXjGsxrN3fGIWLMXjUpprM5qql3HBK3KoyCfuNF+ZVUxUO2pfmbcmYGff7g8iOrJn5YKrnrcWC2p7ZWbSKafmXeKK3cW7DmPFmvEaB/2NnQxhmLNg5/mUETPo3CoJUuZe0lzbAXCEaulQAZY9LzMxW3M0idAUxQjTpf2PCPUUoctVUpRbGAue2IMmNSy8RwDMXC8MWKrEW85gRTEXuUMjFLUwzGZqW8+oF8QNwsfuyUFlWxgxGlVDVLdnlCK1JwlHeW3QpyH/INCort39xy/wDkscg3uDgDLNMERrX6lq3BzmKX/wCRwsAvdeYaWiPokMtXzqPc+O9RvbKYtIlK2HqbxeYXdxzp/wDINBe57fuNuLfiWG8fEtw7e8vxacRFYUeYqTOuzLOar4i0VGF2gJ49CMgFrKW3ywTKxTEzWxKjiO2FmXcQOYzB2jjODAojKlR3NIMuKf1PDoeqCvJUd3AJPTmEZdRUXc0+ZZkeYAEliZi4nJvMafxHhVeY0RbcBzFF7EsqyOvEM6go1ZMCPGoEG1ZlTI64O2LFSAXHYlZVVcmZaO6EVur4jWBX7jmi6vzKPP3G3FH4jjNJxBC6f3FeYBXmO3io274jXy8QtZezn5mzvCqMPmARH/rdx/uJSzHF4JbS7lUWN/M3d9+1xZKorWyNmtnuWu6fxuWDX7uLO/8AdRa9xYaNA2+IgiTnF/UK0HMDI1K0qLMeOlsrHAyL3KM9MSXcI9BOIp/U8I9TRmJNUFz2TIqCzVVMqcxKhtuiphvMaG45y3G1+IKI9iXVywiHG4jzmZumC8bgbhgu5SnMcm5YEHHMtzqBwxiyl9rCUb8GCv8A1Ay/8lMF1/uNYp/cbaAtf2pWBTfOI1WjDEUrd8VETUuxajhOvEvHB7TCrr8TFZ2ze7/DFpXyv+oUDipdJXMbVa7+Jdmv1cavB+o4N3LV/wBYxHGzPqXjdXBS17jQ5+cRU/8AUyizcYVg1mBdUMTFzlIM6jCixJbKg5gzVY2yiRixBgxYueowv7OxNkejWDDL2L/TT5WRMJzNu4xzcQT+40OZd7nJ8Tbhl23LIjhlZxqYwi5eegXqJV8ExV8w4aPW4SrGNtikaVDQ/mAZxTcsDFblnPzOGKO8pMP5m29cy2zdzHaq5qX2ZOYtY0c5nfatcSkM9sFT8fPMWrr7gbxZ6mdamK3XzKyox3qJShxqX3aOWptrftlcop6lgllPct738xz5eoDeu1aiL51uayP1Lw1XrtFj/wBuPQkVSgOWHhpb8u4nzCQmagQxEqPHRUVSs+eBl1zgiRCO6jHghB6Li1GXOfqPol8/geRBGsCR2lBY9RVi5ntqGWNDuUS7mYhHGY2mphHOOIDH3Cojd1BxOFblA8V0AwLz6iujfuYHoahrB5agJTXuNrOqigld/Ec25S0ys0q5gWw2p+KjQPEvBz8xXnP4lttr2iU448yms6l41z2jvt5jkx9ws4AfUUrFd+0sEf8Ac9FnxmJRXLvEoCVXzLxm/EujBZfaWm2/McEf+xKOPVRb1j5i1WItsI956z37wwuAWMGWYDEQHUJbBqUMzwRG5xHVIEDJnMYtQi49FnBGOX7fRM5bOhm/QLGY43DROYINwKWCziWrJLSwiUPzMpkYl1hcSsOJTUs1NdouKhl3Kp6ic5ilf6jBZFi6F6GEPO6xB1z6gNVR6mlY33jmrPqNDnEcKvUWy858yuQga1KEwWniZ770XE+e2YaWIepRRbXxLJZrWYWuT5xEMufRFvCFnfECN38LBsQurwVBF4/Nk5BV9xa3vyQy3rzSTt/pig6X3FL9eI2rKUd4KNvHcuYX5+JatZY9KaYufMKwUaJVK9d5MadJjFWc4OCK2XKiXmFq2B0HEZQkI16zGDp/Q/RHccMyIo5zhxMM2hZ7IlDzBsMxWQGRojTMbYuKN/mDMo5jqK7yrxUqsxBg0VfdKnEFL18wq7YhZujiXN4rRGaX9Ru6/UZo0sFNt+8fuNaXfLKFQJvUFF41q5dgNteRhRVqvHKAEmS91uLla32y7pv1UFuW/EWlMV84gfk1nUbxjntqO9eyoO7Caq5tatr0wytqsNTnNM61MNo3e9NQR2A+peVOPbOS1+RiVZ9S6DP71FU7xT4i+YvQGLVgvZOdQTKlOVgyygOst6iIlSc8EvvMrOYl8KEC2OqJxGV1lY0hLAS2by74/olWeGUfhMenSHDLQ5JjLJp6hRKDJmBThBi1vMRy16i+UQ4jqMvITnBLUETP+4VcWfiADL9yw/3KVlJKrPeNr49Qs3ipVFGt0y1YG/ZuBMF1lxHZgu95it5W94NC7+Bljlhe6l8gL8seNrxc5ZyeDMLOaPNSi0sw94N7u+5+4gUVhzqCI/8AsoGi18XKxyLrhlF5xUoidvMsBlj1MC2i/eYUc3mnMbwrPxFpxXjZLP8A4xau9ep9RZuBbEHIdQjA4iqTNvcZi6CrEgCPPBPJKRzHpuCMPMdyxZYky5jaE+SUcy2M2fF9EtJensmkU1h3Bd1MYMkHELq9MpaYHBKLevmNE0jpazOYZuViC+6OLzrtDZfEGHZfqEHzVFTL/MMDbwD67zRM7ZLgVrdPD6YkUPPDA9nnESuSr1UulF/DBbyZ9kdKl1uG5QrsMxQ7OWKrS7PMogvpjUusUfNksTHfvOMFfMBoNEy1GsUj5iQzu+5KRQtN41EUFV81CwbtZVVjfcimFnwxOb+7i3lz3I5oOfM+Li+vxHB6jmEUExYblKJQEsV4a8spJZHLLkOozwdKgcy1RLG4MSrYFscpjHoQNxsiEV0E1uZJZ8H0S5TCcMo2mDFZHMRalkGUx7jC2GmbFOIFbl2bIl1T+5QIbpdRo7ubczubO8aAqDSUzW+YK7mEm+7mfB4bmbaqd10fJh4TOMQD/RC/IyGOyBtDaE5uEiLwE9Rwui/bN6cwFh8dhiuTRfiCFAHyxUI2/NytBn1FLFV6iGL7Y8G2+KSC7qsxYLj8WRpDt4ZS0W+ScpQ33Ki93gIp7Oe5KJ2+NRyXw+YiZ37zEO0/eYv9uNUMuK95UFC1intCDEUh8yi1BFuUsftBoM8E883t9HKtgniBnoCMYR9vTaTLBUSTJMkD8P1LoTxJiHZLCOkR3DdzYSqhkpDWIKx4GtQrNG54b5ncNJyxXbiKU4jH9TtW45f+RSbLGjmKKaXi5Q2X5jvKIK3QMJqgMk9cN00kDDir6dRjw3uSk1l2SCNMObi25r2MVcCg1ZLOGl1jUrOHG8u5Tl3nnMrOGe9VCktY3WGy+8tsxfqpgtId8OpqzG4RKzdZ2MMu/wAxdLzzuXzmn0yti0hcWV3MxDGfuLXB+JePvMWXF6BEPIfEI1SkJYVy4lL0XMEck80xMpsuJc9Cow5jqs0RjpmXvlzFShCjlEI5n6f6jkqXjMaviWOZyEoWO7htZi5lUwSt5gnMyVqDio3sPeI1VfkllscaJ8wLc5mdo1ePzEQ7ohVwLdfkZmnht48waRpJ3JdU9vnMEquUX6DxDNpVsBUSIaiiBylgDteSBbYfpJjQ/uXVVaHmFO7d8Q/6YJeavHKM0bTvip9MOIhRmv1G6RntXE5D9i4oPH7lrtt7y2wQ42lxpWvGyL2LHIsPxF3rrfQigrAwcTiVhHUDmeDDotYBtvqFZj9JLxc36JiBxGMdMyXzEi0TGzPFiKuekn9u0GZdwreZiXcYkqtI6E2MCn2YiWHJLvUvPaFTfM12nyKlWyliHqUXWIiF5ueUTx7gzUXJolBDsJgHBAu1rcIhV1wT5X1csmjO6XbtMVbde5duzcq1/GSFBVm8OS5k4HiKW6vPrMprFdtQKwtHpI5CY83cbTTjUBFwQoDzbQxHdTPEo5/ZMXdnmBo1deaalDfgWVEqrx7l4ptjHH/2XL67QNsuaoQlSslijBqBC0M27myY4Ycx2iKVblBHcumCoL5GM/WgLeZhmJK+YMw7nn/gQNjEFBL1xqIrsm+CqxlymFqLsg4rmJvOSXO4pQGOYwyZx3guKxXMtUBCmisnmeDuDSse5Qs2d6lKdywWs7l3lKu3cG415IUOCJwfELmh9zaBE7cRA2VfeP8ATmGGMB+5VjF8ag2uce455N73KW7WvFRXwvxGrbyDuy8qx8jURE12yTKZOd4y3Nl/s5jluy/mXWBd8D/2NVp7w8r95SLh8/qXjz6j/SXHq0FxxavMWARFRzHME00Qitb1OgjLERWwjiLiLoFgCiK2+Y9MPRHbE1G0wKG7uPip2EYCPRb4l3HFE3cV4hqECG5UhsqbQbnG1ZgnGWMrJx3jYu/xG7td/Eewx7P4ROLiUtVUBdJZ73LsBrsVF9lT4sRqjt2gTy9xlcP4gDjmuYsCrs7sTfNb3Kp/5FnLxkqctbfMbrOzgqYd79TkUH5JY2Gq8y8YPyEMFgA90RWnNOt7l3e/wQQZsRu8k0UQhSsK9jliK3XfcXNL83HepvsS8Rb/AIa1EwsXmBhQaJalg1CK8s4DoUxVRGzmAJc/JHcqXRgDg6L03QenbxL+JY6j4wO0tgh12+iDcMNqJS4mcYGUsyThYbUQoo5l8kTdS7MblhuC1e77RCgD8m47LwZ1KtuLkma3EKCmzxLW4+GXUaWdwL58y+5VQKXWonZupQVTG5m3GPHeXeSte8RwVT8ykp1wERnOA8kQhyXzC3h7/wDyFGex21KVijHLSSzzjwk2XTf7SxwVR5qY/wCCI0ptq8ai4oo+Uhd2OTOEYuNY71uKX29PS5cv+LErVgPGWWUARiDKwTeJzsrx0K5jYs2y7YF4lY1Kq2MsbmS0l1O7UXpcNkYbRtLeJ6we0fGU7Ska7fRHDNJZYi3riWpEBl1ucEJr2QYPmUJmFrBffiPCe45vX/ZkeR6jwkcpVfcVba+qqFph3xKbUo1cW7or5lcL+tQUUJBRSZ+GKOPGoiuW/wAzQAB9otiX7MROvi6ig075bY2NnHZGOOD4nHY32qCc2a4ZVA1b6GZzY/FXF4FFbThFRnDVpqVSvxiplBeHEdmHzX/JReMa4ljzg4uLF/lQRjsaIRKljLKWDU52V66pSVctaneNKSMIqyy6i9pdsuBfmPR3DqZFJWoMR2lO0oL+sOg7iwEi04QumZl6smNe0FkCDcEKcIN4PxARhGLShv3Ev48TbfrMu33iJ4v8TN02jsgQi9q7Smhl/E7jHsiyFzZzfioIHDHBqaBopghWLr3KBW67GI0KIPG5VC8826/9gqkM+hl84L8JNBOfO4KB0ccOZqx70uWKthisMLt2+kY0BZQ9/wBoqWiuMuYq5Ue1Ru9FcYl5xj5ix/lTGNyqiFRcZgqiOI3CNWAlZRL4xXLUq1w+0ARUSriEIVZlviXLxF6bZZaU6A6jD0f7jsmDHJ0ZS2xLUriLCyiqkpzyS4DTKckrwyjm487nA81knYN/MBM3XGo6FLZxcbePJEVPMHBaUrMVAlnzMPeU4hTbxiDZaXzqC8fNlRzy+LtOXaazW5dAO961MrL9ZqHh84z5YYlHzCZVyPA7j8HOSWbqjA04xrKVBWLNZNUTO6fEA17bJd2t+yL4L+ovmX5i5/hcuURblzS8rK4O0dACrxK4MzXaVldcpJewTKahGCIXcsik4TLAj94jtfMY6m0FGMvpcvrUH9nZ0VkxlywjdsxtEsIZg9sIJ3eXEsiOXNwUqr1xiOd5/wBRvBquY3mte44ujjtMXh/cBCZNBK5D1epgDw5ribgoxf3BQ4+Khpw334ljTw8Uwt0ZzCmdeM1HsF+f7iUq3K8VuWKlGt5l8hXvWBHLkizAVxWyUoV9i7gL3b7m46u/1VzQzjDmeRXsjtxi+PMuL/B6LU3KlCMrEpRK6CCDF6IIKJnjaUS9qCU8EARwTSpUqEaJXmpnHY6czSHJLojB1Fy5cGL+zshHT03MyW1EMlbIwiMPqIvbrCMWpyRKpj05/MaM8y0s+d1LsL+Jw7ovKnNRAsDd/ENANm9kQBoMdzU0VTJ+I4ovPi43UVjuReR/EXRTt8DBzk24suNL5vs/qXy3b4GKKYBPJUELGDUIqC/Al47xCs/sSFm1nsO5QXbg7bYrgWmhE4W9lPEusV+SI7l+ouf+S/4sYuZcDm1VELq0AQoIogiXRViozLdQsymEV0LHXQIbg1aXLuxYdGxGXrz+MP6Ds6GGO4dRgUio8MVkdEtElfumRiJfuYMzPGqUmzBAK+xzKHPxcSNXHDk+yKqrzykNlmmsZ3LCk2Ha43Q0HsqO5pXfiFAB2zZdzKx3u7rMFBd5vFRCKgN0rHyO5CAp1+f7qKQVTeMpTAqqEpeew3+ZsrDWO78RxhR9bfmZK2nwYi1oDzDQGhXmIObiOPqL3l/wuLFl9XKbqa/LCqghns8Eql8u4tE4IFsohDQRYrelZgQIeZ6klxIziOYGui5dJ/Gsn+w7JcZeIcxlEl2hkhgjxMyDcVJ7RBSBp6FjKtE83uKpuycKM84nF/7no36gGtpiWsdnZhaOH6i4q7vPCRT8Y1uAUb+P+purbwSo8Ud7Jaa1XDdQu2PeJW+yeUzDyvndwA5/TcV5oO9YxHhdmrGNmnfLAVRWdZpuK1XP5jjx8R9xb6rFjFy+lRJ62h7CwtgjKZXRsZuGJYyrc9AKmuhei56cwz0mO5ZZDmOobY9E5dB/FAj+k7Oq4LjGLcFiXRoY7UzuoCq5mD7Mqsxp9wQNQ/8ABOzOt4iac/iZG8LwwUS29FTJSlN4ncuOMRNmc+ITxkjKh481Mqq+NkbTdfiWGb9B1L13+GUZ0exlP6zJobv1DmzHpmCy6rzHF3r1cdGvqNOf3HOS16iy+OixYsXrUCYrm3PYYZ69v8h6dkOoFsIqcTiO4xm2cdDM0O7siVVhFRNdAv4LqMDH+j6Jc5i1Lshl5mRLUNmZZBo5hYxBBDJ5nDHLzHJH3mC8p+altl1fEUe/xmXGmvUBq7X6uBgJWu0spV12pI8PntDB3+dRaVn5LlVnv4YK+cYzCtVfYqWHD1kgmr95gKtE8pKY05BaQnBYO7HBVGPG5spCvMXi8R630XrUqBMElvA5WETUFHPe6D1Ylwp03OIxxHoIsDMMorL192LDooVGGBE6EuXFhqP9H0dLzFg1DZMIUFiC374ipO8doyx2PMeI9kEvPxEZ3EJr3MnCJEsXjwzaqt8lzRdZx2ihkpW4pNOfDNkcvq6hTVUc7qGSjjyk1ntxUXjjvFPPPqOP9kSHOcb3xKvFrxq6lgDd4sqDlS2s7ie2HOtwCzAu8pLOVrzFviL0Yx61KgRgAqtAQVhdp4cEXEXoxlQMyoHUkcyptFqDcFyploOSPIR302gK6CSGWDoksk/qfojFzLizIgzEjKqlAD3CygqHuYCKwzuA99ReY9v4lhzfEKXVxKUrJmr1Ozp9QCKmAzAAwUcTBte7dyqtWfUVcGMd4K0THq5oW/dXmOfjW7hnIB5gpdNdssKxujmxqCh+7inASnWeYsFleMEYf/Ki3av7ij1XrUrqEY7iCWY/8IDKgIosWpc4lQNyoYI1GLquLbBDTN5WH5lzOZxBQcupk7h5zLDz6HylO89oeU9oeUv+P6Ipz0L6MpQPSMtRSckVq6hsTAKl18TDcRf1H8PqNi5i4x/WYBsz+IWGrY8zHueLqLi1vsYai1R+OLjbK/uJkDMOJVHMUcF+dMd5K86jzxnReoA0s3eUBklFYylxxQGq8VEFg3nCo8XjvRCB3YRXK6L1qV0qVFWDAcrA+Nyra3MCLmMZjqTiOosWLF6iHmDMyTcNSxMI6mE2Np7TyTyw8p7R8o+U9pXvPae0tydvojqLmbRa6FguLDMnMP31LrvLLIpUd6iClXHiZ636mbgjN8xPNeZWMVfeVRRWc53KLS/ctk3mO3/yC2rrnUGha141DFb9wFLSzvUMf6zUHBa/iAKsK7pUQ4L2atLBkusZBm9rk4qNW/1F/KpUepGvav5NQUYAlzoysxIE46OIosyjHUqViUQIKg2HaeyekjKaIoXb0CinTfv0sqlu8FPaX5O30RcRcxZixYMESYHEVWSwj5gJDFytNzDuOOcRBzAFGn4hweJVb/E1sxxFaFcxVgfwwE1VFhnGdsxPiPrPgAl4wfqK0q3ymBrfcjTSP4YVzVnqA0i671EPId6Yd4ofVRGltb3zFeY/xOtfwwRcJy6/UwUS5c30emZcW4oyokTMCMBAqcz36Yqi5hqKGbyxZcGD0W9CoqHX/pfqYHQZJmo3EuJ0C2nlAR37YYDEWtQq8zgGYQ5dyB2+eYl2OOM6+IqG2t3UUXG97uJLsE6Hh28zhIuRDctXITYwhKmCNDLObf3Koo0uzT6gOGU1sYHNFM6qW1lcZKSLT4tJdiLzFz/Gv5mpdV+uYIlUEY6j05nFw1GMY6jKlZ6ahlgnMFsoJlkcw1PEVUep0uXGPQYs+r9dAzMmONStSqibiuh2H7k8NQCRmFmu+4lNQAN7i+yYF3raRKidm40ZxVOYByj3YrM5naAzalubXT7limBI8r5hzDvEp6MeJ3AOatuKmO3hqLGQD1Vxlub8jFnP+J6DY3yhmsYy5dQnENTz0Y+ZXRZc3BCOoc2zwQjtdAZ5GKntL/AErpUY76BExD+n6m45sKzJj0s2BMsBS5g0zxFgKQMyrRWrJY1zxMrk+JatQKzt7VuUaXj8xu8w1V7mAEPxDSu0XICnu+Y8fkoHLCrXldibGLm8Dvd6hcNvfzLqkW1wX/2U3vPbcV8687izH/KNOM+MFEWZc5jmahcS+jicRcxixYGBiB0EhdgJbZzGEpJuDGVAgSpUroYQjqH9P10AQqVHUqABDZcVcy4ZkJTo5M7l4zdQy1FVqvUuyrSA2hc/tsooOYg4/UMlM8ZgQ0XaJ7Hi9y5ynvEV1ljcqipXyXKAKoOzVy1sLb0YZp2fVRRel/48jyI+WEHQB+pojHUJqXNsToxjuLiLDcDErXQCpmStF7xMAdCY0+UjHoQjHqehqM+j9QqXDCELxGapIi47K8w5TQzMlT3glAU94XEwbDtARsxK7SwMcQWKC5zrcFjG+1kADNvzcQhYZ+JtdmyHjgfm4vfBpI6UGfXMF9PcVHtxkmKkDHdiz/Gv8NmF2nxKg8RIkScTmBDHV3FLm1SqgWwMdAxFRcqWUvZFfQQGjjBGWMoGBlIpFIsehGU/D9TBA1KStbmkbQHMURivaK2JaXJ2gxAyYNjepWKgcjFS8kG+7LaoZgW49QlKUd6lMhROSCqbLe9XDY7ZxBxTlxxqAXVjvMI7rnlLjqsg6rJFzZrfDNZw5xeJZtPzHfSs/wCNlAsAvlgqMcxmUKRwQ5WXfTvGbZXMLThLHxAmpSTC376Qc9BcaEYqK1XNNz2h5w84eU9uj36xBFIf4fqN1G7cHBvMFhlLNDIind6npDG1uPBGvCU1V/E4U4ItOJlOVJf74io+xu4ZKxtshk1Z86ijd4xyTDBr03UsB/K8RqN783FbsPVkFQXJdbl3d971PuXH/M5ym5dtHTjAlSpxKiYJVRKGU9GGVKlm4FR1KzcrGNZeWYIdLAtC6FuoSLv/AC+eUOh+t+oUVOaCoKDBQyhDREBiasoXqWKFQRYHKxdF3KaayQsL2i4By/UR1cRbDZqCAty97xMGnS+8GDFHfJDv+MjmNLBr5S4hyKYuqWUOGq8J8RVOf3LFpwXlrITZDXEucbnrqf4TyxH5YHVEPwdDK610dxI4CIrDOVULMIqo0FysmNzFk7aiuDpQjix7ZUqVKZmCy0t/Lz5y/wCCUMLEAxLcRrHsilEAIYY4Ey0waL46U8EpWZlTAbqwuGw9TLgXnggsNXMsYuJY08yhiwfxcCzk9quN6P7qUrV+szzg9Rzxn1Bw8JHPuO8a/ncuX/NHjK93H7mMXVldN9HccvQmkCVGMMsJbYReYqFm1nEWsyvtFHx0qVKlQOh6hhhURlpOGXFsEmzEuPcRlhDrPBhfokNL3esau8w0vMGtNzSz9RS86PmKU2Huohgtealrzj00w5B/Fxc7/eIhWq7Nag00P5YUroTiy46KVW87jj+F/wCVKq2PB/6ypAgGcROvMGD3gZ6kMHQyzNKF4iUs7IqBDorVDsRHaWV/GoRJUqJEldBgRapaDVxhhLGWG4mRw1gv2gwlKRyTKPE1jmc2OJYtMy0bsa5iiXR54iYM/wDkcwX/AImmzZ51Ez/tKiXBdGi7gFmMecXHuv73FVdYeQiR3T71MGfX8bx19fxSmnoN1nPy1AUoD8EWu4pueWF5dsq4kcTjodbA6K5imZlmHRWz4iHSnnkejrr0XLly+tx61PpfUulRUxYnlhApkjaMGpYOMRQBR/uOfTMRcbgtq4ZMCcJhYl8Z78Tk58xcwrzn8zhbfbnEXnv8RDQWnl3HD3fiIK5weY2OqfUXzGeJXcXeoFI7H/Hlc9AAWIvgYy1MqQwipllZ6q7jCZl9FmSoyxbKCVEsbiyhMG2+tlcP8ueghkkk/wAK+p3j/R9TFEphyM2UwVLqFIOYG4WyMIWuXiKGDfuCleI7vF3xMuF4/EXWNcxCkDMVTXmXjX+7ltOavtcu37a1P1BjoxLZ5lnaX1CVKzKlSr6W1XH8NzV4fxMbWBYGnMaRowx1hA2RxBixpMkYVF6B3UWMqpBCOCCVGftK+f4ckk6z3nvPee09odC2QIGWX2gpgzMElsMoQIKWUOu2NuCDGeiF3Uuv9wGtTu12l4KLieSFZyxFx+MxQKMf6nY4j410rbL3mMetdKnxA68Vx/EVmhn8jCG5VBwe3v0GWTDCVNptBzKiJBWLOI6lJFbKi5l0nRQqfiOely2X/AZfwFv43kwYhzBF7fQFOmjMWpYyQAe5Fp6LSou2BA0IkaqjiZu6vxLVwNzJUnvOZmis5xzGjz+ot7z3l7xNR31elfxz0v8Aki6n8YwgcgK9xemkZawt0O6PM0jWMCVE4mEW06Oo7Gbbh0y9f5h3/CpX8H+Ny2XHnP/+AAMA/9k=";
  const isLoggedIn = !!currentUser;

  const onAuditionScored = (score) => {
    setStats(prev => {
      const newStats = { ...prev, auditions: prev.auditions + 1, lastScore: score };
      setTalentPool(pool => pool.map(t => t.username === currentUser?.username ? { ...t, stats: newStats } : t));
      return newStats;
    });
    // Log to weekly Hall of Fame ledger
    setWeeklyScores(prev => [...prev, { username: currentUser?.username, score, timestamp: new Date().toISOString() }]);
  };
  const onDojoCompleted = (xp) => setStats(prev => ({ ...prev, dojoXp: prev.dojoXp + xp, dojoStreak: prev.dojoStreak + 1 }));
  const onProfileBuilt = (form, aiSkills) => {
    setStats(prev => ({ ...prev, profileBuilt: true }));
    setProfileData({ form, aiSkills });
    // Add/update this actor in the talent pool
    setTalentPool(prev => {
      const existing = prev.findIndex(t => t.username === currentUser?.username);
      const entry = { username: currentUser?.username, form, aiSkills, stats: { ...stats, profileBuilt: true }, joinedDate: new Date().toLocaleDateString() };
      if (existing >= 0) { const updated = [...prev]; updated[existing] = entry; return updated; }
      return [...prev, entry];
    });
  };

  const openSignup = () => { setShowSignup(true); setAuthMode("signup"); setAuthForm({ email: "", username: "", password: "", confirmPassword: "", role: "actor" }); setAuthErrors({}); };
  const openLogin = () => { setShowSignup(true); setAuthMode("login"); setAuthForm({ email: "", username: "", password: "", confirmPassword: "", role: "actor" }); setAuthErrors({}); };

  const handleLogout = () => { setCurrentUser(null); setPage(PAGES.LANDING); setStats({ auditions: 0, lastScore: null, dojoXp: 0, dojoStreak: 0, profileBuilt: false }); setProfileData(null); };

  const updateField = (field, val) => { setAuthForm(prev => ({ ...prev, [field]: val })); setAuthErrors(prev => ({ ...prev, [field]: "" })); };

  const validateSignup = () => {
    const errs = {};
    if (!authForm.email || !authForm.email.includes("@") || !authForm.email.includes(".")) errs.email = "Enter a valid email address";
    if (!authForm.username || authForm.username.length < 3) errs.username = "Username must be at least 3 characters";
    if (/[^a-zA-Z0-9_]/.test(authForm.username)) errs.username = "Letters, numbers, and underscores only";
    if (!authForm.password || authForm.password.length < 6) errs.password = "Password must be at least 6 characters";
    if (authForm.password !== authForm.confirmPassword) errs.confirmPassword = "Passwords don't match";
    setAuthErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateLogin = () => {
    const errs = {};
    if (!authForm.username) errs.username = "Enter your username or email";
    if (!authForm.password) errs.password = "Enter your password";
    setAuthErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSignupSubmit = () => {
    if (!validateSignup()) return;
    setAuthMode("confirm");
  };

  const handleLoginSubmit = () => {
    if (!validateLogin()) return;
    // In production: validate credentials against database
    // For demo: accept any valid-looking login
    setCurrentUser({ username: authForm.username, email: authForm.username.includes("@") ? authForm.username : authForm.username + "@apex", role: authForm.role || "actor" });
    setShowSignup(false);
    setPage(PAGES.DASHBOARD);
  };

  const handleConfirmTrial = () => {
    setAuthMode("done");
    setCurrentUser({ username: authForm.username, email: authForm.email, role: authForm.role || "actor" });
    if (isFounderPricing) setFounderCount(prev => prev + 1);
    setTimeout(() => { setShowSignup(false); setPage(PAGES.DASHBOARD); }, 1800);
  };

  const handleGoogleAuth = () => {
    // In production: triggers Google OAuth popup via Firebase/Bubble
    // For demo: simulate getting Google profile data
    const mockGoogleEmail = "user@gmail.com";
    updateField("email", mockGoogleEmail);
    setAuthMode("google_username");
  };

  const handleGoogleUsernameSubmit = () => {
    if (!authForm.username || authForm.username.length < 3) {
      setAuthErrors({ username: "Username must be at least 3 characters" });
      return;
    }
    if (/[^a-zA-Z0-9_]/.test(authForm.username)) {
      setAuthErrors({ username: "Letters, numbers, and underscores only" });
      return;
    }
    setAuthErrors({});
    setAuthMode("confirm");
  };

  const signupModalJSX = showSignup ? (
    <div onClick={() => setShowSignup(false)} style={{
      position: "fixed", inset: 0, zIndex: 999, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)",
      display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: "rgba(18,18,32,0.85)", backdropFilter: "blur(40px)", WebkitBackdropFilter: "blur(40px)",
        borderRadius: 24, border: `1px solid ${BRAND.border}`,
        padding: "44px 40px", maxWidth: 440, width: "100%", position: "relative",
        boxShadow: `0 32px 100px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05)`,
      }}>
        <button onClick={() => setShowSignup(false)} style={{
          position: "absolute", top: 16, right: 16, background: "transparent", border: "none",
          color: BRAND.textDim, fontSize: 20, cursor: "pointer", lineHeight: 1,
        }}>✕</button>

        {authMode === "signup" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ width: 52, height: 52, borderRadius: 14, background: BRAND.gradient, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 900, color: "#fff", fontFamily: "'Outfit', sans-serif", margin: "0 auto 16px" }}>A</div>
              <h2 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Create Your Account</h2>
              <p style={{ margin: 0, fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>Start your 3-day free trial. Full access to all AI tools.</p>
            </div>
            <button onClick={handleGoogleAuth} style={{
              width: "100%", padding: "14px 16px", borderRadius: 12, border: `1px solid ${BRAND.border}`,
              background: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 12,
              fontSize: 15, fontWeight: 600, color: "#333", fontFamily: "'Outfit', sans-serif", marginBottom: 20, transition: "all 0.2s",
            }}
              onMouseEnter={e => e.currentTarget.style.background = "#f5f5f5"}
              onMouseLeave={e => e.currentTarget.style.background = "#fff"}
            >
              <svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
              Continue with Google
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
              <div style={{ flex: 1, height: 1, background: BRAND.border }} />
              <span style={{ fontSize: 12, color: BRAND.textDim, fontFamily: "'Outfit', sans-serif" }}>or sign up with email</span>
              <div style={{ flex: 1, height: 1, background: BRAND.border }} />
            </div>
            <AuthInput label="EMAIL ADDRESS" type="email" value={authForm.email} onChange={e => updateField("email", e.target.value)} placeholder="you@example.com" error={authErrors.email} autoFocus />
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: BRAND.textDim, letterSpacing: 1, marginBottom: 8, fontFamily: "'Outfit', sans-serif" }}>I AM A...</label>
              <div style={{ display: "flex", gap: 8 }}>
                {[{ val: "actor", icon: "🎭", label: "Actor / Talent" }, { val: "director", icon: "🎬", label: "Casting Professional" }].map(opt => (
                  <button key={opt.val} onClick={() => updateField("role", opt.val)} style={{
                    flex: 1, padding: "14px 12px", borderRadius: 12, cursor: "pointer",
                    background: authForm.role === opt.val ? (opt.val === "actor" ? BRAND.primary + "15" : BRAND.accent + "15") : BRAND.surface,
                    border: `1px solid ${authForm.role === opt.val ? (opt.val === "actor" ? BRAND.primary + "60" : BRAND.accent + "60") : BRAND.border}`,
                    color: authForm.role === opt.val ? BRAND.text : BRAND.textMuted,
                    fontSize: 14, fontWeight: 600, fontFamily: "'Outfit', sans-serif", transition: "all 0.2s",
                    display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                  }}>
                    <span style={{ fontSize: 18 }}>{opt.icon}</span> {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <AuthInput label="USERNAME" value={authForm.username} onChange={e => updateField("username", e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))} placeholder="your_username" error={authErrors.username} />
            <div style={{ fontSize: 11, color: BRAND.textDim, marginTop: -12, marginBottom: 16 }}>This will be your public URL: apexperform.com/{authForm.username || "username"}</div>
            <AuthInput label="PASSWORD" type="password" value={authForm.password} onChange={e => updateField("password", e.target.value)} placeholder="Min 6 characters" error={authErrors.password} />
            <AuthInput label="CONFIRM PASSWORD" type="password" value={authForm.confirmPassword} onChange={e => updateField("confirmPassword", e.target.value)} placeholder="Re-enter password" error={authErrors.confirmPassword} />
            <GlowButton onClick={handleSignupSubmit} style={{ width: "100%", textAlign: "center" }}>Continue →</GlowButton>
            <div style={{ textAlign: "center", marginTop: 20 }}>
              <span style={{ fontSize: 13, color: BRAND.textMuted }}>Already have an account? </span>
              <button onClick={() => { setAuthMode("login"); setAuthErrors({}); }} style={{ background: "none", border: "none", color: BRAND.primary, fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "'Outfit', sans-serif" }}>Log in</button>
            </div>
          </>
        )}

        {authMode === "login" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ width: 52, height: 52, borderRadius: 14, background: BRAND.gradient, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 900, color: "#fff", fontFamily: "'Outfit', sans-serif", margin: "0 auto 16px" }}>A</div>
              <h2 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Welcome Back</h2>
              <p style={{ margin: 0, fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>Log in to your APEX PERFORM account.</p>
            </div>
            <button onClick={() => {
              // In production: Google OAuth login
              // For demo: simulate returning user
              setCurrentUser({ username: "google_user", email: "user@gmail.com", role: "actor" });
              setShowSignup(false);
              setPage(PAGES.DASHBOARD);
            }} style={{
              width: "100%", padding: "14px 16px", borderRadius: 12, border: `1px solid ${BRAND.border}`,
              background: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 12,
              fontSize: 15, fontWeight: 600, color: "#333", fontFamily: "'Outfit', sans-serif", marginBottom: 20, transition: "all 0.2s",
            }}
              onMouseEnter={e => e.currentTarget.style.background = "#f5f5f5"}
              onMouseLeave={e => e.currentTarget.style.background = "#fff"}
            >
              <svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
              Continue with Google
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
              <div style={{ flex: 1, height: 1, background: BRAND.border }} />
              <span style={{ fontSize: 12, color: BRAND.textDim, fontFamily: "'Outfit', sans-serif" }}>or log in with email</span>
              <div style={{ flex: 1, height: 1, background: BRAND.border }} />
            </div>
            <AuthInput label="USERNAME OR EMAIL" value={authForm.username} onChange={e => updateField("username", e.target.value)} placeholder="your_username or email" error={authErrors.username} autoFocus />
            <AuthInput label="PASSWORD" type="password" value={authForm.password} onChange={e => updateField("password", e.target.value)} placeholder="Your password" error={authErrors.password} />
            <GlowButton onClick={handleLoginSubmit} style={{ width: "100%", textAlign: "center" }}>Log In →</GlowButton>
            <div style={{ textAlign: "center", marginTop: 20 }}>
              <span style={{ fontSize: 13, color: BRAND.textMuted }}>Don't have an account? </span>
              <button onClick={() => { setAuthMode("signup"); setAuthErrors({}); }} style={{ background: "none", border: "none", color: BRAND.primary, fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "'Outfit', sans-serif" }}>Sign up free</button>
            </div>
          </>
        )}

        {authMode === "google_username" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ width: 52, height: 52, borderRadius: 14, background: BRAND.gradient, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 900, color: "#fff", fontFamily: "'Outfit', sans-serif", margin: "0 auto 16px" }}>A</div>
              <h2 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Choose Your Username</h2>
              <p style={{ margin: 0, fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>
                Signed in as <span style={{ color: BRAND.accent, fontWeight: 600 }}>{authForm.email}</span>
              </p>
            </div>
            <div style={{
              padding: "12px 16px", borderRadius: 10, background: BRAND.accent + "10",
              border: `1px solid ${BRAND.accent}30`, marginBottom: 20, display: "flex", alignItems: "center", gap: 10,
            }}>
              <span style={{ fontSize: 20 }}>✓</span>
              <span style={{ fontSize: 13, color: BRAND.accent }}>Google account verified</span>
            </div>
            <AuthInput label="CHOOSE A USERNAME" value={authForm.username} onChange={e => updateField("username", e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))} placeholder="your_username" error={authErrors.username} autoFocus />
            <div style={{ fontSize: 11, color: BRAND.textDim, marginTop: -12, marginBottom: 16 }}>This will be your public URL: apexperform.com/{authForm.username || "username"}</div>
            <GlowButton onClick={handleGoogleUsernameSubmit} style={{ width: "100%", textAlign: "center" }}>Continue to Trial →</GlowButton>
          </>
        )}

        {authMode === "confirm" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>💳</div>
              <h2 style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 800, color: BRAND.text, fontFamily: "'Outfit', sans-serif" }}>Confirm Your Trial</h2>
              <p style={{ margin: 0, fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>Review before starting.</p>
            </div>
            <div style={{ background: BRAND.surface, borderRadius: 14, border: `1px solid ${BRAND.border}`, padding: "20px", marginBottom: 20 }}>
              {[
                ["Account", authForm.email],
                ["Username", `@${authForm.username}`],
                ["Plan", isFounderPricing ? "APEX Founder" : "APEX Standard"],
                ["Today", "$0.00", true],
                ["After 3 days", currentPriceNum],
              ].map(([label, val, isAccent], i, arr) => (
                <div key={label} style={{ display: "flex", justifyContent: "space-between", marginBottom: i < arr.length - 1 ? 12 : 0, paddingBottom: i < arr.length - 1 ? 12 : 0, borderBottom: i < arr.length - 1 ? `1px solid ${BRAND.border}` : "none" }}>
                  <span style={{ fontSize: 13, color: BRAND.textMuted }}>{label}</span>
                  <span style={{ fontSize: 13, color: isAccent ? BRAND.accent : BRAND.text, fontWeight: isAccent ? 700 : 600 }}>{val}</span>
                </div>
              ))}
            </div>
            <div style={{
              padding: "12px 16px", borderRadius: 10, background: BRAND.gold + "10",
              border: `1px solid ${BRAND.gold}30`, marginBottom: 20,
            }}>
              <span style={{ fontSize: 12, color: BRAND.gold, lineHeight: 1.6 }}>
                ⚠️ You will be charged <strong>{currentPriceNum}</strong> starting 3 days from today unless you cancel. Cancel anytime in Settings.{isFounderPricing && <><br/><span style={{ color: BRAND.accent }}>🔒 Founder's Price — locked in forever as long as your subscription stays active.</span></>}
              </span>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <GlowButton variant="ghost" onClick={() => setAuthMode("signup")} style={{ flex: 1, textAlign: "center" }}>← Back</GlowButton>
              <GlowButton onClick={handleConfirmTrial} style={{ flex: 2, textAlign: "center" }}>Start Free Trial →</GlowButton>
            </div>
          </>
        )}

        {authMode === "done" && (
          <div style={{ textAlign: "center", padding: "20px 0" }}>
            <div style={{ fontSize: 56, marginBottom: 16 }}>🎉</div>
            <h2 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: BRAND.accent, fontFamily: "'Outfit', sans-serif" }}>You're In, @{authForm.username}!</h2>
            <p style={{ margin: 0, fontSize: 14, color: BRAND.textMuted, lineHeight: 1.6 }}>
              Your 3-day free trial is active. Redirecting to your dashboard...
            </p>
          </div>
        )}
      </div>
    </div>
  ) : null;

  return (
    <div style={{ background: BRAND.bg, minHeight: "100vh", color: BRAND.text, fontFamily: "'Outfit', sans-serif", position: "relative" }}>
      <div style={{ position: "fixed", inset: 0, background: BRAND.meshGradient, pointerEvents: "none", zIndex: 0 }} />
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html, body, #root { background: ${BRAND.bg} !important; color: ${BRAND.text}; margin: 0; padding: 0; min-height: 100vh; font-family: 'Outfit', sans-serif; }
        ::selection { background: ${BRAND.primary}; color: #fff; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.15); }
        input:focus, textarea:focus { border-color: ${BRAND.primary} !important; outline: none; box-shadow: 0 0 0 3px ${BRAND.primaryGlow}; }
        @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
        @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-8px); } }
        @keyframes glow-pulse { 0%, 100% { opacity: 0.6; } 50% { opacity: 1; } }
        @keyframes gradient-shift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        @keyframes fade-up { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes pulse { 0%, 100% { transform: scale(1); opacity: 0.8; } 50% { transform: scale(1.05); opacity: 1; } }
        .noise-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 9999; opacity: 0.025; background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E"); }
      `}</style>
      <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />
      <div className="noise-overlay" />
      {signupModalJSX}
      <div id="main-scroll" style={{ height: "100vh", overflowY: "auto", overflowX: "hidden", position: "relative", zIndex: 1 }}>
        <NavBar page={page} setPage={setPage} isLoggedIn={isLoggedIn} openSignup={openSignup} openLogin={openLogin} onLogout={handleLogout} username={currentUser?.username} role={currentUser?.role} />
        {page === PAGES.LANDING && <LandingPage setPage={setPage} openSignup={openSignup} founderSlotsLeft={founderSlotsLeft} isFounderPricing={isFounderPricing} currentPrice={currentPrice} performerOfTheWeek={performerOfTheWeek} />}
        {page === PAGES.DASHBOARD && currentUser?.role === "director" && <DirectorDashboard setPage={setPage} username={currentUser?.username} talentPool={talentPool} />}
        {page === PAGES.DASHBOARD && currentUser?.role !== "director" && <DashboardPage setPage={setPage} stats={stats} username={currentUser?.username} />}
        {page === PAGES.DOJO && <DojoPage setPage={setPage} onDojoCompleted={onDojoCompleted} stats={stats} />}
        {page === PAGES.AI_LAB && <AILabPage setPage={setPage} />}
        {page === PAGES.COACH && <CoachPage setPage={setPage} onAuditionScored={onAuditionScored} />}
        {page === PAGES.HALL_OF_FAME && <HallOfFamePage setPage={setPage} hallOfFame={hallOfFame} performerOfTheWeek={performerOfTheWeek} daysUntilReset={daysUntilReset} currentWeekScores={currentWeekScores} currentUser={currentUser} />}
        {page === PAGES.RESUME && <ResumePage setPage={setPage} onProfileBuilt={onProfileBuilt} profileData={profileData} />}
        {page === PAGES.ANALYTICS && <AnalyticsPage setPage={setPage} stats={stats} />}
        {page === PAGES.INSIGHTS && <InsightsPage setPage={setPage} stats={stats} />}
        {page === PAGES.HEADSHOTS && <HeadshotRankerPage setPage={setPage} />}
        {page === PAGES.PROFILE && <ProfilePage setPage={setPage} profileData={profileData} username={currentUser?.username} />}
        {page === PAGES.SETTINGS && <SettingsPage user={currentUser} currentPriceNum={currentPriceNum} isFounderPricing={isFounderPricing} />}
        {page === PAGES.FOUNDER && <FounderPage setPage={setPage} founderPhoto={founderPhoto} />}
      </div>
    </div>
  );
}
