# APEX Perform — Deployment Guide
## Created by Armaan Juneja

This guide gets your app live on the internet. Follow each step in order.

---

## STEP 1: Get Your Accounts Ready (10 minutes)

You need 3 free accounts. Have a parent help with any that need a credit card.

### 1a. GitHub (stores your code)
- Go to github.com → Sign up → Free account
- Create a new repository called `apex-perform`
- Keep it Public (free hosting needs this)

### 1b. Vercel (hosts your website — free)
- Go to vercel.com → Sign up with your GitHub account
- That's it — Vercel connects to GitHub automatically

### 1c. Anthropic API Key (powers the AI tools)
- Go to console.anthropic.com → Sign up
- Go to API Keys → Create key → Copy it and save it somewhere safe
- Add a payment method (parent help needed) — you only pay per use (~$0.003 per AI call)

---

## STEP 2: Upload Your Code to GitHub (5 minutes)

### Option A: Using GitHub.com (easiest)
1. Go to your `apex-perform` repository on GitHub
2. Click "Add file" → "Upload files"
3. Drag in ALL files from the apex-perform folder:
   - `package.json`
   - `public/index.html`
   - `src/index.js`
   - `src/App.jsx`
4. Click "Commit changes"

### Option B: Using terminal (if you have Git installed)
```bash
cd apex-perform
git init
git add .
git commit -m "APEX Perform v1.0 - Launch"
git remote add origin https://github.com/YOUR_USERNAME/apex-perform.git
git push -u origin main
```

---

## STEP 3: Deploy on Vercel (2 minutes)

1. Go to vercel.com → Dashboard
2. Click "Add New Project"
3. Import your `apex-perform` repository from GitHub
4. Vercel auto-detects it as a React app
5. In "Environment Variables", add:
   - Name: `REACT_APP_CLAUDE_API_KEY`
   - Value: (paste your Anthropic API key)
6. Click "Deploy"
7. Wait 1-2 minutes — Vercel builds and deploys automatically
8. You'll get a URL like: `apex-perform.vercel.app`

Your app is now LIVE on the internet.

---

## STEP 4: Custom Domain (optional, ~$12/year)

1. Buy `apexperform.com` from namecheap.com or Google Domains
2. In Vercel → Your project → Settings → Domains
3. Add `apexperform.com`
4. Vercel gives you DNS records — add them in your domain registrar
5. Wait 10-30 minutes for DNS to propagate
6. Your site is now at apexperform.com with free SSL (https)

---

## STEP 5: Set Up Stripe (when ready for payments)

1. Go to stripe.com → Create account (parent help needed)
2. Products → Create "APEX Perform" → $4.99/month with 3-day trial
3. Coupons → Create "APEX-FOUNDER" → $3.00 off → Duration: forever → Max redemptions: 1000
4. Get your Stripe Publishable Key and Secret Key
5. Add to Vercel environment variables:
   - `REACT_APP_STRIPE_KEY` = your publishable key

---

## What's Working Right Now (without any backend)

The deployed app has EVERYTHING working as a demo:
- Full landing page with scarcity counter
- Signup/login flow (stores in browser session)
- All 6 AI tools (use real Claude API with your key)
- Director dashboard with talent search
- Hall of Fame leaderboard
- Headshot uploads and analysis
- Profile building and sharing
- Founder page with your photo

The only things that need a backend later:
- Data persistence across browser sessions (Firebase)
- Real payment processing (Stripe Checkout)
- Google OAuth (Firebase Auth)
- Multi-user talent pool (Firestore)

You can launch and start getting users NOW, then add the backend as you grow.

---

## Need Help?

If something doesn't work, the most common fixes are:
1. Make sure `src/App.jsx` has the export at the bottom
2. Check that your API key is set in Vercel environment variables
3. Clear your browser cache and reload

---

© 2026 APEX Perform · Created by Armaan Juneja
